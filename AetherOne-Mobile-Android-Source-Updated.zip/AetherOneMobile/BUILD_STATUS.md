# Build status
The source is prepared for an Android Gradle build using GitHub Actions. No APK has been compiled or tested in this environment: Android SDK, Gradle and network access are unavailable here.
The workflow compiles a debug-signed installable APK and verifies that the output exists. It does not establish device compatibility or benchmark claims.
