package com.aetherone.mobile

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.text.InputType
import android.net.Uri
import org.json.JSONArray

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 16, 26)
    private val panel = Color.rgb(25, 32, 46)
    private val fg = Color.rgb(237, 243, 255)
    private val accent = Color.rgb(112, 205, 236)
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var holder: FrameLayout
    private lateinit var tabCount: TextView
    private val tabs = mutableListOf<WebView>()
    private var active = -1
    private val prefs by lazy { getSharedPreferences("aether", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        newTab("https://www.google.com")
    }
    private fun rounded(color: Int, radius: Float = 20f) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun textButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 19f; setTextColor(fg); gravity = Gravity.CENTER
        setOnClickListener { action() }
    }
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        setContentView(root)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12, 10, 12, 10) }
        root.addView(top, LinearLayout.LayoutParams(-1, 58.dp))
        val logo = TextView(this).apply { text = "◈"; textSize = 27f; setTextColor(accent); gravity = Gravity.CENTER }
        top.addView(logo, LinearLayout.LayoutParams(42.dp, -1))
        address = EditText(this).apply {
            setSingleLine(true); textSize = 14f; setTextColor(fg); setHintTextColor(Color.LTGRAY)
            hint = "Search or enter address"; setPadding(15.dp, 0, 12.dp, 0)
            background = rounded(panel); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> navigate(text.toString()); true }
        }
        top.addView(address, LinearLayout.LayoutParams(0, 43.dp, 1f))
        top.addView(textButton("↻") { current()?.reload() }, LinearLayout.LayoutParams(44.dp, -1))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = android.content.res.ColorStateList.valueOf(accent); visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(-1, 2.dp))
        holder = FrameLayout(this)
        root.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(panel) }
        root.addView(bottom, LinearLayout.LayoutParams(-1, 55.dp))
        fun item(label: String, action: () -> Unit): TextView = textButton(label, action).also { bottom.addView(it, LinearLayout.LayoutParams(0, -1, 1f)) }
        item("‹") { current()?.let { if (it.canGoBack()) it.goBack() } }
        item("›") { current()?.let { if (it.canGoForward()) it.goForward() } }
        item("⌂") { current()?.loadUrl("https://www.google.com") }
        tabCount = item("1") { showTabs() }
        item("⋮") { showMenu() }
    }
    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()
    private fun current(): WebView? = tabs.getOrNull(active)
    private fun newTab(url: String) {
        val web = WebView(this)
        web.setBackgroundColor(Color.WHITE)
        web.isSaveEnabled = true
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false)
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "http" || uri.scheme == "https") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri)); true
                } catch (_: Exception) { true }
            }
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) { if (view === current()) { address.setText(url); progress.visibility = View.VISIBLE } }
            override fun onPageFinished(view: WebView, url: String) { if (view === current()) { address.setText(url); progress.visibility = View.GONE }; saveHistory(url) }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, value: Int) { if (view === current()) { progress.progress = value; progress.visibility = if (value >= 100) View.GONE else View.VISIBLE } }
            override fun onReceivedTitle(view: WebView, title: String?) { if (view === current()) tabCount.text = "${tabs.size}" }
        }
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val request = android.app.DownloadManager.Request(android.net.Uri.parse(url))
                request.addRequestHeader("User-Agent", userAgent)
                CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
                request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager).enqueue(request)
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "Download unavailable: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        tabs.add(web); switchTo(tabs.lastIndex); web.loadUrl(url)
    }
    private fun switchTo(index: Int) {
        if (index !in tabs.indices) return
        current()?.onPause()
        active = index; holder.removeAllViews()
        val view = tabs[index]
        (view.parent as? android.view.ViewGroup)?.removeView(view)
        holder.addView(view, FrameLayout.LayoutParams(-1, -1))
        view.onResume(); address.setText(view.url ?: ""); tabCount.text = "${tabs.size}"
    }
    private fun navigate(raw: String) {
        val input = raw.trim(); if (input.isEmpty()) return
        if (input.startsWith("javascript:", true) || input.startsWith("file:", true) || input.startsWith("content:", true)) {
            Toast.makeText(this, "Unsupported address", Toast.LENGTH_SHORT).show(); return
        }
        val url = if (input.startsWith("https://") || input.startsWith("http://")) input else if (!input.contains(' ') && input.contains('.') && !input.startsWith("javascript:", true)) "https://$input" else "https://www.google.com/search?q=" + java.net.URLEncoder.encode(input, "UTF-8")
        current()?.loadUrl(url); address.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0)
    }
    private fun saveHistory(url: String) {
        if (!url.startsWith("https://")) return
        val history = readList("history"); history.remove(url); history.add(0, url)
        writeList("history", history.take(100))
    }
    private fun readList(key: String): MutableList<String> = try {
        val arr = JSONArray(prefs.getString(key, "[]")); MutableList(arr.length()) { arr.getString(it) }
    } catch (_: Exception) { mutableListOf() }
    private fun writeList(key: String, values: List<String>) { prefs.edit().putString(key, JSONArray(values).toString()).apply() }
    private fun showList(title: String, values: List<String>, select: (String) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(values.toTypedArray()) { _, which -> select(values[which]) }.setNegativeButton("Close", null).show()
    }
    private fun showTabs() {
        val names = tabs.mapIndexed { i, web -> "${i + 1}. ${web.title?.take(38) ?: "New tab"}" } + "+ New tab" + "Close current tab"
        AlertDialog.Builder(this).setTitle("Tabs").setItems(names.toTypedArray()) { _, index ->
            when (index) {
                tabs.size -> newTab("https://www.google.com")
                tabs.size + 1 -> closeTab()
                else -> switchTo(index)
            }
        }.setNegativeButton("Cancel", null).show()
    }
    private fun closeTab() {
        if (tabs.size == 1) { current()?.loadUrl("https://www.google.com"); return }
        val oldIndex = active
        val old = tabs.removeAt(oldIndex); holder.removeView(old); old.destroy()
        active = -1
        switchTo(oldIndex.coerceAtMost(tabs.lastIndex))
    }
    private fun showMenu() {
        val options = arrayOf("New tab", "Bookmark this page", "Bookmarks", "History", "Share page", "Clear browsing data")
        AlertDialog.Builder(this).setTitle("Aether One").setItems(options) { _, which ->
            when (which) {
                0 -> newTab("https://www.google.com")
                1 -> current()?.url?.let { url -> val bookmarks = readList("bookmarks"); if (!bookmarks.contains(url)) { bookmarks.add(0, url); writeList("bookmarks", bookmarks) }; Toast.makeText(this, "Bookmarked", Toast.LENGTH_SHORT).show() }
                2 -> showList("Bookmarks", readList("bookmarks")) { current()?.loadUrl(it) }
                3 -> showList("History", readList("history")) { current()?.loadUrl(it) }
                4 -> current()?.url?.let { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, it) }, "Share link")) }
                5 -> AlertDialog.Builder(this).setTitle("Clear browsing data?").setMessage("Removes cookies, cache, history and stored site data.").setPositiveButton("Clear") { _, _ ->
                    CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush()
                    WebStorage.getInstance().deleteAllData()
                    tabs.forEach { it.clearCache(true); it.clearHistory() }
                    prefs.edit().remove("history").apply()
                }.setNegativeButton("Cancel", null).show()
            }
        }.show()
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (current()?.canGoBack() == true) current()?.goBack() else super.onBackPressed() }
    override fun onPause() { super.onPause(); current()?.onPause() }
    override fun onResume() { super.onResume(); current()?.onResume() }
    override fun onDestroy() { tabs.forEach { (it.parent as? android.view.ViewGroup)?.removeView(it); it.destroy() }; super.onDestroy() }
}
