# Aether One Mobile 0.1

A native Android browser prototype built with Kotlin and Android System WebView. No ads, analytics, external SDKs or background services are included.

## Included
- Address bar with Google search fallback
- Multiple tabs, back/forward, refresh, home
- Bookmarks and local browsing history
- Android DownloadManager integration
- Share links and clear browsing data
- JavaScript and DOM storage for modern website compatibility
- HTTPS-first navigation; cleartext network traffic disabled

## Build an APK
### Android Studio
1. Install Android Studio with Android SDK Platform 35.
2. Open this project directory.
3. Wait for Gradle sync, then choose Build > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions (no local SDK needed)
1. Create a private GitHub repository and upload the project files, including `.github/workflows/android-apk.yml`.
2. Open Actions > Build Android APK > Run workflow.
3. Download the `AetherOne-Mobile-debug-APK` artifact after the build succeeds.
4. Extract the artifact and install the APK on your phone.

## Important limitations
This is an uncompiled prototype, not production software. WebView compatibility depends on the Android System WebView installed on the device. Popups, camera/microphone permissions, file upload handling, passkeys, incognito isolation, crash/session recovery, accessibility validation and performance benchmarking require additional development and device testing. Debug APKs are not suitable for store release. No guarantee is made of instant page loads or lower RAM use than every existing browser.
