package com.aetherone.mobile

/** Small, auditable built-in host list. No remote update, regex scans, or network lookup. */
internal object AdRules {
    private val hosts = """
        doubleclick.net googlesyndication.com googleadservices.com google-analytics.com
        adservice.google.com googletagservices.com pagead2.googlesyndication.com
        ads.youtube.com ads-twitter.com ads.linkedin.com ads.pinterest.com
        amazon-adsystem.com media.net adnxs.com adsrvr.org adroll.com adform.net
        advertising.com criteo.com criteo.net taboola.com outbrain.com
        pubmatic.com rubiconproject.com openx.net casalemedia.com indexww.com
        smartadserver.com sharethrough.com lijit.com sovrn.com triplelift.com
        3lift.com contextweb.com bidr.io bidswitch.net bidvertiser.com
        yieldmo.com yieldlab.net yieldlove.com yieldoptimizer.com
        revcontent.com mgid.com propellerads.com popads.net popcash.net
        adsterra.com trafficjunky.net exoclick.com hilltopads.net
        scorecardresearch.com quantserve.com quantcount.com
        hotjar.com hotjar.io mouseflow.com clarity.ms fullstory.com
        adsafeprotected.com doubleverify.com moatads.com
        demdex.net everesttech.net bluekai.com rlcdn.com tapad.com
        mathtag.com mookie1.com agkn.com dotomi.com serving-sys.com
        adtelligent.com onetag-sys.com
        admanmedia.com teads.tv seedtag.com gumgum.com undertone.com
        kargo.com inmobi.com adswizz.com spotxchange.com spotx.tv
        freewheel.tv stickyadstv.com adap.tv advertising.amazon.com
    """.trimIndent().split(Regex("\\s+")).toHashSet()

    fun shouldBlock(resourceHost: String?, pageHost: String): Boolean {
        val resource = resourceHost?.lowercase(java.util.Locale.ROOT)?.trimEnd('.') ?: return false
        val page = pageHost.lowercase(java.util.Locale.ROOT).trimEnd('.')
        // Never block the visited host or its own subdomains, even if on our list.
        if (page.isEmpty() || resource == page || resource.endsWith(".$page")) return false
        var candidate = resource
        while (candidate.isNotEmpty()) {
            if (candidate in hosts) return true
            val dot = candidate.indexOf('.')
            if (dot < 0) break
            candidate = candidate.substring(dot + 1)
        }
        return false
    }
}
