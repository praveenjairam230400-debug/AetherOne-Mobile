package com.aetherone.mobile

import android.app.*
import android.net.ConnectivityManager
import androidx.webkit.*
import java.util.concurrent.Executors
import java.util.concurrent.Executor
import android.app.role.RoleManager
import android.content.*
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 17, 25)
    private val surface = Color.rgb(20, 29, 40)
    private val card = Color.rgb(28, 39, 52)
    private val line = Color.rgb(42, 55, 70)
    private val ink = Color.rgb(238, 244, 250)
    private val muted = Color.rgb(151, 168, 186)
    private val mint = Color.rgb(113, 231, 201)
    private val prefs by lazy { getSharedPreferences("aether", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var holder: FrameLayout
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var reloadIcon: IconView
    private lateinit var securityIcon: IconView
    private lateinit var backIcon: IconView
    private lateinit var forwardIcon: IconView
    private lateinit var tabsIcon: IconView
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findResult: TextView
    private val tabs = mutableListOf<Page>()
    private var active = -1
    private var desktop = false
    private var customVideo: View? = null
    private var customVideoCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var restoring = false
    private lateinit var speedLabel: TextView
    private val uiHandler = Handler(Looper.getMainLooper())
    private val sessionWriter = Runnable { persistSession() }
    private val startupExecutor = Executors.newSingleThreadExecutor()
    private var engineReady = false
    private var preloadSignal: CancellationSignal? = null
    private var preloadUrl: String? = null
    private var preloadOwner: Page? = null
    private var preloadStatus = "Engine warming up"
    private var historyCache: MutableList<String>? = null
    private val uiExecutor = Executor { task -> uiHandler.post(task) }
    @Volatile private var adBlock = true
    private var lite = false
    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()
    private class Page(var url: String = HOME, var title: String = "New tab", var web: WebView? = null) {
        @Volatile var filterHost = ""
        val blocked = AtomicInteger(0)
        val observed = AtomicInteger(0)
        var requestedAt = 0L
        var visibleMs = 0L
        var completeMs = 0L
        var pendingStart = false
        var loading = false
        var preloaded = false
        var reused = false
    }
    companion object { private const val HOME = "aether://home"; private const val FILE_PICK = 401 }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        // Start Chromium before any other WebView API or page restoration can initialize it.
        startEngine()
        desktop = prefs.getBoolean("desktop", false)
        lite = prefs.getBoolean("lite", false)
        adBlock = prefs.getBoolean("adBlock", true)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        buildUi()
        val session = try { JSONArray(prefs.getString("session", "[]")) } catch (_: Exception) { JSONArray() }
        restoring = true
        for (i in 0 until minOf(session.length(), 20)) {
            val item = session.optJSONObject(i) ?: continue
            val url = item.optString("url", HOME)
            if (url == HOME || isWebUrl(url)) tabs.add(Page(url, item.optString("title", "New tab")))
        }
        if (tabs.isEmpty()) tabs.add(Page())
        switchTo(prefs.getInt("active", 0).coerceIn(0, tabs.lastIndex))
        restoring = false
        handleIntent(intent)
    }
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        setContentView(root)
        // Android 15+ enforces edge-to-edge for target 35. Apply actual system/IME insets.
        root.setOnApplyWindowInsetsListener { _, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val safe = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime())
                root.setPadding(safe.left, safe.top, safe.right, safe.bottom)
            } else {
                @Suppress("DEPRECATION")
                root.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }
        root.requestApplyInsets()
        val top = row().apply { setPadding(8.dp, 6.dp, 8.dp, 8.dp) }
        root.addView(top, LinearLayout.LayoutParams(-1, 64.dp))
        top.addView(icon("brand", "Aether home") { home() }, LinearLayout.LayoutParams(44.dp, 48.dp))
        val omnibox = row().apply { background = rounded(surface, 18f, line) }
        top.addView(omnibox, LinearLayout.LayoutParams(0, 48.dp, 1f))
        securityIcon = icon("search", "Page connection information") { connectionInfo() }.apply { color = muted }
        omnibox.addView(securityIcon, LinearLayout.LayoutParams(38.dp, 48.dp))
        address = EditText(this).apply {
            textSize = 14f; setTextColor(ink); setHintTextColor(muted); hint = "Search or enter address"
            background = null; setSingleLine(true); setSelectAllOnFocus(true); setPadding(0, 0, 0, 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, event ->
                if (action == EditorInfo.IME_ACTION_GO || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP)) { navigate(text.toString()); true } else false
            }
            setOnFocusChangeListener { _, focused -> if (focused && currentPage()?.url == HOME) setText("") }
        }
        omnibox.addView(address, LinearLayout.LayoutParams(0, -1, 1f))
        reloadIcon = icon("reload", "Reload page") { current()?.let { if (it.progress < 100) it.stopLoading() else it.reload() } }
        omnibox.addView(reloadIcon, LinearLayout.LayoutParams(44.dp, 48.dp))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(mint); progressBackgroundTintList = ColorStateList.valueOf(bg); visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 2.dp))
        speedLabel = text("Engine warming up", 10f, muted).apply { setPadding(16.dp, 0, 16.dp, 0); gravity = Gravity.CENTER_VERTICAL; contentDescription = "Open Loading Inspector"; isClickable = true; setOnClickListener { loadingInspector() } }
        root.addView(speedLabel, LinearLayout.LayoutParams(-1, 23.dp))
        findBar = row().apply { setPadding(12.dp, 4.dp, 4.dp, 4.dp); setBackgroundColor(surface); visibility = View.GONE }
        findInput = EditText(this).apply {
            hint = "Find on this page"; setTextColor(ink); setHintTextColor(muted); textSize = 14f; setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> current()?.findAllAsync(text.toString()); hideKeyboard(); true }
        }
        findBar.addView(findInput, LinearLayout.LayoutParams(0, 48.dp, 1f))
        findResult = text("", 11f, muted)
        findBar.addView(findResult)
        findBar.addView(icon("up", "Previous match") { current()?.findNext(false) }, LinearLayout.LayoutParams(44.dp, 48.dp))
        findBar.addView(icon("down", "Next match") { current()?.findNext(true) }, LinearLayout.LayoutParams(44.dp, 48.dp))
        findBar.addView(icon("close", "Close find") { closeFind() }, LinearLayout.LayoutParams(44.dp, 48.dp))
        root.addView(findBar)
        holder = FrameLayout(this)
        root.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, 1.dp))
        val bottom = row().apply { setPadding(6.dp, 4.dp, 6.dp, 4.dp); setBackgroundColor(bg) }
        root.addView(bottom, LinearLayout.LayoutParams(-1, 62.dp))
        backIcon = icon("back", "Go back") { current()?.let { if (it.canGoBack()) it.goBack() else home() } }
        forwardIcon = icon("forward", "Go forward") { current()?.let { if (it.canGoForward()) it.goForward() } }
        tabsIcon = icon("tabs", "Open tabs") { showTabs() }
        listOf(backIcon, forwardIcon, icon("home", "Home") { home() }, tabsIcon, icon("menu", "Browser menu") { showMenu() }).forEach {
            bottom.addView(it, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun text(value: String, size: Float = 15f, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private fun rounded(color: Int, radius: Float = 18f, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.dpFloat(); if (stroke != null) setStroke(1.dp, stroke)
    }
    private fun Float.dpFloat() = this * resources.displayMetrics.density
    private fun icon(kind: String, label: String, action: () -> Unit) = IconView(kind).apply {
        contentDescription = label; isClickable = true; isFocusable = true
        val out = android.util.TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, out, true)
        if (out.resourceId != 0) foreground = getDrawable(out.resourceId)
        setOnClickListener { action() }
    }
    private fun currentPage() = tabs.getOrNull(active)
    private fun current() = currentPage()?.web
    private fun isWebUrl(url: String) = try { val uri = Uri.parse(url); uri.scheme in listOf("https", "http") && !uri.host.isNullOrBlank() } catch (_: Exception) { false }
    private fun webFor(page: Page): WebView = page.web ?: WebView(this).also { web ->
        page.web = web
        web.setBackgroundColor(Color.WHITE)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; builtInZoomControls = true; displayZoomControls = false
            allowFileAccess = false; allowContentAccess = false; mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true; setSupportMultipleWindows(false); mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
            blockNetworkImage = lite
        }
        setDesktop(web)
        applySiteSettings(page, page.url)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.BACK_FORWARD_CACHE)) WebSettingsCompat.setBackForwardCacheEnabled(web.settings, true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (request.isForMainFrame || request.url.scheme !in listOf("https", "http")) return null
                page.observed.incrementAndGet()
                // Runs on Chromium's worker thread. No WebView access, network, disk or UI work.
                if (adBlock && prefs.getBoolean("site:${page.filterHost}:ads", true) &&
                    AdRules.shouldBlock(request.url.host, page.filterHost)) {
                    page.blocked.incrementAndGet()
                    return WebResourceResponse("text/plain", "UTF-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https") {
                    if (!request.isForMainFrame) return false
                    page.blocked.set(0); page.observed.set(0)
                    applySiteSettings(page, uri.toString())
                    cancelPreloadUnless(uri.toString())
                    page.requestedAt = SystemClock.elapsedRealtime(); page.visibleMs = 0; page.completeMs = 0
                    page.loading = true; page.pendingStart = true; page.preloaded = false; page.reused = false
                    return false
                }
                if (uri.scheme == "http") { view.loadUrl(uri.buildUpon().scheme("https").build().toString()); return true }
                if (request.hasGesture() && uri.scheme in listOf("mailto", "tel", "sms", "geo", "market")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)) } catch (_: Exception) { toast("No app can open this link") }
                }
                return true
            }
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                applySiteSettings(page, url)
                if (page.url != HOME) {
                    if (!page.pendingStart && !page.loading) page.requestedAt = SystemClock.elapsedRealtime()
                    page.pendingStart = false; page.loading = true; page.visibleMs = 0; page.completeMs = 0
                    page.url = url; if (page === currentPage()) syncControls()
                }
            }
            override fun onPageCommitVisible(view: WebView, url: String) {
                if (page.url != HOME && page.requestedAt > 0 && page.visibleMs == 0L) {
                    page.visibleMs = SystemClock.elapsedRealtime() - page.requestedAt
                    if (page === currentPage()) updateSpeedLabel()
                }
            }
            override fun onPageFinished(view: WebView, url: String) {
                if (page.url == HOME) return
                page.url = url; page.title = view.title ?: host(url)
                page.loading = false
                if (page.requestedAt > 0) page.completeMs = SystemClock.elapsedRealtime() - page.requestedAt
                if (isWebUrl(url) && view.originalUrl != null) saveHistory(url)
                saveSession(); if (page === currentPage()) syncControls()
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame && page === currentPage()) { page.loading = false; progress.visibility = View.GONE; toast("Page could not load. Check the address or connection.") }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, value: Int) {
                if (page === currentPage() && page.url != HOME) {
                    progress.progress = value
                    progress.visibility = if (value >= 100) View.GONE else View.VISIBLE
                    val glyph = if (value < 100) "close" else "reload"
                    if (reloadIcon.kind != glyph) { reloadIcon.kind = glyph; reloadIcon.contentDescription = if (value < 100) "Stop loading" else "Reload page"; reloadIcon.invalidate() }
                }
            }
            override fun onReceivedTitle(view: WebView, title: String?) { page.title = title ?: "Page"; saveSession() }
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = callback
                val types = params.acceptTypes.filter { it.contains('/') && !it.contains(';') }.toTypedArray()
                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = if (types.size == 1) types[0] else "*/*"
                    if (types.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, types)
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                return try { startActivityForResult(picker, FILE_PICK); true } catch (_: Exception) { fileCallback = null; callback.onReceiveValue(null); toast("File picker unavailable"); true }
            }
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customVideo != null) { callback.onCustomViewHidden(); return }
                customVideo = view; customVideoCallback = callback
                (window.decorView as ViewGroup).addView(view, ViewGroup.LayoutParams(-1, -1))
                if (Build.VERSION.SDK_INT >= 30) window.insetsController?.hide(WindowInsets.Type.systemBars())
            }
            override fun onHideCustomView() { hideVideo() }
        }
        web.setFindListener { index, count, done -> if (done) findResult.text = if (count == 0) "0 results" else "${index + 1}/$count" }
        web.setOnLongClickListener {
            val hit = web.hitTestResult
            if (hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                hit.extra?.takeIf { isWebUrl(it) }?.let { url ->
                    sheet("Link", listOf("Open in new tab" to { newTab(url) }, "Copy link" to { copy(url) }, "Share link" to { share(url) })); return@setOnLongClickListener true
                }
            }
            false
        }
        web.setDownloadListener { url, agent, disposition, mime, _ ->
            if (!url.startsWith("https://", true)) { toast("Only HTTPS downloads are supported"); return@setDownloadListener }
            try {
                val filename = URLUtil.guessFileName(url, disposition, mime).replace(Regex("[/\\\\]"), "_")
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    addRequestHeader("User-Agent", agent)
                    CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    if (Build.VERSION.SDK_INT >= 29) setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                    else setDestinationInExternalFilesDir(this@MainActivity, Environment.DIRECTORY_DOWNLOADS, filename)
                    if (!mime.isNullOrBlank()) setMimeType(mime)
                }
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request); toast("Downloading $filename")
            } catch (_: Exception) { toast("Download could not start") }
        }
    }
    private fun setDesktop(web: WebView) {
        web.settings.userAgentString = if (desktop) WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Android", "X11; Linux x86_64").replace("Mobile ", "") else WebSettings.getDefaultUserAgent(this)
        web.settings.useWideViewPort = true; web.settings.loadWithOverviewMode = true
    }
    private fun newTab(url: String = HOME) { if (tabs.size >= 20) { toast("Close a tab first (20 tab limit)"); return }; tabs.add(Page()); switchTo(tabs.lastIndex); if (url != HOME) navigate(url) }
    private fun switchTo(index: Int) {
        if (index !in tabs.indices) return
        if (active == index && holder.childCount > 0) return
        cancelPreloadUnless(null)
        val previous = currentPage()
        if (previous?.url == HOME && (previous.web?.url == null || previous.web?.url == "about:blank")) {
            previous.web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }; previous.web = null
        }
        current()?.onPause(); closeFind(); active = index; holder.removeAllViews()
        val page = tabs[index]
        if (page.url == HOME) showHome() else {
            val web = webFor(page); web.visibility = View.VISIBLE; web.settings.offscreenPreRaster = false
            (web.parent as? ViewGroup)?.removeView(web); holder.addView(web, FrameLayout.LayoutParams(-1, -1)); web.onResume()
            if (web.url == null) { applySiteSettings(page, page.url); page.requestedAt = SystemClock.elapsedRealtime(); page.pendingStart = true; page.loading = true; web.loadUrl(page.url) }
            else page.reused = !page.loading
        }
        syncControls(); saveSession()
    }
    private fun home() {
        cancelPreloadUnless(null)
        current()?.stopLoading(); current()?.onPause(); currentPage()?.apply { url = HOME; title = "New tab"; loading = false }
        closeFind(); holder.removeAllViews(); showHome(); syncControls(); saveSession()
    }
    private fun showHome() {
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = column().apply { setPadding(24.dp, 24.dp, 24.dp, 30.dp) }
        scroll.addView(content)
        val identity = row()
        identity.addView(IconView("brand").apply { color = mint; contentDescription = "Aether One logo" }, LinearLayout.LayoutParams(34.dp, 34.dp))
        identity.addView(text("AETHER ONE", 12f, mint, true).apply { letterSpacing = .18f; setPadding(10.dp, 0, 0, 0) })
        content.addView(identity)
        content.addView(text("A little space.\nA world to explore.", 32f, ink, true).apply { setPadding(0, 26.dp, 0, 8.dp); setLineSpacing(2.dp.toFloat(), 1f) })
        content.addView(text("Your next discovery starts here.", 14f, muted))
        val search = row().apply { background = rounded(card, 22f, line); setPadding(14.dp, 0, 8.dp, 0) }
        search.addView(IconView("search").apply { color = mint }, LinearLayout.LayoutParams(28.dp, 28.dp))
        val query = EditText(this).apply {
            background = null; hint = "Search the web"; textSize = 16f; setTextColor(ink); setHintTextColor(muted); setSingleLine(true)
            setPadding(12.dp, 0, 4.dp, 0); imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> navigate(text.toString()); true }
        }
        search.addView(query, LinearLayout.LayoutParams(0, -1, 1f))
        search.addView(icon("forward", "Search") { navigate(query.text.toString()) }, LinearLayout.LayoutParams(44.dp, 48.dp))
        content.addView(search, LinearLayout.LayoutParams(-1, 62.dp).apply { topMargin = 28.dp; bottomMargin = 30.dp })
        content.addView(text("QUICK ACCESS", 11f, muted, true).apply { letterSpacing = .14f })
        val links = listOf(Triple("Google", "G", "https://www.google.com"), Triple("YouTube", "play", "https://www.youtube.com"), Triple("Wikipedia", "W", "https://www.wikipedia.org"), Triple("GitHub", "code", "https://github.com"))
        val grid = row().apply { gravity = Gravity.TOP }
        links.forEach { (name, glyph, url) ->
            val tile = column().apply { gravity = Gravity.CENTER; isClickable = true; isFocusable = true; contentDescription = "Open $name"; setOnClickListener { navigate(url) } }
            val badge = FrameLayout(this).apply { background = rounded(surface, 19f, line) }
            if (glyph.length == 1) badge.addView(text(glyph, 23f, mint, true).apply { gravity = Gravity.CENTER }, FrameLayout.LayoutParams(-1, -1))
            else badge.addView(IconView(glyph).apply { color = mint }, FrameLayout.LayoutParams(-1, -1))
            tile.addView(badge, LinearLayout.LayoutParams(56.dp, 56.dp))
            tile.addView(text(name, 11f, muted).apply { gravity = Gravity.CENTER; setPadding(0, 10.dp, 0, 0) })
            grid.addView(tile, LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18.dp; bottomMargin = 30.dp })
        val saved = readList("bookmarks").take(4)
        if (saved.isNotEmpty()) {
            content.addView(text("SAVED FOR YOU", 11f, muted, true).apply { letterSpacing = .14f })
            saved.forEach { url -> content.addView(homeLink(host(url), url) { navigate(url) }, LinearLayout.LayoutParams(-1, 62.dp).apply { topMargin = 10.dp }) }
        }
        val note = row().apply { background = rounded(surface); setPadding(16.dp, 14.dp, 16.dp, 14.dp) }
        note.addView(IconView("lock").apply { color = mint }, LinearLayout.LayoutParams(24.dp, 24.dp))
        note.addView(text("Instant Open prepares Google on Wi-Fi.\nUses extra data · control it in Speed settings.", 12f, muted).apply { setPadding(12.dp, 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24.dp })
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        root.post { prepareHomePreload() }
    }
    private fun homeLink(title: String, subtitle: String, action: () -> Unit) = column().apply {
        background = rounded(surface); setPadding(16.dp, 9.dp, 16.dp, 9.dp); isClickable = true; isFocusable = true; setOnClickListener { action() }
        addView(text(title, 14f, ink, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        addView(text(subtitle, 11f, muted).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
    }
    private fun navigate(raw: String) {
        val requestedAt = SystemClock.elapsedRealtime()
        val input = raw.trim(); if (input.isEmpty()) return
        val uri = Uri.parse(input)
        val url = when {
            input.equals(HOME, true) -> { home(); return }
            input.startsWith("https://", true) -> "https://" + input.substring(8)
            input.startsWith("http://", true) -> "https://" + input.substring(7)
            !uri.scheme.isNullOrEmpty() && input.contains("://") -> { toast("Unsupported address"); return }
            listOf("javascript:", "file:", "content:", "data:", "intent:").any { input.startsWith(it, true) } -> { toast("Unsupported address"); return }
            !input.contains(' ') && input.contains('.') -> "https://$input"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(input, "UTF-8")
        }
        if (!isWebUrl(url)) { toast("Enter a valid address"); return }
        val page = currentPage() ?: return
        val matchingPreload = preloadOwner === page && preloadUrl == url
        cancelPreloadUnless(if (matchingPreload) url else null)
        page.url = url; val web = webFor(page)
        applySiteSettings(page, url)
        val sameLivePage = web.url == url && web.progress == 100
        page.requestedAt = requestedAt; page.visibleMs = 0; page.completeMs = 0; page.reused = sameLivePage; page.preloaded = false
        page.pendingStart = !sameLivePage; page.loading = !sameLivePage
        web.visibility = View.VISIBLE; web.settings.offscreenPreRaster = false
        holder.removeAllViews(); (web.parent as? ViewGroup)?.removeView(web); holder.addView(web, FrameLayout.LayoutParams(-1, -1)); web.onResume()
        address.clearFocus(); hideKeyboard(); closeFind()
        if (!sameLivePage) { page.blocked.set(0); page.observed.set(0); web.loadUrl(url) }
        syncControls(); saveSession()
    }
    private fun syncControls() {
        val page = currentPage(); val home = page?.url == HOME
        val addressText = if (home) "" else page?.url ?: ""
        if (!address.hasFocus() && address.text.toString() != addressText) address.setText(addressText)
        securityIcon.kind = if (home) "search" else "lock"; securityIcon.color = if (home) muted else mint; securityIcon.invalidate()
        val loading = !home && (current()?.progress ?: 100) < 100
        progress.visibility = if (loading) View.VISIBLE else View.GONE; progress.progress = current()?.progress ?: 100
        reloadIcon.kind = if (loading) "close" else "reload"; reloadIcon.contentDescription = if (loading) "Stop loading" else "Reload page"; reloadIcon.alpha = if (home) .35f else 1f; reloadIcon.invalidate()
        backIcon.alpha = if (!home) 1f else .3f; forwardIcon.alpha = if (!home && current()?.canGoForward() == true) 1f else .3f
        if (tabsIcon.badge != tabs.size.toString()) { tabsIcon.badge = tabs.size.toString(); tabsIcon.contentDescription = "Open tabs, ${tabs.size} tabs"; tabsIcon.invalidate() }
        updateSpeedLabel()
    }
    private fun showTabs() {
        val dialog = bottomDialog()
        val content = sheetBase("Your tabs", "${tabs.size} open · tap a tab to switch")
        val scroll = ScrollView(this)
        val list = column()
        tabs.forEachIndexed { i, page ->
            val item = row().apply { background = rounded(if (i == active) card else surface, 18f, if (i == active) mint else line); setPadding(12.dp, 8.dp, 4.dp, 8.dp) }
            item.addView(IconView(if (page.url == HOME) "home" else "globe").apply { color = if (i == active) mint else muted }, LinearLayout.LayoutParams(34.dp, 42.dp))
            val label = column().apply { setPadding(10.dp, 0, 6.dp, 0); isClickable = true; isFocusable = true; setOnClickListener { dialog.dismiss(); switchTo(i) } }
            label.addView(text(page.title, 15f, ink, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            label.addView(text(if (page.url == HOME) "Your Aether start page" else host(page.url), 12f, muted).apply { maxLines = 1 })
            item.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            item.addView(icon("close", "Close ${page.title}") { dialog.dismiss(); closeTab(i); showTabs() }, LinearLayout.LayoutParams(48.dp, 48.dp))
            list.addView(item, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10.dp })
        }
        scroll.addView(list); content.addView(scroll, LinearLayout.LayoutParams(-1, minOf(360.dp, tabs.size * 82.dp)))
        content.addView(actionRow("plus", "New tab", "Start a fresh discovery") { dialog.dismiss(); newTab() })
        dialog.setContentView(content); showBottom(dialog)
    }
    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val selected = currentPage(); val removed = tabs.removeAt(index)
        removed.web?.let { (it.parent as? ViewGroup)?.removeView(it); it.stopLoading(); it.destroy() }; removed.web = null
        if (tabs.isEmpty()) tabs.add(Page())
        active = -1
        switchTo(if (selected === removed) index.coerceAtMost(tabs.lastIndex) else tabs.indexOf(selected).coerceAtLeast(0))
    }
    private fun bottomDialog() = Dialog(this).apply { window?.setBackgroundDrawableResource(android.R.color.transparent) }
    private fun sheetBase(title: String, subtitle: String? = null) = column().apply {
        background = rounded(surface, 26f); setPadding(20.dp, 12.dp, 20.dp, 22.dp)
        addView(View(this@MainActivity).apply { background = rounded(line, 4f) }, LinearLayout.LayoutParams(36.dp, 4.dp).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = 18.dp })
        addView(text(title, 23f, ink, true).apply { setPadding(0, 0, 0, 8.dp) })
        if (subtitle != null) addView(text(subtitle, 12f, muted).apply { setPadding(0, 0, 0, 18.dp) })
    }
    private fun showBottom(dialog: Dialog) {
        hideKeyboard()
        dialog.show(); dialog.window?.apply { setBackgroundDrawableResource(android.R.color.transparent); setLayout(-1, -2); setGravity(Gravity.BOTTOM); addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); setDimAmount(.55f) }
    }
    private fun actionRow(glyph: String, title: String, subtitle: String? = null, action: () -> Unit) = row().apply {
        setPadding(0, 7.dp, 0, 7.dp); minimumHeight = 52.dp; isClickable = true; isFocusable = true; contentDescription = title
        setOnClickListener { action() }; addView(IconView(glyph).apply { color = mint }, LinearLayout.LayoutParams(36.dp, 36.dp))
        val labels = column().apply { setPadding(12.dp, 0, 0, 0) }; labels.addView(text(title, 15f))
        if (subtitle != null) labels.addView(text(subtitle, 11f, muted))
        addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
    }
    private fun sheet(title: String, entries: List<Pair<String, () -> Unit>>) {
        val dialog = bottomDialog(); val content = sheetBase(title)
        entries.forEach { (label, action) -> content.addView(actionRow("forward", label) { dialog.dismiss(); action() }) }
        dialog.setContentView(content); showBottom(dialog)
    }
    private fun showMenu() {
        val dialog = bottomDialog(); val content = sheetBase("Make it your space", "Aether One · 0.4.0")
        val entries: List<Triple<String, String, () -> Unit>> = listOf(
            Triple("plus", "New tab", { newTab() }),
            Triple("star", "Save this page", { currentPage()?.url?.takeIf { it != HOME }?.let { val list = readList("bookmarks"); list.remove(it); list.add(0, it); writeList("bookmarks", list); toast("Saved to bookmarks") } ?: toast("Open a website first") }),
            Triple("bookmark", "Bookmarks", { showSaved("Bookmarks", "bookmarks") }),
            Triple("history", "History", { showSaved("History", "history") }),
            Triple("search", "Find on page", { if (currentPage()?.url != HOME) { findBar.visibility = View.VISIBLE; findInput.requestFocus(); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT) } else toast("Open a website first") }),
            Triple("desktop", if (desktop) "Desktop site · on" else "Desktop site · off", { desktop = !desktop; prefs.edit().putBoolean("desktop", desktop).apply(); tabs.forEach { it.web?.let { web -> setDesktop(web) }; applySiteSettings(it, it.url) }; if (currentPage()?.url != HOME) current()?.reload(); Unit }),
            Triple("download", "Downloads", { try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (_: Exception) { toast("Downloads app unavailable") } }),
            Triple("share", "Share page", { currentPage()?.url?.takeIf { it != HOME }?.let { share(it) } ?: toast("Open a website first") }),
            Triple("lock", if (adBlock) "Ad blocker · on" else "Ad blocker · off", { blockerSettings() }),
            Triple("settings", "Site controls", { siteControls() }),
            Triple("history", "Loading Inspector", { loadingInspector() }),
            Triple("settings", "Speed settings", { speedSettings() }),
            Triple("settings", "Settings", { showSettings() })
        )
        val scroll = ScrollView(this); val rows = column()
        entries.forEach { (glyph, label, action) -> rows.addView(actionRow(glyph, label) { dialog.dismiss(); action() }) }
        scroll.addView(rows); content.addView(scroll, LinearLayout.LayoutParams(-1, minOf(480.dp, resources.displayMetrics.heightPixels / 2)))
        dialog.setContentView(content); showBottom(dialog)
    }
    private fun siteHost(url: String) = Uri.parse(url).host?.lowercase(java.util.Locale.ROOT)?.trimEnd('.') ?: ""
    private fun siteKey(host: String, setting: String) = "site:$host:$setting"
    private fun applySiteSettings(page: Page, url: String) {
        val h = siteHost(url)
        if (h != page.filterHost) { page.filterHost = h; page.blocked.set(0); page.observed.set(0) }
        page.web?.settings?.apply {
            javaScriptEnabled = prefs.getBoolean(siteKey(h, "js"), true)
            blockNetworkImage = lite || !prefs.getBoolean(siteKey(h, "images"), true)
            val useDesktop = prefs.getBoolean(siteKey(h, "desktop"), desktop)
            userAgentString = if (useDesktop) WebSettings.getDefaultUserAgent(this@MainActivity).replace("; wv", "").replace("Android", "X11; Linux x86_64").replace("Mobile ", "") else WebSettings.getDefaultUserAgent(this@MainActivity)
        }
    }
    private fun toggleRow(label: String, detail: String, checked: Boolean, changed: (Boolean) -> Unit) = column().apply {
        setPadding(0, 5.dp, 0, 10.dp)
        addView(Switch(this@MainActivity).apply {
            text = label; setTextColor(ink); textSize = 15f; isChecked = checked; minimumHeight = 48.dp
            setOnCheckedChangeListener { _, value -> changed(value) }
        })
        addView(text(detail, 12f, muted))
    }
    private fun reloadWithPolicy(page: Page) {
        cancelPreloadUnless(null)
        applySiteSettings(page, page.url)
        page.blocked.set(0); page.observed.set(0)
        page.requestedAt = SystemClock.elapsedRealtime(); page.pendingStart = true
        page.visibleMs = 0; page.completeMs = 0; page.reused = false; page.preloaded = false
        if (page.url != HOME) page.web?.reload()
    }
    private fun blockerSettings() {
        val d = bottomDialog(); val c = sheetBase("Ad & tracker blocker", "Local filtering · no browsing data sent to a filtering server")
        c.addView(toggleRow("Block known ad and tracker hosts", "Changes affect new requests. Reload open pages to fully apply.", adBlock) {
            adBlock = it; prefs.edit().putBoolean("adBlock", it).apply(); cancelPreloadUnless(null)
        })
        c.addView(text("Built-in host rules stop matching subresource requests before download. Main pages are never blocked. This is not a complete EasyList engine: first-party ads, video ads, service workers and redirected requests may escape filtering.", 13f, muted).apply { setPadding(0, 10.dp, 0, 14.dp) })
        c.addView(actionRow("reload", "Reload this page") { d.dismiss(); currentPage()?.let { reloadWithPolicy(it) } })
        c.addView(actionRow("settings", "Site exception & controls") { d.dismiss(); siteControls() })
        d.setContentView(c); showBottom(d)
    }
    private fun siteControls() {
        val p = currentPage()?.takeIf { it.url != HOME } ?: run { toast("Open a website first"); return }
        val h = siteHost(p.url)
        val d = bottomDialog(); val c = sheetBase("Site controls", "$h · settings apply to this exact host")
        for ((key, title, detail) in listOf(
            Triple("ads", "Ad blocker for this site", "The global blocker switch must also be on."),
            Triple("js", "JavaScript", "Turning off scripts can break sign-in, video and interactive pages."),
            Triple("images", "Images", "Speed settings Lite mode overrides this switch."),
            Triple("desktop", "Desktop layout", "Ask this site for its desktop version."))) {
            c.addView(toggleRow(title, detail, prefs.getBoolean(siteKey(h, key), if (key == "desktop") desktop else true)) {
                prefs.edit().putBoolean(siteKey(h, key), it).apply(); cancelPreloadUnless(null)
            })
        }
        c.addView(actionRow("reload", "Apply & reload", "Reloads open tabs on this host") {
            d.dismiss(); tabs.filter { siteHost(it.url) == h }.forEach { reloadWithPolicy(it) }
        })
        c.addView(actionRow("close", "Reset this site's settings") {
            val e = prefs.edit(); listOf("ads", "js", "images", "desktop").forEach { e.remove(siteKey(h, it)) }; e.apply()
            d.dismiss(); tabs.filter { siteHost(it.url) == h }.forEach { reloadWithPolicy(it) }
        })
        val scroll = ScrollView(this); scroll.addView(c); d.setContentView(scroll); showBottom(d)
    }
    private fun loadingInspector() {
        val p = currentPage()?.takeIf { it.url != HOME } ?: run { toast("Open a website first"); return }
        val w = p.web ?: return
        val expected = w.url
        val d = bottomDialog(); val c = sheetBase("Loading Inspector", "${host(p.url)} · current document")
        val report = text("Reading page timings…", 13f, ink).apply { setTextIsSelectable(true); setLineSpacing(5.dp.toFloat(), 1f) }
        c.addView(report)
        c.addView(actionRow("reload", "Reload to measure a new visit", "Reload uses the normal HTTP cache") { d.dismiss(); reloadWithPolicy(p) })
        val scroll = ScrollView(this); scroll.addView(c); d.setContentView(scroll); showBottom(d)
        val base = "Observed subresource requests: ${p.observed.get()}\nBlocked requests: ${p.blocked.get()}\n" +
            "Native first-visible callback: ${if (p.visibleMs > 0) "${p.visibleMs} ms" else "unavailable"}\n" +
            "Native finished callback: ${if (p.completeMs > 0) "${p.completeMs} ms" else "pending / unavailable"}\n\n"
        if (!w.settings.javaScriptEnabled) { report.text = base + "Page timings unavailable with JavaScript disabled."; return }
        w.evaluateJavascript("""(function(){try {
            var n=performance.getEntriesByType('navigation')[0];
            if(!n)return JSON.stringify({error:'Navigation timing unavailable'});
            var r=performance.getEntriesByType('resource');
            var f=performance.getEntriesByName('first-contentful-paint')[0];
            return JSON.stringify({dns:n.domainLookupEnd-n.domainLookupStart,connect:n.connectEnd-n.connectStart,
                server:n.responseStart-n.requestStart,download:n.responseEnd-n.responseStart,
                dom:n.domContentLoadedEventEnd,load:n.loadEventEnd,fcp:f?f.startTime:null,
                count:r.length,bytes:r.reduce(function(s,x){return s+(x.transferSize||0)},0),
                slow:r.slice().sort(function(a,b){return b.duration-a.duration}).slice(0,5).map(function(x){
                    var u=new URL(x.name);return {host:u.hostname,ms:x.duration};})});
            }catch(e){return JSON.stringify({error:'Page timing unavailable'})}})()""") { raw ->
            if (!d.isShowing) return@evaluateJavascript
            if (w.url != expected) { report.text = "Page changed. Reopen the inspector."; return@evaluateJavascript }
            try {
                val decoded = JSONArray("[" + raw.take(50000) + "]").optString(0)
                val j = JSONObject(decoded)
                if (j.has("error")) { report.text = base + "Navigation timing unavailable."; return@evaluateJavascript }
                fun ms(k: String): String { val v = j.optDouble(k, -1.0); return if (v.isFinite() && v >= 0) "${v.toLong()} ms" else "unavailable" }
                val slow = j.optJSONArray("slow") ?: JSONArray()
                val items = (0 until minOf(5, slow.length())).joinToString("\n") { i -> val x = slow.getJSONObject(i); "• ${x.optString("host").take(120)} · ${x.optDouble("ms").toLong()} ms" }
                report.text = base + "DNS: ${ms("dns")}\nConnection (includes TLS): ${ms("connect")}\nRequest to first byte: ${ms("server")}\nDocument download: ${ms("download")}\nDOM ready: ${ms("dom")}\nLoad event: ${ms("load")}\nFirst contentful paint: ${ms("fcp")}\n\n" +
                    "Resource timing entries: ${j.optInt("count")}\nReported resource transfer: ${j.optLong("bytes") / 1024} KiB\n\nSlowest observed resources\n$items\n\n" +
                    "Timings come from the page and may be altered by it. Zero can mean a reused connection/cache or an event still pending. Cross-origin sizes may be hidden; counts and bytes are incomplete. Dynamic content can continue after load. Native first-visible is not FCP. No estimated time saved is claimed."
            } catch (_: Exception) { report.text = base + "Navigation timing unavailable." }
        }
    }
    private fun showSettings() {
        sheet("Settings", listOf("Make Aether your default browser" to { defaultBrowser() }, "Clear browsing data" to { clearData() }, "About Aether One 0.4.0" to { AlertDialog.Builder(this).setTitle("Aether One 0.4.0").setMessage("A native Android browser powered by your installed Android System WebView.\n\nHTTPS-first navigation. No app analytics. Bookmarks and history are stored on this device. Websites and your chosen search engine may collect data.\n\nPrototype build: camera/microphone, private browsing and password management are not included.").setPositiveButton("Done", null).show() }))
    }
    private fun defaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) { val role = getSystemService(RoleManager::class.java); if (role.isRoleAvailable(RoleManager.ROLE_BROWSER) && !role.isRoleHeld(RoleManager.ROLE_BROWSER)) startActivityForResult(role.createRequestRoleIntent(RoleManager.ROLE_BROWSER), 402) else toast("Aether is already your default browser") }
            else startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        } catch (_: Exception) { toast("Choose Aether in Android Settings → Default apps → Browser") }
    }
    private fun showSaved(title: String, key: String) {
        val values = readList(key)
        val dialog = bottomDialog(); val content = sheetBase(title, if (values.isEmpty()) "Nothing here yet." else "${values.size} saved links · hold a link to remove it")
        val scroll = ScrollView(this); val rows = column()
        values.forEach { url -> rows.addView(homeLink(host(url), url) { dialog.dismiss(); navigate(url) }.apply {
            setOnLongClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Remove this link?").setMessage(host(url)).setPositiveButton("Remove") { _, _ -> val list = readList(key); list.remove(url); writeList(key, list); dialog.dismiss(); showSaved(title, key) }.setNegativeButton("Cancel", null).show(); true }
        }, LinearLayout.LayoutParams(-1, 64.dp).apply { bottomMargin = 8.dp }) }
        scroll.addView(rows); content.addView(scroll, LinearLayout.LayoutParams(-1, minOf(380.dp, maxOf(64.dp, values.size * 72.dp))))
        dialog.setContentView(content); showBottom(dialog)
    }
    private fun clearData() {
        AlertDialog.Builder(this).setTitle("Clear browsing data?").setMessage("Closes open pages and removes cookies, site storage, cache, history and saved sessions. Your bookmarks stay saved. You will be signed out of websites.").setPositiveButton("Clear data") { _, _ ->
            tabs.forEach { it.web?.let { web -> (web.parent as? ViewGroup)?.removeView(web); web.stopLoading(); web.clearCache(true); web.clearHistory(); web.destroy() }; it.web = null }
            tabs.clear(); active = -1
            CookieManager.getInstance().removeAllCookies { CookieManager.getInstance().flush() }
            WebStorage.getInstance().deleteAllData(); WebViewDatabase.getInstance(this).clearHttpAuthUsernamePassword()
            cancelPreloadUnless(null); historyCache = null
            uiHandler.removeCallbacks(sessionWriter)
            prefs.edit().remove("history").remove("session").apply(); newTab(); toast("Browsing data cleared")
        }.setNegativeButton("Cancel", null).show()
    }
    private fun connectionInfo() {
        val url = currentPage()?.url ?: HOME
        AlertDialog.Builder(this).setTitle(if (url == HOME) "Your Aether start page" else "HTTPS connection").setMessage(if (url == HOME) "This start page is part of the app." else "${host(url)}\n\nHTTPS encrypts the connection. It does not guarantee that a website is trustworthy.").setPositiveButton("Done", null).show()
    }
    private fun readList(key: String): MutableList<String> = try { val a = JSONArray(prefs.getString(key, "[]")); MutableList(a.length()) { a.getString(it) } } catch (_: Exception) { mutableListOf() }
    private fun writeList(key: String, values: List<String>) { if (key == "history") historyCache = values.toMutableList(); prefs.edit().putString(key, JSONArray(values).toString()).apply() }
    private fun saveHistory(url: String) {
        val list = historyCache ?: readList("history").also { historyCache = it }
        list.remove(url); list.add(0, url); while (list.size > 200) list.removeAt(list.lastIndex)
        writeList("history", list)
    }
    private fun saveSession() { if (!restoring) { uiHandler.removeCallbacks(sessionWriter); uiHandler.postDelayed(sessionWriter, 300) } }
    private fun persistSession() {
        if (restoring) return
        val session = JSONArray(); tabs.forEach { session.put(JSONObject().put("url", it.url).put("title", it.title)) }
        prefs.edit().putString("session", session.toString()).putInt("active", active).apply()
    }
    private fun host(url: String) = Uri.parse(url).host?.removePrefix("www.") ?: url
    private fun hideKeyboard() { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0) }
    private fun closeFind() { if (::findBar.isInitialized) { findBar.visibility = View.GONE; findResult.text = ""; current()?.clearMatches() } }
    private fun copy(value: String) { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Link", value)); toast("Link copied") }
    private fun share(value: String) { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, value) }, "Share link")) }
    private fun toast(value: String) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show() }
    private fun hideVideo() {
        customVideo?.let { (it.parent as? ViewGroup)?.removeView(it) }; customVideo = null
        customVideoCallback?.onCustomViewHidden(); customVideoCallback = null
        if (Build.VERSION.SDK_INT >= 30) window.insetsController?.show(WindowInsets.Type.systemBars())
    }
    private fun handleIntent(intent: Intent?) { intent?.dataString?.takeIf { isWebUrl(it) }?.let { newTab(it) } }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(request: Int, result: Int, data: Intent?) {
        super.onActivityResult(request, result, data)
        if (request == FILE_PICK) { val uris = if (result == RESULT_OK) data?.clipData?.let { c -> Array(c.itemCount) { c.getItemAt(it).uri } } ?: data?.data?.let { arrayOf(it) } else null; fileCallback?.onReceiveValue(uris); fileCallback = null }
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when { customVideo != null -> hideVideo(); findBar.visibility == View.VISIBLE -> closeFind(); currentPage()?.url != HOME -> { if (current()?.canGoBack() == true) current()?.goBack() else home() }; else -> super.onBackPressed() }
    }
    override fun onPause() { cancelPreloadUnless(null); uiHandler.removeCallbacks(sessionWriter); persistSession(); current()?.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); if (currentPage()?.url != HOME) current()?.onResume() else if (::root.isInitialized) root.post { if (!isFinishing && !isDestroyed) prepareHomePreload() } }
    override fun onDestroy() { cancelPreloadUnless(null); uiHandler.removeCallbacksAndMessages(null); startupExecutor.shutdown(); fileCallback?.onReceiveValue(null); fileCallback = null; tabs.forEach { it.web?.let { w -> (w.parent as? ViewGroup)?.removeView(w); w.destroy() } }; super.onDestroy() }

    private fun startEngine() {
        try {
            WebViewCompat.startUpWebView(applicationContext,
                WebViewStartUpConfig.Builder(startupExecutor).build(),
                object : WebViewOutcomeReceiver<WebViewStartUpResult, WebViewStartupException> {
                    override fun onResult(result: WebViewStartUpResult) {
                        engineReady = true; preloadStatus = "Engine ready"; startupExecutor.shutdown()
                        uiHandler.post {
                            if (isFinishing || isDestroyed || !::root.isInitialized) return@post
                            val page = currentPage()
                            if (page?.url == HOME && page.web == null) webFor(page)
                            prepareHomePreload(); updateSpeedLabel()
                        }
                    }
                    override fun onError(error: WebViewStartupException) {
                        preloadStatus = "Standard startup"; startupExecutor.shutdown()
                        if (!isFinishing && !isDestroyed) updateSpeedLabel()
                    }
                })
        } catch (_: RuntimeException) { preloadStatus = "Standard startup"; startupExecutor.shutdown() }
    }
    private fun prepareHomePreload() {
        val page = currentPage() ?: return
        if (!engineReady || page.url != HOME || isFinishing || isDestroyed) return
        val web = webFor(page)
        if (!prefs.getBoolean("preload", true)) { preloadStatus = "Engine ready · preload off"; updateSpeedLabel(); return }
        val connection = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connection.isActiveNetworkMetered || connection.activeNetwork == null) { preloadStatus = "Engine ready · preload waits for Wi-Fi"; updateSpeedLabel(); return }
        if (web.url != null && web.url != "about:blank") { preloadStatus = "Previous page kept in memory"; updateSpeedLabel(); return }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PRERENDER_WITH_URL)) { preloadStatus = "Engine ready · page preload unavailable"; updateSpeedLabel(); return }
        if (preloadOwner === page && preloadUrl != null) return
        cancelPreloadUnless(null)
        val url = "https://www.google.com"
        applySiteSettings(page, url)
        val signal = CancellationSignal(); preloadSignal = signal; preloadOwner = page; preloadUrl = url
        web.settings.offscreenPreRaster = true
        if (web.parent == null) { web.visibility = View.INVISIBLE; holder.addView(web, 0, FrameLayout.LayoutParams(-1, -1)); web.onResume() }
        preloadStatus = "Instant Open preparing Google · Wi-Fi"; updateSpeedLabel()
        try {
            WebViewCompat.prerenderUrlAsync(web, url, signal, uiExecutor, object : PrerenderOperationCallback {
                override fun onPrerenderActivated() {
                    page.preloaded = true; preloadSignal = null; preloadOwner = null; preloadUrl = null
                    if (page === currentPage()) updateSpeedLabel()
                }
                override fun onError(exception: PrerenderException) {
                    if (preloadSignal === signal) {
                        preloadSignal = null; preloadOwner = null; preloadUrl = null; preloadStatus = "Engine ready · standard page loading"
                        if (!isFinishing && !isDestroyed) updateSpeedLabel()
                    }
                }
            })
        } catch (_: RuntimeException) { cancelPreloadUnless(null); preloadStatus = "Engine ready · standard page loading"; updateSpeedLabel() }
    }
    private fun cancelPreloadUnless(url: String?) {
        if (url != null && url == preloadUrl && preloadOwner === currentPage()) return
        val owner = preloadOwner
        val signal = preloadSignal
        preloadSignal = null; preloadOwner = null; preloadUrl = null
        signal?.cancel()
        owner?.web?.settings?.offscreenPreRaster = false
    }
    private fun updateSpeedLabel() {
        if (!::speedLabel.isInitialized) return
        val p = currentPage()
        val value = when {
            p == null || p.url == HOME -> preloadStatus
            p.reused -> "Live page reused · no network reload"
            p.visibleMs > 0 -> "First visible ${p.visibleMs} ms" + (if (p.completeMs > 0) " · loaded ${p.completeMs} ms" else " · still loading") + (if (p.preloaded) " · preloaded" else "")
            p.completeMs > 0 -> "Loaded ${p.completeMs} ms" + (if (p.preloaded) " · preloaded" else "")
            else -> "Loading" + (if (lite) " · Lite images off" else "")
        }
        if (speedLabel.text.toString() != value) speedLabel.text = value
    }
    private fun speedSettings() {
        val preload = prefs.getBoolean("preload", true)
        sheet("Speed settings", listOf(
            "Instant Open · " + (if (preload) "on (Wi-Fi)" else "off") to {
                prefs.edit().putBoolean("preload", !preload).apply()
                if (preload) { cancelPreloadUnless(null); preloadStatus = "Engine ready · preload off"; updateSpeedLabel() } else prepareHomePreload()
                toast(if (preload) "Preload off" else "Google quick link will prepare on Wi-Fi (uses data)")
            },
            "Lite mode · " + (if (lite) "on" else "off") to {
                lite = !lite; prefs.edit().putBoolean("lite", lite).apply()
                cancelPreloadUnless(null)
                tabs.forEach { applySiteSettings(it, it.url) }
                if (currentPage()?.url != HOME) current()?.reload()
                toast(if (lite) "Network images off; text and scripts still load" else "Images on")
            },
            "How loading times work" to {
                AlertDialog.Builder(this).setTitle("Real loading times").setMessage("""First visible measures from navigation request until WebView reports that new page content is ready to show. Loaded measures until its page-finished callback. They are different milestones.

Instant Open prepares only the Google home quick link on unmetered networks. The current WebView must support prerendering. Extra network data and memory are used.

Back/forward cache is enabled when your WebView supports it. Cache eligibility depends on each website. Reload always requests a refresh.""").setPositiveButton("Done", null).show()
            }
        ))
    }

    private inner class IconView(var kind: String) : View(this@MainActivity) {
        var color = ink
        var badge = ""
        private val pen = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = minOf(width, height) * .5f
            canvas.save(); canvas.translate((width-s)/2, (height-s)/2); canvas.scale(s/24f, s/24f)
            pen.color = color; pen.style = Paint.Style.STROKE; pen.strokeWidth = 1.75f; pen.strokeCap = Paint.Cap.ROUND; pen.strokeJoin = Paint.Join.ROUND
            fun path(vararg points: Float) { val p = Path(); p.moveTo(points[0], points[1]); for (i in 2 until points.size step 2) p.lineTo(points[i], points[i+1]); canvas.drawPath(p, pen) }
            fun l(a: Float,b: Float,c: Float,d: Float) { canvas.drawLine(a,b,c,d,pen) }
            when (kind) {
                "brand" -> { pen.color = mint; path(4f,19f,12f,3f,20f,19f); path(8f,15f,16f,15f); pen.strokeWidth = 1.3f; canvas.drawArc(2f,6f,22f,22f,10f,145f,false,pen) }
                "back" -> path(15f,5f,8f,12f,15f,19f)
                "forward" -> { path(9f,5f,16f,12f,9f,19f) }
                "up" -> path(6f,15f,12f,9f,18f,15f)
                "down" -> path(6f,9f,12f,15f,18f,9f)
                "close" -> { l(6f,6f,18f,18f); l(6f,18f,18f,6f) }
                "plus" -> { l(12f,5f,12f,19f); l(5f,12f,19f,12f) }
                "home" -> { path(3f,11f,12f,4f,21f,11f); path(6f,10f,6f,20f,10f,20f,10f,14f,14f,14f,14f,20f,18f,20f,18f,10f) }
                "search" -> { canvas.drawCircle(10.5f,10.5f,6f,pen); l(15f,15f,20f,20f) }
                "reload" -> { canvas.drawArc(5f,5f,19f,19f,40f,280f,false,pen); path(15f,3f,19f,6f,15f,9f) }
                "tabs" -> { canvas.drawRoundRect(4f,3f,20f,21f,4f,4f,pen); pen.style = Paint.Style.FILL; pen.textSize = if (badge.length>1) 9f else 11f; pen.typeface = Typeface.DEFAULT_BOLD; pen.textAlign = Paint.Align.CENTER; canvas.drawText(badge,12f,16f,pen) }
                "menu" -> { l(5f,7f,19f,7f); l(5f,12f,19f,12f); l(5f,17f,14f,17f) }
                "lock" -> { canvas.drawRoundRect(5f,10f,19f,21f,3f,3f,pen); canvas.drawArc(8f,3f,16f,16f,180f,180f,false,pen); l(12f,14f,12f,17f) }
                "star" -> path(12f,3f,14.8f,8.7f,21f,9.7f,16.5f,14f,17.6f,20.2f,12f,17.3f,6.4f,20.2f,7.5f,14f,3f,9.7f,9.2f,8.7f,12f,3f)
                "bookmark" -> path(6f,3f,18f,3f,18f,21f,12f,17f,6f,21f,6f,3f)
                "history" -> { canvas.drawCircle(12f,12f,8f,pen); path(12f,7f,12f,12f,16f,14f) }
                "globe" -> { canvas.drawCircle(12f,12f,9f,pen); canvas.drawOval(8f,3f,16f,21f,pen); l(3f,12f,21f,12f) }
                "desktop" -> { canvas.drawRoundRect(3f,4f,21f,17f,2f,2f,pen); l(12f,17f,12f,21f); l(8f,21f,16f,21f) }
                "download" -> { path(12f,3f,12f,15f); path(7f,11f,12f,16f,17f,11f); path(4f,17f,4f,21f,20f,21f,20f,17f) }
                "share" -> { canvas.drawCircle(6f,12f,3f,pen); canvas.drawCircle(18f,5f,3f,pen); canvas.drawCircle(18f,19f,3f,pen); l(9f,10.5f,15f,6.5f); l(9f,13.5f,15f,17.5f) }
                "settings" -> { canvas.drawCircle(12f,12f,7f,pen); canvas.drawCircle(12f,12f,2.5f,pen); l(12f,2f,12f,5f); l(12f,19f,12f,22f); l(2f,12f,5f,12f); l(19f,12f,22f,12f) }
                "play" -> { canvas.drawRoundRect(2f,5f,22f,19f,5f,5f,pen); path(10f,9f,15f,12f,10f,15f,10f,9f) }
                "code" -> { path(8f,7f,3f,12f,8f,17f); path(16f,7f,21f,12f,16f,17f); l(14f,5f,10f,19f) }
            }
            canvas.restore()
        }
    }
}
