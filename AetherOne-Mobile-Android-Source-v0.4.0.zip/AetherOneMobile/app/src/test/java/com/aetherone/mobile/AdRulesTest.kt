package com.aetherone.mobile

import org.junit.Assert.*
import org.junit.Test

class AdRulesTest {
    @Test fun blocksKnownAdHostsAndSubdomains() {
        assertTrue(AdRules.shouldBlock("securepubads.g.doubleclick.net", "example.org"))
        assertTrue(AdRules.shouldBlock("DOUBLECLICK.NET.", "example.org"))
    }
    @Test fun neverUsesSubstringMatching() {
        assertFalse(AdRules.shouldBlock("notdoubleclick.net", "example.org"))
        assertFalse(AdRules.shouldBlock("doubleclick.net.example.org", "news.example.com"))
        assertFalse(AdRules.shouldBlock("images.example.org", "example.org"))
    }
    @Test fun preservesDirectVisitsAndFirstPartySubdomains() {
        assertFalse(AdRules.shouldBlock("doubleclick.net", "doubleclick.net"))
        assertFalse(AdRules.shouldBlock("secure.doubleclick.net", "doubleclick.net"))
        assertFalse(AdRules.shouldBlock(null, "example.org"))
        assertFalse(AdRules.shouldBlock("doubleclick.net", ""))
    }
}
