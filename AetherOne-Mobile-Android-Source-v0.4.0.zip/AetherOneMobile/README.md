# Aether One Mobile 0.4.0

Adds local host-based ad/tracker blocking, a global switch, exact-host exceptions, site JavaScript/images/desktop settings, and Loading Inspector.

Filtering runs in shouldInterceptRequest without fetching resources itself. Main-frame navigations and visited-host subresources are protected. Immutable suffix-matched host rules avoid substring false positives. Atomic tab counters are diagnostic, not byte or time-saved estimates. No remote rule updater or browsing telemetry.

Limits: built-in host list is not a full EasyList parser. First-party ads, inline ads, service worker traffic, blob resources, and subsequent redirects can escape filtering. Filtering can break third-party functionality; use a per-site exception or turn it off. Counters only cover intercepted requests. Controls apply to exact hosts and require Apply & reload; global ad switch affects new requests immediately.

Loading Inspector reads PerformanceNavigationTiming and ResourceTiming on demand through evaluateJavascript, without a native JavaScript bridge. Reports DNS, connection, request-to-first-byte, document download, DOM/load milestones, FCP when available and five slowest reported resource hosts (no query strings). Page measurements are untrusted. Cross-origin transfer sizes may be hidden, cache/reused connections may report zero, load events may be pending and dynamic work can continue later. Inspector does not identify OS scheduling, extensions or promise complete network capture.

Preserves 0.3 engine startup, feature-guarded BackForwardCache, configurable Google home prerender on unmetered networks, live-page reuse and debounced local session writes. Full-content mode keeps images and JavaScript on by default. Lite mode is optional.

## Build
JDK 17, Gradle 8.11.1, AGP 8.10.1, compile SDK 36, target SDK 35, minimum SDK 26. CI runs host-rule unit tests, assembleDebug and Android lint.

## Installation
This remains a development-signed APK. CI does not retain its generated debug private key. Certificates differ between runs; it cannot update earlier installations in place. Do not uninstall without considering saved app data. Permanent protected release signing remains to be configured. No claim of instant loading or measured speedup on an actual phone.
