using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.Web.WebView2.Core;

namespace AetherOnePC;
public sealed partial class BrowserForm
{
    private string FaviconPath(string url)=>Path.Combine(profilePath,"Favicons",Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(Policy.Host(url))))+".png");
    private Bitmap? LoadCachedFavicon(string url){try{var path=FaviconPath(url);if(File.Exists(path)){using var original=Image.FromFile(path);return new Bitmap(original,16,16);}}catch{}return null;}
    private void CacheFavicon(string url,Bitmap icon){if(!IsWeb(url))return;try{using var memory=new MemoryStream();icon.Save(memory,System.Drawing.Imaging.ImageFormat.Png);var bytes=memory.ToArray();var path=FaviconPath(url);_=Task.Run(()=>{try{Directory.CreateDirectory(Path.GetDirectoryName(path)!);if(File.Exists(path)||Directory.EnumerateFiles(Path.GetDirectoryName(path)!,"*.png").Take(257).Count()<256)File.WriteAllBytes(path,bytes);}catch{}});}catch{}}
    private HorizontalTabs? horizontalTabs;
    private FavoritesBar? favorites;
    private FlowLayoutPanel? extensionPins;
    private TableLayoutPanel? browserToolbar;
    private string extensionPinKey = "";
    private SuggestionWindow? suggestions;
    private readonly System.Windows.Forms.Timer suggestTimer = new(){Interval=110};
    private readonly List<Suggestion> suggestionItems=[];
    private sealed record Suggestion(string Title,string Detail,string Value,BrowserTab? Tab=null);
    [DllImport("user32.dll")] private static extern bool ReleaseCapture();
    [DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr hwnd,int msg,IntPtr w,IntPtr l);
    protected override void WndProc(ref Message m)
    {
        if(m.Msg==0x84 && WindowState!=FormWindowState.Maximized){long v=m.LParam.ToInt64();var p=PointToClient(new Point((short)v,(short)(v>>16)));int e=6;bool l=p.X<e,r=p.X>=ClientSize.Width-e,t=p.Y<e,b=p.Y>=ClientSize.Height-e;
            if(l||r||t||b){m.Result=(IntPtr)(t?(l?13:r?14:12):b?(l?16:r?17:15):l?10:11);return;}}
        base.WndProc(ref m);
    }
    private void BuildBrowserChrome()
    {
        FormBorderStyle=FormBorderStyle.None;MaximizedBounds=Screen.FromControl(this).WorkingArea;BackColor=Visual.Base;MinimumSize=new Size(860,560);
        var layout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,BackColor=Visual.Base,Padding=new Padding(1)};
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute,36));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,44));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,30));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,19));Controls.Add(layout);
        horizontalTabs=new HorizontalTabs(this){Dock=DockStyle.Fill};layout.Controls.Add(horizontalTabs,0,0);
        var bar=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=14,RowCount=1,BackColor=Visual.Surface,Padding=new Padding(8,3,7,4)};bar.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        for(int i=0;i<14;i++)bar.ColumnStyles.Add(new ColumnStyle(i==4?SizeType.Percent:SizeType.Absolute,i==4?100:i==12?0:i==13?76:32));browserToolbar=bar;
        Button Tool(string glyph,string name,Action run){var b=(ChromeButton)Button("",name,run);b.Glyph=glyph;b.BackColor=Visual.Surface;return b;}
        back=Tool("back","Back · Alt+Left",()=>{if(Current?.Web?.CanGoBack==true)Current.Web.GoBack();});forward=Tool("forward","Forward · Alt+Right",()=>{if(Current?.Web?.CanGoForward==true)Current.Web.GoForward();});reload=Tool("reload","Reload / stop",Reload);
        bar.Controls.Add(back,0,0);bar.Controls.Add(forward,1,0);bar.Controls.Add(reload,2,0);bar.Controls.Add(Tool("home","New tab page",Home),3,0);
        var box=new Panel{Dock=DockStyle.Fill,BackColor=Visual.Card,Padding=new Padding(12,8,10,5),Margin=new Padding(6,0,9,0)};
        address.Font=new Font("Segoe UI",10);address.BackColor=Visual.Card;address.ForeColor=Visual.Text;address.PlaceholderText="";box.Controls.Add(address);
        var addressCue=new Label{Text="Search or enter web address",Dock=DockStyle.Fill,BackColor=Visual.Card,ForeColor=Visual.Muted,Font=new Font("Segoe UI",10)};box.Controls.Add(addressCue);addressCue.BringToFront();
        void Cue(){addressCue.Visible=address.Text.Length==0&&!address.Focused;}addressCue.Click+=(_,_)=>address.Focus();address.TextChanged+=(_,_)=>Cue();address.GotFocus+=(_,_)=>Cue();address.LostFocus+=(_,_)=>Cue();
        bar.Controls.Add(box,4,0);
        address.TextChanged+=(_,_)=>{suggestTimer.Stop();if(address.Focused){suggestTimer.Start();}else suggestions?.Hide();};suggestTimer.Tick+=(_,_)=>{suggestTimer.Stop();ShowSuggestions();};
        address.GotFocus+=(_,_)=>ShowSuggestions();address.LostFocus+=(_,_)=>BeginInvoke((Action)(()=>{if(suggestions?.ContainsFocus!=true)suggestions?.Hide();}));
        address.KeyDown+=(_,e)=>{
            if(e.KeyCode==Keys.Down||e.KeyCode==Keys.Up){e.SuppressKeyPress=true;if(suggestions?.Visible!=true)ShowSuggestions();suggestions?.MoveSelection(e.KeyCode==Keys.Down?1:-1);}
            else if(e.KeyCode==Keys.Escape){suggestions?.Hide();e.SuppressKeyPress=true;}
            else if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;if(suggestions?.Visible==true&&suggestions.SelectedIndex>=0)ChooseSuggestion(suggestions.SelectedIndex);else _=Navigate(address.Text);}
        };
        bar.Controls.Add(Tool("bookmark","Save page · Ctrl+D",Bookmark),5,0);
        bar.Controls.Add(Tool("extensions","Extensions",()=>_=ExtensionsDialog()),6,0);
        bar.Controls.Add(Tool("split","Split screen",()=>_=SplitView()),7,0);
        bar.Controls.Add(Tool("notes","Workspace notes",ToggleNotes),8,0);
        bar.Controls.Add(Tool("download","Downloads · Ctrl+J",Downloads),9,0);
        shield=Tool("shield","Site & privacy controls",SiteDialog);bar.Controls.Add(shield,10,0);bar.Controls.Add(Tool("menu","Browser menu",ShowMenu),11,0);
        var workspace=Button("Spaces ▾","Switch workspace",WorkspaceMenu);workspace.Font=new Font("Segoe UI",9);workspace.BackColor=Visual.Surface;bar.Controls.Add(workspace,13,0);layout.Controls.Add(bar,0,1);
        favorites=new FavoritesBar(this){Dock=DockStyle.Fill,Visible=state.ShowFavorites};layout.Controls.Add(favorites,0,2);if(!state.ShowFavorites)layout.RowStyles[2].Height=0;
        shell=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,BackColor=Visual.Base,Padding=new Padding(0)};
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,0));shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));shell.RowStyles.Add(new RowStyle(SizeType.Percent,100));focusMode=true;
        rail=new WorkspaceRail(this){Dock=DockStyle.Fill,Visible=false};shell.Controls.Add(rail,0,0);
        pageHost=new Panel{Dock=DockStyle.Fill,BackColor=Visual.Surface};pageHost.Controls.Add(tabs);shell.Controls.Add(pageHost,1,0);layout.Controls.Add(shell,0,3);
        var footer=new Panel{Dock=DockStyle.Fill,BackColor=Visual.Surface,Padding=new Padding(10,2,4,0)};status.ForeColor=Visual.Muted;status.Font=new Font("Segoe UI",8);footer.Controls.Add(status);footer.Controls.Add(progress);layout.Controls.Add(footer,0,4);
        extensionPins=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,FlowDirection=FlowDirection.LeftToRight,Margin=Padding.Empty};bar.Controls.Add(extensionPins,12,0);
        LocationChanged+=(_,_)=>suggestions?.Hide();ResizeBegin+=(_,_)=>suggestions?.Hide();
    }
    private void RefreshExtensionPins()
    {
        if(extensionPins==null||browserToolbar==null)return;
        var extensions=state.PinnedExtensions.Where(loadedExtensions.ContainsKey).Select(id=>loadedExtensions[id]).Where(x=>x.IsEnabled).Take(3).ToArray();
        string key=string.Join("|",extensions.Select(x=>x.Id));if(key==extensionPinKey)return;extensionPinKey=key;
        foreach(Control c in extensionPins.Controls.Cast<Control>().ToArray())c.Dispose();extensionPins.Controls.Clear();browserToolbar.ColumnStyles[12].Width=extensions.Length*32;
        foreach(var e in extensions){var extension=e;var button=(ChromeButton)Button("",extension.Name,()=>_=OpenExtensionPage(extension));button.Glyph="notes";button.Dock=DockStyle.None;button.Size=new Size(29,32);button.BackColor=Visual.Surface;button.Margin=new Padding(1,0,1,0);extensionPins.Controls.Add(button);}
    }
    private void ShowBrowserMenu()
    {
        var m=new ContextMenuStrip{BackColor=Visual.Surface,ForeColor=Visual.Text,Font=new Font("Segoe UI",10),ShowImageMargin=false,Padding=new Padding(6)};
        void Item(string text,Action run,string keys=""){var x=new ToolStripMenuItem(text){ShortcutKeyDisplayString=keys,AutoSize=false,Width=290,Height=34};x.Click+=(_,_)=>run();m.Items.Add(x);}
        Item("New tab",()=>NewTab(),"Ctrl+T");Item("Reopen closed tab",ReopenClosed,"Ctrl+Shift+T");m.Items.Add(new ToolStripSeparator());
        Item("Favorites",()=>ShowLinks(false),"Ctrl+B");Item("History",()=>ShowLinks(true),"Ctrl+H");Item("Downloads",Downloads,"Ctrl+J");Item("Extensions",()=>_=ExtensionsDialog());m.Items.Add(new ToolStripSeparator());
        Item("Zoom  − / +",ZoomMenu);Item("Find on page",()=>_=Find(),"Ctrl+F");Item("Print",()=>Current?.Web?.CoreWebView2?.ShowPrintUI(),"Ctrl+P");Item("Split screen",()=>_=SplitView());Item("Site controls",SiteDialog);Item("Ad blocker",BlockerDialog);
        var more=new ToolStripMenuItem("Workspace tools");more.DropDownItems.Add("Command palette",null,(_,_)=>CommandPalette());more.DropDownItems.Add("Read later",null,(_,_)=>ShowReadLater());more.DropDownItems.Add("Save to Read later",null,(_,_)=>SaveReadLater());more.DropDownItems.Add("Notes",null,(_,_)=>ToggleNotes());more.DropDownItems.Add("Vertical tab sidebar",null,(_,_)=>ToggleFocus());more.DropDownItems.Add("Sleep inactive tabs",null,(_,_)=>SleepInactive());more.DropDownItems.Add("Loading Inspector",null,async(_,_)=>await Inspector());m.Items.Add(more);m.Items.Add(new ToolStripSeparator());
        Item("Settings",SettingsDialog);Item("About Aether One",()=>MessageBox.Show(this,"Aether One PC 0.3\nWindows interface · Microsoft WebView2\n\nUnpacked extension support; compatibility depends on WebView2. No app analytics. Data is local to this Windows profile. No sync, isolated private browsing, or dedicated password manager.\n\n"+profilePath,"About Aether One"));m.Show(this,new Point(Math.Max(0,ClientSize.Width-310),78));
    }
    private void ZoomMenu(){var m=new ContextMenuStrip();foreach(var n in new[]{75,90,100,110,125,150}){int zoom=n;m.Items.Add(n+"%",null,(_,_)=>{if(Current?.Web!=null)Current.Web.ZoomFactor=zoom/100.0;});}m.Show(Cursor.Position);}
    private void SettingsDialog()
    {
        using var d=Dialog("Settings",760,540);var flow=new FlowLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(30),FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true};
        flow.Controls.Add(Label("Make Aether yours",23,Visual.Text));flow.Controls.Add(Label("Appearance & browsing",12,Visual.Muted));
        var bar=new CheckBox{Text="Show favorites bar",Checked=state.ShowFavorites,AutoSize=true};bar.CheckedChanged+=(_,_)=>{state.ShowFavorites=bar.Checked;favorites!.Visible=bar.Checked;((TableLayoutPanel)favorites.Parent!).RowStyles[2].Height=bar.Checked?30:0;QueueSave();};flow.Controls.Add(bar);
        var saver=new CheckBox{Text="Memory saver: reduce hidden-page memory target",Checked=state.MemorySaver,AutoSize=true};saver.CheckedChanged+=(_,_)=>{state.MemorySaver=saver.Checked;if(!state.MemorySaver)foreach(var p in pages)RestoreMemoryTarget(p);QueueSave();};flow.Controls.Add(saver);flow.Controls.Add(Label("Keeps page state and scripts running. Reclaiming memory can slow a later return; actual savings depend on the engine. Audio, loading and pinned tabs are excluded.",10,Visual.Muted));
        foreach(var entry in new[]{("Extensions",(Action)(()=>_=ExtensionsDialog())),("Ad & tracker blocking",(Action)BlockerDialog),("Site permissions and content",(Action)SiteDialog),("Bookmarks",(Action)(()=>ShowLinks(false))),("History",(Action)(()=>ShowLinks(true)))}){var b=Button(entry.Item1,entry.Item1,()=>{d.Close();entry.Item2();});b.Dock=DockStyle.None;b.Size=new Size(500,42);flow.Controls.Add(b);}
        flow.Controls.Add(Label("Address suggestions are local. Typed text is sent to the selected search engine only when you submit a search.\nProfile and site data stay in your existing AetherOnePC profile.",11,Visual.Muted));d.Controls.Add(flow);d.ShowDialog(this);
    }
    private void ShowSuggestions()
    {
        if(!address.Focused||closing)return;string q=address.Text.Trim();suggestionItems.Clear();
        if(q.Length>0){bool url=IsWeb(q)||(!q.Any(char.IsWhiteSpace)&&q.Contains('.'));suggestionItems.Add(new Suggestion(url?"Open "+q:"Search for “"+q+"”",url?"Web address":"Google search",q));}
        bool Match(string title,string url)=>q.Length==0||title.Contains(q,StringComparison.OrdinalIgnoreCase)||url.Contains(q,StringComparison.OrdinalIgnoreCase);
        var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var p in pages.Where(p=>!p.AtHome&&Match(p.Title,p.Url)).Take(4)){if(seen.Add(p.Url))suggestionItems.Add(new Suggestion(p.Title,"Switch to tab · "+p.Url,p.Url,p));}
        foreach(var x in state.Bookmarks.Concat(state.ReadLater).Concat(state.History).Where(x=>Match(x.Title,x.Url))){if(seen.Add(x.Url))suggestionItems.Add(new Suggestion(string.IsNullOrWhiteSpace(x.Title)?Policy.Host(x.Url):x.Title,x.Url,x.Url));if(suggestionItems.Count>=8)break;}
        if(suggestionItems.Count==0){suggestions?.Hide();return;}
        suggestions??=new SuggestionWindow(this);suggestions.Items=suggestionItems.Select(x=>(x.Title,x.Detail)).ToList();suggestions.SelectedIndex=-1;suggestions.Bounds=new Rectangle(address.Parent!.PointToScreen(new Point(0,address.Parent.Height)),new Size(address.Parent.Width,Math.Min(8,suggestionItems.Count)*52+8));if(!suggestions.Visible)suggestions.Show(this);suggestions.Invalidate();
    }
    private void ChooseSuggestion(int index){if(index<0||index>=suggestionItems.Count)return;var x=suggestionItems[index];suggestions?.Hide();if(x.Tab!=null){SelectPage(x.Tab);x.Tab.Web?.Focus();Sync();}else _=Navigate(x.Value);}
    private sealed class SuggestionWindow:Form
    {
        private readonly BrowserForm owner;public List<(string Title,string Detail)> Items=[];public int SelectedIndex=-1;
        protected override bool ShowWithoutActivation=>true;
        protected override CreateParams CreateParams { get {var p=base.CreateParams;p.ExStyle|=0x08000000;return p;} }
        public SuggestionWindow(BrowserForm o){owner=o;FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;DoubleBuffered=true;BackColor=Visual.Card;}
        public void MoveSelection(int by){SelectedIndex=Math.Clamp(SelectedIndex+by,0,Items.Count-1);Invalidate();}
        protected override void OnPaint(PaintEventArgs e){for(int i=0;i<Items.Count;i++){var r=new Rectangle(3,4+i*52,Width-6,50);if(i==SelectedIndex)Visual.Round(e.Graphics,r,Color.FromArgb(63,68,80),6);Visual.Icon(e.Graphics,"search",new Rectangle(15,r.Y+16,17,17),Visual.Muted);Visual.TextAt(e.Graphics,Items[i].Title,new Rectangle(43,r.Y+5,Width-55,23),10,Visual.Text);Visual.TextAt(e.Graphics,Items[i].Detail,new Rectangle(44,r.Y+29,Width-56,18),8,Visual.Muted);}}
        protected override void OnMouseMove(MouseEventArgs e){int i=(e.Y-4)/52;if(i>=0&&i<Items.Count&&i!=SelectedIndex){SelectedIndex=i;Invalidate();}base.OnMouseMove(e);}
        protected override void OnMouseDown(MouseEventArgs e){int i=(e.Y-4)/52;if(i>=0&&i<Items.Count)owner.ChooseSuggestion(i);base.OnMouseDown(e);}
    }
    private sealed class HorizontalTabs:Control
    {
        private readonly BrowserForm owner;private readonly List<(Rectangle Rect,BrowserTab Page)> hits=[];private int first;private readonly ToolTip tip=new();private BrowserTab? hovering;
        public HorizontalTabs(BrowserForm o){owner=o;DoubleBuffered=true;BackColor=Visual.Base;AccessibleName="Horizontal browser tabs";}
        protected override void OnPaint(PaintEventArgs e)
        {
            var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Visual.Base);hits.Clear();Visual.Icon(g,"brand",new Rectangle(11,8,20,20),Visual.Mint);
            var all=owner.pages.Where(x=>x.Workspace==owner.state.ActiveWorkspace).OrderByDescending(x=>x.Pinned).ToArray();int available=Math.Max(100,Width-223);int tw=Math.Clamp(available/Math.Max(1,all.Length),110,224);int slots=Math.Max(1,available/tw);int active=Array.IndexOf(all,owner.Current);if(active<first)first=Math.Max(0,active);if(active>=first+slots)first=active-slots+1;first=Math.Clamp(first,0,Math.Max(0,all.Length-slots));
            int x=40;foreach(var p in all.Skip(first).Take(slots)){var r=new Rectangle(x,3,tw-3,33);if(p==owner.Current)Visual.Round(g,r,Visual.Surface,8);
                if(p.Favicon!=null&&!p.AtHome)g.DrawImage(p.Favicon,new Rectangle(x+11,11,16,16));else Visual.Icon(g,p.AtHome?"brand":p.Sleeping?"sleep":"clock",new Rectangle(x+11,11,16,16),p==owner.Current?Visual.Mint:Visual.Muted);
                Visual.TextAt(g,p.AtHome?"New tab":p.Title,new Rectangle(x+33,10,tw-61,23),9,p==owner.Current?Visual.Text:Visual.Muted);
                if(p.Audible)Visual.TextAt(g,"♪",new Rectangle(x+tw-45,9,15,20),10,Visual.Mint);
                Visual.Icon(g,"close",new Rectangle(x+tw-24,13,12,12),Visual.Muted);hits.Add((r,p));x+=tw;}
            Visual.Icon(g,"plus",new Rectangle(Math.Min(x+8,Width-166),11,17,17),Visual.Muted);
            if(all.Length>slots)Visual.Icon(g,"down",new Rectangle(Width-163,12,14,14),Visual.Muted);
            using var pen=new Pen(Visual.Text,1);g.DrawLine(pen,Width-121,19,Width-111,19);g.DrawRectangle(pen,Width-78,14,9,9);Visual.Icon(g,"close",new Rectangle(Width-39,11,17,17),Visual.Text);
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);if(e.X>Width-48){owner.Close();return;}if(e.X>Width-94){owner.WindowState=owner.WindowState==FormWindowState.Maximized?FormWindowState.Normal:FormWindowState.Maximized;return;}if(e.X>Width-140){owner.WindowState=FormWindowState.Minimized;return;}if(e.X<36){owner.WorkspaceMenu();return;}
            foreach(var (r,p) in hits)if(r.Contains(e.Location)){if(e.Button==MouseButtons.Right)owner.TabMenu(p);else if(e.Button==MouseButtons.Middle||e.X>r.Right-24)owner.CloseTab(p);else owner.SelectPage(p);return;}
            int plus=hits.Count>0?hits[^1].Rect.Right+11:48;
            if(Math.Abs(e.X-Math.Min(plus,Width-158))<18){owner.NewTab();return;}
            if(e.X>Width-178){owner.TabSearchMenu();return;}
            if(e.Clicks==2){owner.WindowState=owner.WindowState==FormWindowState.Maximized?FormWindowState.Normal:FormWindowState.Maximized;return;}
            ReleaseCapture();SendMessage(owner.Handle,0xA1,(IntPtr)2,IntPtr.Zero);
        }
        protected override void OnMouseWheel(MouseEventArgs e){first=Math.Max(0,first-(e.Delta>0?1:-1));Invalidate();base.OnMouseWheel(e);}
        protected override void OnMouseMove(MouseEventArgs e){var p=hits.FirstOrDefault(x=>x.Rect.Contains(e.Location)).Page;if(p!=hovering){hovering=p;tip.SetToolTip(this,p==null?"":p.Title+"\n"+p.Url+(p.Sleeping?"\nSleeping":""));}base.OnMouseMove(e);}
        protected override void Dispose(bool disposing){if(disposing)tip.Dispose();base.Dispose(disposing);}
    }
    private void TabSearchMenu(){var m=new ContextMenuStrip{BackColor=Visual.Surface,ForeColor=Visual.Text};foreach(var p in pages){var page=p;m.Items.Add((p.AtHome?"New tab":p.Title)+" · "+p.Workspace,null,(_,_)=>SelectPage(page));}m.Show(Cursor.Position);}
    private sealed class FavoritesBar:Control
    {
        private readonly BrowserForm owner;private readonly List<(Rectangle R,string Url)> hits=[];
        public FavoritesBar(BrowserForm o){owner=o;DoubleBuffered=true;BackColor=Visual.Surface;AccessibleName="Favorites and website shortcuts";Cursor=Cursors.Hand;}
        protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.Clear(Visual.Surface);hits.Clear();var items=owner.state.Bookmarks.Count>0?owner.state.Bookmarks.Take(8).ToArray():new[]{new SavedLink{Title="Google",Url="https://www.google.com/"},new SavedLink{Title="YouTube",Url="https://www.youtube.com/"},new SavedLink{Title="Wikipedia",Url="https://www.wikipedia.org/"},new SavedLink{Title="GitHub",Url="https://github.com/"}};int x=16;foreach(var p in items){int width=Math.Min(155,Math.Max(85,TextRenderer.MeasureText(p.Title,Font).Width+35));if(x+width>Width-30)break;var tab=owner.pages.FirstOrDefault(t=>Policy.Host(t.Url)==Policy.Host(p.Url)&&t.Favicon!=null);if(tab?.Favicon!=null)g.DrawImage(tab.Favicon,new Rectangle(x,7,16,16));else{Visual.Round(g,new Rectangle(x,6,18,18),Visual.Card,4);Visual.TextAt(g,p.Title.FirstOrDefault().ToString().ToUpperInvariant(),new Rectangle(x+1,6,17,19),8,Visual.Mint,true);}Visual.TextAt(g,p.Title,new Rectangle(x+24,7,width-29,20),8,Visual.Text);hits.Add((new Rectangle(x,0,width,Height),p.Url));x+=width;}}
        protected override void OnMouseDown(MouseEventArgs e){foreach(var (r,url)in hits)if(r.Contains(e.Location)){if(e.Button==MouseButtons.Middle)owner.NewTab(url);else _=owner.Navigate(url);return;}base.OnMouseDown(e);}
    }
    private sealed class StartPage:Control
    {
        private readonly BrowserForm owner;private readonly BrowserTab page;private readonly TextBox search;private readonly Label cue;private readonly List<(Rectangle R,Action Run)> hits=[];
        public StartPage(BrowserForm o,BrowserTab p){owner=o;page=p;DoubleBuffered=true;BackColor=Visual.Surface;
            search=new TextBox{BorderStyle=BorderStyle.None,Font=new Font("Segoe UI",13),ForeColor=Visual.Text,BackColor=Visual.Card};cue=new Label{Text="Search the web",ForeColor=Visual.Muted,BackColor=Visual.Card,Font=new Font("Segoe UI",11),Cursor=Cursors.IBeam};Controls.Add(search);Controls.Add(cue);cue.BringToFront();
            void Place(){int width=Math.Min(640,Width-100);search.Bounds=new Rectangle((Width-width)/2+43,222,width-65,27);cue.Bounds=new Rectangle(search.Left,224,search.Width,25);cue.Visible=search.Text.Length==0&&!search.Focused;Invalidate();}
            Resize+=(_,_)=>Place();cue.Click+=(_,_)=>search.Focus();search.TextChanged+=(_,_)=>Place();search.GotFocus+=(_,_)=>Place();search.LostFocus+=(_,_)=>Place();search.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;_=owner.Navigate(search.Text,page);}};AccessibleName="Aether new tab page";
        }
        protected override void OnPaint(PaintEventArgs e){var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Visual.Surface);hits.Clear();int width=Math.Min(640,Width-100),left=(Width-width)/2;
            Visual.Icon(g,"brand",new Rectangle(Width/2-17,71,34,34),Visual.Mint);using(var heading=new Font("Segoe UI",30,FontStyle.Bold))TextRenderer.DrawText(g,"Aether One",heading,new Rectangle(0,123,Width,55),Visual.Text,TextFormatFlags.HorizontalCenter);using(var subtitle=new Font("Segoe UI",10))TextRenderer.DrawText(g,"Your browser. Your space.",subtitle,new Rectangle(0,180,Width,25),Visual.Muted,TextFormatFlags.HorizontalCenter);
            Visual.Round(g,new Rectangle(left,207,width,57),Visual.Card,25,true);Visual.Icon(g,"search",new Rectangle(left+15,226,19,19),Visual.Muted);
            var links=new[]{("Google","G","https://www.google.com/"),("YouTube","▶","https://www.youtube.com/"),("Wikipedia","W","https://www.wikipedia.org/"),("GitHub","⌘","https://github.com/")};int start=Width/2-190;
            for(int i=0;i<4;i++){int x=start+i*100;var r=new Rectangle(x,297,80,88);Visual.Round(g,new Rectangle(x+15,297,50,50),Visual.Card,13);Visual.TextAt(g,links[i].Item2,new Rectangle(x+29,310,40,35),18,Visual.Mint,true);Visual.TextAt(g,links[i].Item1,new Rectangle(x+9,357,85,24),9,Visual.Muted);string url=links[i].Item3;hits.Add((r,()=>_=owner.Navigate(url,page)));}
            if(Height>515){Visual.TextAt(g,"PICK UP WHERE YOU LEFT OFF",new Rectangle(left,426,width,21),8,Visual.Muted,true);int y=461;foreach(var link in owner.state.History.Take(2)){Visual.Icon(g,"clock",new Rectangle(left+3,y+5,16,16),Visual.Muted);Visual.TextAt(g,link.Title,new Rectangle(left+31,y,width-35,24),9,Visual.Text);var saved=link;hits.Add((new Rectangle(left,y,width,30),()=>_=owner.Navigate(saved.Url,page)));y+=35;}if(owner.state.History.Count==0)Visual.TextAt(g,"Recent pages will appear here.",new Rectangle(left,461,width,25),9,Visual.Muted);}
        }
        protected override void OnMouseDown(MouseEventArgs e){foreach(var (r,run)in hits)if(r.Contains(e.Location)){run();return;}base.OnMouseDown(e);}
    }
}
