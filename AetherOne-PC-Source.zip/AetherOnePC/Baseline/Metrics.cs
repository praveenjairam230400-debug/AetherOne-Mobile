using System.Diagnostics;
using System.Text.Json;
namespace AetherOnePC;
public sealed partial class BrowserForm {
    private async Task RunBenchmark(string output,BrowserTab page)
    {
        // Native dashboard and one warmed, blank engine. No remote page or background feed.
        var engineReadyMs = Program.Startup.Elapsed.TotalMilliseconds;
        await Task.Delay(3000);GC.Collect();GC.WaitForPendingFinalizers();
        var proc=Process.GetCurrentProcess();proc.Refresh();var cpu=proc.TotalProcessorTime;var start=Stopwatch.StartNew();await Task.Delay(3000);proc.Refresh();
        File.WriteAllText(Path.Combine(output,"performance.json"),JsonSerializer.Serialize(new{Version="0.1.0",NativeWindowShownMs=shownMs,EngineReadyMs=engineReadyMs,Scenario="Native dashboard with one warmed WebView2, no remote page",RootWorkingSetBytes=proc.WorkingSet64,RootPrivateBytes=proc.PrivateMemorySize64,ManagedBytes=GC.GetTotalMemory(false),IdleRootCpuMs=(proc.TotalProcessorTime-cpu).TotalMilliseconds,SampleMs=start.ElapsedMilliseconds,PageViews=pages.Count(x=>x.Web!=null),NativeControls=CountControls(this),Note="Root process only; WebView2 child processes excluded. Single CI sample, not an end-user benchmark."},new JsonSerializerOptions{WriteIndented=true}));
    }
    private static int CountControls(Control c)=>1+c.Controls.Cast<Control>().Sum(CountControls);
}