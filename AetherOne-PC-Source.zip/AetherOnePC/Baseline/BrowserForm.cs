using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using System.Diagnostics;
using System.Text.Json;

namespace AetherOnePC;

public sealed partial class BrowserForm : Form
{
    private readonly Color bg = Color.FromArgb(11, 17, 25), panel = Color.FromArgb(20, 29, 40), ink = Color.FromArgb(235, 244, 250), mint = Color.FromArgb(113, 231, 201);
    private readonly TabControl tabs = new() { Dock = DockStyle.Fill, Padding = new Point(20, 8) };
    private readonly TextBox address = new() { Dock = DockStyle.Fill, BorderStyle = BorderStyle.None, Font = new Font("Segoe UI", 12), PlaceholderText = "Search or enter an address" };
    private readonly Label status = new() { Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly ProgressBar progress = new() { Dock = DockStyle.Bottom, Height = 3, Visible = false };
    private readonly System.Windows.Forms.Timer saver = new() { Interval = 600 };
    private readonly string profilePath;
    private readonly string statePath;
    private BrowserState state = new();
    private Task<CoreWebView2Environment>? environment;
    private bool closing;
    private readonly bool smoke;
    private double shownMs;
    private readonly List<BrowserTab> pages = [];
    private Button back = null!, forward = null!, reload = null!, shield = null!;
    private BrowserTab? Current => tabs.SelectedTab?.Tag as BrowserTab;
    private sealed class BrowserTab
    {
        public TabPage Container = null!;
        public Panel Home = null!;
        public WebView2? Web;
        public Task? Initialization;
        public string Url = "";
        public string Title = "New tab";
        public bool AtHome = true;
        public bool Loading;
        public int Blocked, Observed;
        public Stopwatch Clock = new();
        public long Finished;
        public string LastError = "";
    }
    public BrowserForm(bool smokeTest = false)
    {
        smoke = smokeTest;
        profilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AetherOnePC", smoke ? "SmokeTest" : "Profile");
        Directory.CreateDirectory(profilePath); statePath = Path.Combine(profilePath, "browser-state.json");
        try { if (!smoke && File.Exists(statePath)) state = JsonSerializer.Deserialize<BrowserState>(File.ReadAllText(statePath)) ?? new(); }
        catch { if (File.Exists(statePath)) File.Copy(statePath, statePath + ".corrupt-" + DateTime.UtcNow.Ticks, true); }
        state.Bookmarks ??= []; state.History ??= []; state.Tabs ??= []; state.Sites ??= [];
        Text = "Aether One"; Width = 1320; Height = 860; MinimumSize = new Size(840, 560);
        Size = new Size(Math.Min(1320, Screen.PrimaryScreen!.WorkingArea.Width - 24), Math.Min(860, Screen.PrimaryScreen.WorkingArea.Height - 24));
        StartPosition = FormStartPosition.CenterScreen; BackColor = bg; ForeColor = ink; Font = new Font("Segoe UI", 10);
        Icon = System.Drawing.Icon.ExtractAssociatedIcon(Environment.ProcessPath!);
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1, BackColor = bg, Padding = new Padding(8) };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
        Controls.Add(layout);
        var toolbar = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 1, ColumnCount = 12, BackColor = bg, Padding = new Padding(0, 6, 0, 6) };
        toolbar.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        for (var i = 0; i < 12; i++) toolbar.ColumnStyles.Add(i == 4 ? new ColumnStyle(SizeType.Percent, 100) : new ColumnStyle(SizeType.Absolute, i >= 7 ? 76 : 43));
        back = Button("←", "Back · Alt+Left", () => { if (Current?.Web?.CanGoBack == true) Current.Web.GoBack(); });
        forward = Button("→", "Forward · Alt+Right", () => { if (Current?.Web?.CanGoForward == true) Current.Web.GoForward(); });
        reload = Button("↻", "Reload / stop · Ctrl+R", Reload);
        toolbar.Controls.Add(back, 0, 0); toolbar.Controls.Add(forward, 1, 0); toolbar.Controls.Add(reload, 2, 0);
        toolbar.Controls.Add(Button("⌂", "Home", Home), 3, 0);
        var box = new Panel { Dock = DockStyle.Fill, BackColor = panel, Padding = new Padding(14, 10, 8, 8) };
        address.BackColor = panel; address.ForeColor = ink;
        address.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; _ = Navigate(address.Text); } };
        box.Controls.Add(address); toolbar.Controls.Add(box, 4, 0);
        toolbar.Controls.Add(Button("Go", "Open address", () => _ = Navigate(address.Text)), 5, 0);
        toolbar.Controls.Add(Button("+", "New tab · Ctrl+T", () => NewTab()), 6, 0);
        toolbar.Controls.Add(Button("Save", "Bookmark · Ctrl+D", Bookmark), 7, 0);
        shield = Button("Shield", "Ad blocker controls", BlockerDialog); toolbar.Controls.Add(shield, 8, 0);
        toolbar.Controls.Add(Button("Site", "Site controls", SiteDialog), 9, 0);
        toolbar.Controls.Add(Button("Inspect", "Loading Inspector", () => _ = Inspector()), 10, 0);
        toolbar.Controls.Add(Button("Menu", "Browser menu", ShowMenu), 11, 0);
        layout.Controls.Add(toolbar, 0, 0); layout.Controls.Add(tabs, 0, 1);
        var footer = new Panel { Dock = DockStyle.Fill, BackColor = bg, Padding = new Padding(8, 3, 8, 0) };
        status.ForeColor = mint; status.Font = new Font("Segoe UI", 9); status.Text = "AETHER ONE  /  Your space to explore";
        footer.Controls.Add(status); footer.Controls.Add(progress); layout.Controls.Add(footer, 0, 2);
        tabs.SelectedIndexChanged += (_, _) => { Sync(); QueueSave(); };
        tabs.MouseDown += (_, e) => { if (e.Button == MouseButtons.Middle) for (var i = 0; i < tabs.TabCount; i++) if (tabs.GetTabRect(i).Contains(e.Location)) { CloseTab(pages.First(p => p.Container == tabs.TabPages[i])); break; } };
        var tabMenu = new ContextMenuStrip(); tabMenu.Items.Add("Close current tab", null, (_, _) => CloseTab(Current)); tabs.ContextMenuStrip = tabMenu;
        saver.Tick += (_, _) => { saver.Stop(); Save(); };
        Shown += async (_, _) =>
        {
            shownMs = Program.Startup.Elapsed.TotalMilliseconds;
            environment = CoreWebView2Environment.CreateAsync(null, Path.Combine(profilePath, "WebView"));
            if (smoke) { await SmokeTest(); return; }
            foreach (var url in state.Tabs.Where(IsWeb).Take(12).ToArray()) NewTab(url, false);
            NewTab();
            try { await environment; var warm = Current; if (!closing && warm != null) await Ensure(warm); if (!closing) status.Text = "Engine ready · Ctrl+L to search · Shield controls ad blocking"; }
            catch (Exception e) { EngineError(e); }
        };
        FormClosing += (_, _) => { Save(); closing = true; saver.Stop(); foreach (var p in pages) p.Web?.Dispose(); };
    }
    private Button Button(string label, string help, Action action)
    {
        var b = new Button { Text = label, AccessibleName = help, Dock = DockStyle.Fill, FlatStyle = FlatStyle.Flat, BackColor = panel, ForeColor = ink, Cursor = Cursors.Hand, Margin = new Padding(2), TabStop = true };
        b.FlatAppearance.BorderSize = 0; new ToolTip().SetToolTip(b, help); b.Click += (_, _) => action(); return b;
    }
    private Label Label(string text, float size, Color color) => new() { Text = text, Font = new Font("Segoe UI", size), ForeColor = color, AutoSize = true, Margin = new Padding(0, 8, 0, 8), MaximumSize = new Size(760, 0) };
    private void NewTab(string? url = null, bool select = true)
    {
        if (pages.Count >= 24) { status.Text = "24 tab limit · close a tab first"; return; }
        var p = new BrowserTab();
        p.Container = new TabPage("New tab") { BackColor = bg, Tag = p };
        p.Home = new Panel { Dock = DockStyle.Fill, BackColor = bg, AutoScroll = true, Padding = new Padding(55, 35, 45, 30) };
        var content = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        content.Controls.Add(Label("A E T H E R   O N E", 13, mint));
        content.Controls.Add(Label("A little space.\nA world to explore.", 36, ink));
        content.Controls.Add(Label("Search, discover and keep your own corner of the web.", 13, Color.LightSlateGray));
        var search = new TextBox { Width = 640, Font = new Font("Segoe UI", 16), PlaceholderText = "Search the web or enter an address", BackColor = panel, ForeColor = ink, BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(0, 28, 0, 20) };
        search.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; _ = Navigate(search.Text, p); } }; content.Controls.Add(search);
        var quick = new FlowLayoutPanel { AutoSize = true, WrapContents = true, MaximumSize = new Size(800, 0) };
        foreach (var link in new[] { ("Google", "https://www.google.com/"), ("YouTube", "https://www.youtube.com/"), ("Wikipedia", "https://www.wikipedia.org/"), ("GitHub", "https://github.com/") })
        {
            var b = Button(link.Item1, "Open " + link.Item1, () => _ = Navigate(link.Item2, p)); b.Dock = DockStyle.None; b.Size = new Size(145, 55); b.Margin = new Padding(0, 0, 12, 12); quick.Controls.Add(b);
        }
        content.Controls.Add(quick);
        content.Controls.Add(Label("BUILT FOR YOUR FLOW", 11, mint));
        content.Controls.Add(Label("Ctrl+T  New tab     Ctrl+L  Address     Ctrl+W  Close tab\nCtrl+D  Bookmark     Ctrl+H  History     Ctrl+J  Downloads", 12, Color.LightSlateGray));
        content.Controls.Add(Label("Local ad filtering is on by default. Use Shield for the global switch\nor Site to allow ads on a particular website. No app analytics.", 12, Color.LightSlateGray));
        p.Home.Controls.Add(content); p.Container.Controls.Add(p.Home); pages.Add(p); tabs.TabPages.Add(p.Container);
        if (select) tabs.SelectedTab = p.Container;
        if (url != null) { p.Url = url; p.Title = Policy.Host(url); p.Container.Text = p.Title; p.AtHome = false; if (select) _ = Navigate(url, p); }
        p.Container.Enter += (_, _) => { if (!p.AtHome && p.Web == null && IsWeb(p.Url)) _ = Navigate(p.Url, p); };
        Sync(); QueueSave();
    }
    private async Task Ensure(BrowserTab p)
    {
        if (p.Initialization != null) { await p.Initialization; return; }
        p.Initialization = Initialize(p); await p.Initialization;
    }
    private async Task Initialize(BrowserTab p)
    {
        var web = new WebView2 { Dock = DockStyle.Fill, DefaultBackgroundColor = Color.White, Visible = false };
        p.Web = web; p.Container.Controls.Add(web);
        try
        {
            environment ??= CoreWebView2Environment.CreateAsync(null, Path.Combine(profilePath, "WebView"));
            await web.EnsureCoreWebView2Async(await environment);
            if (closing || web.IsDisposed) return;
            var core = web.CoreWebView2;
            core.Settings.IsWebMessageEnabled = false; core.Settings.AreHostObjectsAllowed = false;
            core.Settings.IsPasswordAutosaveEnabled = false; core.Settings.IsGeneralAutofillEnabled = false;
            core.Settings.AreBrowserAcceleratorKeysEnabled = true;
            core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
            core.NavigationStarting += (_, e) =>
            {
                if (closing) return;
                if (!IsWeb(e.Uri)) { e.Cancel = true; status.Text = "Only HTTPS web pages are supported"; return; }
                if (e.Uri.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) { e.Cancel = true; _ = Navigate(e.Uri, p); return; }
                p.Url = e.Uri; p.AtHome = false; p.Blocked = 0; p.Observed = 0; p.Finished = 0; p.LastError = ""; p.Loading = true; p.Clock.Restart();
                ApplyPolicy(p); Sync();
            };
            core.WebResourceRequested += (_, e) =>
            {
                if (closing) return;
                var resource = e.Request.Uri; if (!IsWeb(resource)) return;
                var h = Policy.Host(p.Url);
                if (resource == p.Url && e.ResourceContext == CoreWebView2WebResourceContext.Document) return;
                p.Observed++;
                var rule = Rule(h);
                if ((state.BlockAds && rule.BlockAds && Policy.ShouldBlock(Policy.Host(resource), h)) || (!rule.Images && e.ResourceContext == CoreWebView2WebResourceContext.Image))
                {
                    if (e.ResourceContext != CoreWebView2WebResourceContext.Image || rule.Images) p.Blocked++;
                    e.Response = core.Environment.CreateWebResourceResponse(null, 204, "No Content", "Cache-Control: no-store\r\n");
                }
            };
            core.DocumentTitleChanged += (_, _) => { p.Title = core.DocumentTitle; p.Container.Text = Short(p.Title); if (p == Current) Text = p.Title + " — Aether One"; QueueSave(); };
            core.SourceChanged += (_, _) => { if (IsWeb(core.Source)) p.Url = core.Source; Sync(); };
            core.HistoryChanged += (_, _) => Sync();
            core.NavigationCompleted += (_, e) =>
            {
                p.Loading = false; p.Finished = p.Clock.ElapsedMilliseconds;
                if (!e.IsSuccess) p.LastError = e.WebErrorStatus.ToString();
                if (e.IsSuccess && IsWeb(p.Url)) { state.History.RemoveAll(x => x.Url == p.Url); state.History.Insert(0, new SavedLink { Url = p.Url, Title = p.Title }); state.History = state.History.Take(300).ToList(); }
                QueueSave(); Sync();
            };
            core.NewWindowRequested += (_, e) => { e.Handled = true; if (e.IsUserInitiated && IsWeb(e.Uri)) NewTab(e.Uri); else status.Text = "Automatic popup blocked"; };
            core.PermissionRequested += (_, e) =>
            {
                e.State = CoreWebView2PermissionState.Deny;
                if (smoke || !e.IsUserInitiated) return;
                var result = MessageBox.Show(this, $"{Policy.Host(e.Uri)} requests {e.PermissionKind}.\n\nAllow for this request?", "Site permission", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                e.State = result == DialogResult.Yes ? CoreWebView2PermissionState.Allow : CoreWebView2PermissionState.Deny;
                e.SavesInProfile = false;
            };
            core.ServerCertificateErrorDetected += (_, e) => { e.Action = CoreWebView2ServerCertificateErrorAction.Cancel; status.Text = "Connection blocked: certificate validation failed"; };
            core.ProcessFailed += (_, _) => { p.Loading = false; p.LastError = "Page engine stopped. Close this tab and open a new one."; Sync(); };
            core.DownloadStarting += (_, _) => { status.Text = "Download starting · Ctrl+J opens downloads"; };
        }
        catch { p.Initialization = null; p.Web = null; web.Dispose(); throw; }
    }
    private static bool IsWeb(string? s) => Uri.TryCreate(s, UriKind.Absolute, out var u) && (u.Scheme == "https" || u.Scheme == "http") && !string.IsNullOrEmpty(u.Host);
    private SiteRule Rule(string h) => state.Sites.TryGetValue(h, out var r) ? r : new SiteRule();
    private void ApplyPolicy(BrowserTab p)
    {
        if (p.Web?.CoreWebView2 == null) return;
        var r = Rule(Policy.Host(p.Url)); p.Web.CoreWebView2.Settings.IsScriptEnabled = r.JavaScript; p.Web.ZoomFactor = Math.Clamp(r.Zoom, .5, 2.0);
    }
    private async Task Navigate(string raw, BrowserTab? target = null)
    {
        var url = Policy.Resolve(raw); if (url == null) { status.Text = "Enter an HTTPS address or search phrase"; return; }
        var p = target ?? Current; if (p == null) { NewTab(); p = Current!; }
        try
        {
            p.Url = url; await Ensure(p); if (closing || !pages.Contains(p) || p.Web?.CoreWebView2 == null) return;
            var web = p.Web; ApplyPolicy(p); p.AtHome = false; p.Home.Visible = false; web.Visible = true; web.BringToFront();
            if (web.Source?.AbsoluteUri == url && !p.Loading && p.Finished > 0) { Sync(); status.Text = "Live page reused · no navigation request"; return; }
            p.Loading = true; web.CoreWebView2.Navigate(url); address.Parent?.Focus(); Sync(); QueueSave();
        }
        catch (Exception e) { if (!closing && pages.Contains(p)) EngineError(e); }
    }
    private void EngineError(Exception e)
    {
        if (closing || smoke) return;
        MessageBox.Show(this, "The browser engine could not start. Install or repair Microsoft Edge WebView2 Evergreen Runtime from Microsoft's website, then restart Aether One.\n\n" + e.GetType().Name,
            "WebView2 engine unavailable", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    private void Home()
    {
        var p = Current; if (p == null) return;
        p.Web?.CoreWebView2?.Stop(); p.Loading = false; p.AtHome = true; if (p.Web != null) p.Web.Visible = false; p.Home.Visible = true; p.Home.BringToFront(); p.Container.Text = "New tab"; Sync(); QueueSave();
    }
    private void Reload()
    {
        var p = Current; if (p?.Web?.CoreWebView2 == null || p.AtHome) return;
        if (p.Loading) { p.Web.CoreWebView2.Stop(); p.Loading = false; Sync(); } else { ApplyPolicy(p); p.Loading = true; p.Web.Reload(); }
    }
    private void CloseTab(BrowserTab? p)
    {
        if (p == null) return; pages.Remove(p); tabs.TabPages.Remove(p.Container); p.Web?.Dispose(); p.Container.Dispose(); if (pages.Count == 0 && !closing) NewTab(); Sync(); QueueSave();
    }
    private static string Short(string s) => s.Length > 24 ? s[..23] + "…" : string.IsNullOrWhiteSpace(s) ? "Tab" : s;
    private void Sync()
    {
        if (closing) return;
        var p = Current; var web = p?.Web;
        if (!address.Focused) address.Text = p == null || p.AtHome ? "" : p.Url;
        back.Enabled = web?.CanGoBack == true; forward.Enabled = web?.CanGoForward == true;
        reload.Text = p?.Loading == true ? "×" : "↻"; shield.ForeColor = state.BlockAds ? mint : ink;
        progress.Visible = p?.Loading == true; if (progress.Visible) progress.Style = ProgressBarStyle.Marquee;
        Text = p == null || p.AtHome ? "Aether One" : p.Title + " — Aether One";
        status.Text = p == null || p.AtHome ? "AETHER ONE  /  Your space to explore · Engine warms in the background" :
            p.LastError.Length > 0 ? "Page error: " + p.LastError : p.Loading ? "Loading " + Policy.Host(p.Url) : $"{Policy.Host(p.Url)}  ·  navigation completed {p.Finished} ms  ·  {p.Blocked} requests blocked";
    }
    private void QueueSave() { if (!closing) { saver.Stop(); saver.Start(); } }
    private void Save()
    {
        if (smoke) return;
        state.Tabs = pages.Where(x => !x.AtHome && IsWeb(x.Url)).Select(x => x.Url).ToList();
        try { var temp = statePath + ".tmp"; File.WriteAllText(temp, JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true })); File.Move(temp, statePath, true); }
        catch (Exception) { if (!closing) status.Text = "Could not save browser state · check free disk space and folder permissions"; }
    }
    private void Bookmark()
    {
        var p = Current; if (p == null || p.AtHome || !IsWeb(p.Url)) return;
        state.Bookmarks.RemoveAll(x => x.Url == p.Url); state.Bookmarks.Insert(0, new SavedLink { Url = p.Url, Title = p.Title }); QueueSave(); status.Text = "Page saved to bookmarks";
    }
    private Form Dialog(string title, int width = 620, int height = 450)
    {
        return new Form { Text = title, Width = width, Height = height, StartPosition = FormStartPosition.CenterParent, BackColor = bg, ForeColor = ink, Font = Font, MinimizeBox = false, MaximizeBox = false, ShowInTaskbar = false };
    }
    private void BlockerDialog()
    {
        using var d = Dialog("Ad & tracker blocker", 620, 340);
        var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(24), FlowDirection = FlowDirection.TopDown, WrapContents = false };
        var enabled = new CheckBox { Text = "Block known ad and tracker hosts", Checked = state.BlockAds, AutoSize = true, ForeColor = mint, Margin = new Padding(0, 12, 0, 16) };
        enabled.CheckedChanged += (_, _) => { state.BlockAds = enabled.Checked; Sync(); QueueSave(); };
        flow.Controls.Add(enabled);
        flow.Controls.Add(Label("Local filtering: no filtering server or remote rule download.\nChanges affect new requests. Reload to fully apply.\n\nThis is a built-in host list, not full EasyList compatibility.\nFirst-party ads and some worker/redirect traffic may escape it.\nIf a site breaks, allow ads in Site controls or turn Shield off.", 11, ink));
        var b = Button("Reload current page", "Apply blocker change", () => { d.Close(); if (Current?.Web != null && !Current.AtHome) Current.Web.Reload(); }); b.Dock = DockStyle.None; b.Size = new Size(220, 40); flow.Controls.Add(b);
        d.Controls.Add(flow); d.ShowDialog(this);
    }
    private void SiteDialog()
    {
        var p = Current; if (p == null || p.AtHome) { status.Text = "Open a website first"; return; }
        var host = Policy.Host(p.Url); var rule = Rule(host);
        using var d = Dialog("Site controls — " + host, 600, 420);
        var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(25), FlowDirection = FlowDirection.TopDown, WrapContents = false };
        flow.Controls.Add(Label(host + " · exact host settings", 15, mint));
        var ads = new CheckBox { Text = "Ad blocker for this site (requires global Shield on)", Checked = rule.BlockAds, AutoSize = true };
        var js = new CheckBox { Text = "JavaScript · required by many interactive sites", Checked = rule.JavaScript, AutoSize = true };
        var images = new CheckBox { Text = "Images · leave on for full content", Checked = rule.Images, AutoSize = true };
        flow.Controls.Add(ads); flow.Controls.Add(js); flow.Controls.Add(images);
        flow.Controls.Add(Label("Page zoom (%)", 11, ink));
        var zoom = new NumericUpDown { Minimum = 50, Maximum = 200, Increment = 10, Value = (decimal)(Math.Clamp(rule.Zoom, .5, 2.0) * 100), Width = 100 };
        flow.Controls.Add(zoom);
        var apply = Button("Apply & reload", "Save site settings", () =>
        {
            state.Sites[host] = new SiteRule { BlockAds = ads.Checked, JavaScript = js.Checked, Images = images.Checked, Zoom = (double)zoom.Value / 100 };
            foreach (var t in pages.Where(t => Policy.Host(t.Url) == host && t.Web?.CoreWebView2 != null)) { ApplyPolicy(t); if (!t.AtHome) t.Web!.Reload(); }
            QueueSave(); d.Close();
        }); apply.Dock = DockStyle.None; apply.Size = new Size(240, 42); flow.Controls.Add(apply);
        flow.Controls.Add(Label("Permissions prompt only after a site requests them.\nSign-in, audio/video and complex pages may break with scripts off.", 10, Color.LightSlateGray));
        d.Controls.Add(flow); d.ShowDialog(this);
    }
    private void ShowLinks(bool history)
    {
        using var d = Dialog(history ? "History" : "Bookmarks", 850, 560);
        var source = history ? state.History : state.Bookmarks;
        var list = new ListBox { Dock = DockStyle.Fill, BackColor = panel, ForeColor = ink, BorderStyle = BorderStyle.None, Font = Font, DisplayMember = nameof(SavedLink.Title) };
        foreach (var item in source) list.Items.Add(new SavedLink { Title = item.Title + "  —  " + item.Url, Url = item.Url });
        void Open() { if (list.SelectedItem is SavedLink x) { NewTab(x.Url); d.Close(); } }
        list.DoubleClick += (_, _) => Open(); list.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) Open(); };
        var bottom = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 50 };
        var open = Button("Open", "Open selected link", Open); open.Dock = DockStyle.None; open.Size = new Size(100, 40); bottom.Controls.Add(open);
        var remove = Button("Remove selected", "Remove selected link", () => { if (list.SelectedItem is SavedLink x) { source.RemoveAll(s => s.Url == x.Url); list.Items.Remove(x); QueueSave(); } }); remove.Dock = DockStyle.None; remove.Size = new Size(170, 40); bottom.Controls.Add(remove);
        d.Controls.Add(list); d.Controls.Add(bottom); d.ShowDialog(this);
    }
    private async Task Inspector()
    {
        var p = Current; if (p?.Web?.CoreWebView2 == null || p.AtHome) { status.Text = "Open a website first"; return; }
        var url = p.Url;
        var report = $"{Policy.Host(url)}\r\n\r\nNavigation completed callback: {p.Finished} ms\r\nObserved requests: {p.Observed}\r\nBlocked ad/tracker requests: {p.Blocked}\r\n\r\n";
        try
        {
            if (!Rule(Policy.Host(url)).JavaScript) report += "JavaScript disabled: page timing unavailable.";
            else
            {
                var raw = await p.Web.CoreWebView2.ExecuteScriptAsync("""
                    (()=>{try{const n=performance.getEntriesByType('navigation')[0];if(!n)return null;
                    const r=performance.getEntriesByType('resource'),f=performance.getEntriesByName('first-contentful-paint')[0];
                    return {dns:n.domainLookupEnd-n.domainLookupStart,connection:n.connectEnd-n.connectStart,
                    server:n.responseStart-n.requestStart,download:n.responseEnd-n.responseStart,dom:n.domContentLoadedEventEnd,
                    load:n.loadEventEnd,fcp:f?f.startTime:null,count:r.length,bytes:r.reduce((s,x)=>s+(x.transferSize||0),0),
                    slow:r.slice().sort((a,b)=>b.duration-a.duration).slice(0,5).map(x=>({host:new URL(x.name).hostname,ms:x.duration}))};
                    }catch{return null;}})()
                    """);
                if (p.Url != url) { status.Text = "Page changed. Reopen Loading Inspector."; return; }
                using var doc = JsonDocument.Parse(raw.Length < 50000 ? raw : "null"); var j = doc.RootElement;
                if (j.ValueKind != JsonValueKind.Object) report += "Page timing unavailable.";
                else
                {
                    foreach (var pair in new[] { ("DNS", "dns"), ("Connection including TLS", "connection"), ("Request to first byte", "server"), ("Document download", "download"), ("DOM ready", "dom"), ("Load event", "load"), ("First contentful paint", "fcp") })
                        report += pair.Item1 + ": " + (j.GetProperty(pair.Item2).ValueKind == JsonValueKind.Number ? Math.Round(j.GetProperty(pair.Item2).GetDouble()) + " ms" : "unavailable") + "\r\n";
                    report += "\r\nResource timing entries: " + j.GetProperty("count") + "\r\nReported resource transfer bytes: " + j.GetProperty("bytes") + "\r\n\r\nSlowest reported resources\r\n";
                    foreach (var x in j.GetProperty("slow").EnumerateArray()) report += x.GetProperty("host").GetString() + " — " + Math.Round(x.GetProperty("ms").GetDouble()) + " ms\r\n";
                }
            }
        }
        catch { report += "Page timing unavailable."; }
        report += "\r\n\r\nPage timings are supplied by the website and can be altered by it. Cross-origin sizes can be hidden. Zero can mean cache, reused connections or a pending event. Dynamic content can keep loading after completion. Counts do not capture every worker or redirected request. No time-saved estimate or instant-load claim.";
        using var d = Dialog("Loading Inspector", 700, 620);
        d.Controls.Add(new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BackColor = panel, ForeColor = ink, Font = new Font("Consolas", 11), Text = report, BorderStyle = BorderStyle.None }); d.ShowDialog(this);
    }
    private void ShowMenu()
    {
        var m = new ContextMenuStrip { BackColor = panel, ForeColor = ink };
        m.Items.Add("New tab  Ctrl+T", null, (_, _) => NewTab());
        m.Items.Add("Close tab  Ctrl+W", null, (_, _) => CloseTab(Current));
        m.Items.Add("Bookmarks  Ctrl+B", null, (_, _) => ShowLinks(false));
        m.Items.Add("History  Ctrl+H", null, (_, _) => ShowLinks(true));
        m.Items.Add("Downloads  Ctrl+J", null, (_, _) => Downloads());
        m.Items.Add("Find on page  Ctrl+F", null, async (_, _) => await Find());
        m.Items.Add("Print  Ctrl+P", null, (_, _) => Current?.Web?.CoreWebView2?.ShowPrintUI());
        m.Items.Add("Loading Inspector", null, async (_, _) => await Inspector());
        m.Items.Add("About / profile location", null, (_, _) => MessageBox.Show(this,
            "Aether One PC 0.1.0\nNative Windows interface · Microsoft Edge WebView2 engine\n\nNo app analytics. Bookmarks/history/settings are local JSON; cookies and site data use a separate WebView2 profile. This app does not provide private browsing, extensions, sync or a password manager. Websites may collect data.\n\nPortable EXE; browsing data is stored here:\n" + profilePath,
            "About Aether One"));
        m.Show(Cursor.Position);
    }
    private void Downloads()
    {
        try { Current?.Web?.CoreWebView2?.OpenDefaultDownloadDialog(); }
        catch { status.Text = "Open a website before opening downloads"; }
    }
    private async Task Find()
    {
        var web = Current?.Web; if (web?.CoreWebView2 == null || Current!.AtHome) return;
        using var d = Dialog("Find on page", 480, 150);
        var input = new TextBox { Dock = DockStyle.Top, Font = Font, PlaceholderText = "Search text" };
        var b = Button("Find next", "Find next match", () => d.DialogResult = DialogResult.OK); b.Dock = DockStyle.Bottom; b.Height = 40;
        d.Controls.Add(input); d.Controls.Add(b); d.AcceptButton = b;
        if (d.ShowDialog(this) == DialogResult.OK && !string.IsNullOrWhiteSpace(input.Text))
        {
            try { await web.CoreWebView2.ExecuteScriptAsync("window.find(" + JsonSerializer.Serialize(input.Text) + ", false, false, true)"); }
            catch { status.Text = "Find is unavailable on this page"; }
        }
    }
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        switch (keyData)
        {
            case Keys.Control | Keys.L: address.Focus(); address.SelectAll(); return true;
            case Keys.Control | Keys.T: NewTab(); return true;
            case Keys.Control | Keys.W: CloseTab(Current); return true;
            case Keys.Control | Keys.D: Bookmark(); return true;
            case Keys.Control | Keys.B: ShowLinks(false); return true;
            case Keys.Control | Keys.H: ShowLinks(true); return true;
            case Keys.Control | Keys.J: Downloads(); return true;
            case Keys.Control | Keys.F: _ = Find(); return true;
            case Keys.Control | Keys.R: case Keys.F5: Reload(); return true;
            case Keys.Control | Keys.P: Current?.Web?.CoreWebView2?.ShowPrintUI(); return true;
            case Keys.Alt | Keys.Left: if (Current?.Web?.CanGoBack == true) Current.Web.GoBack(); return true;
            case Keys.Alt | Keys.Right: if (Current?.Web?.CanGoForward == true) Current.Web.GoForward(); return true;
            case Keys.Control | Keys.Tab: if (tabs.TabCount > 0) tabs.SelectedIndex = (tabs.SelectedIndex + 1) % tabs.TabCount; return true;
            case Keys.Control | Keys.Shift | Keys.Tab: if (tabs.TabCount > 0) tabs.SelectedIndex = (tabs.SelectedIndex + tabs.TabCount - 1) % tabs.TabCount; return true;
        }
        return base.ProcessCmdKey(ref msg, keyData);
    }
    private async Task SmokeTest()
    {
        var output = Environment.GetEnvironmentVariable("AETHER_SMOKE_OUTPUT") ?? Path.Combine(profilePath, "Results"); Directory.CreateDirectory(output);
        try
        {
            NewTab(); await Ensure(Current!); var p = Current!;
            if (Environment.GetEnvironmentVariable("AETHER_BENCHMARK") == "1") { await RunBenchmark(output, p); Close(); return; }
            await Task.Delay(700); CaptureWindow(Path.Combine(output, "AetherOne-Home.png"));
            var fixtures = Path.Combine(profilePath, "Fixtures"); Directory.CreateDirectory(fixtures);
            File.WriteAllText(Path.Combine(fixtures, "index.html"), """
                <!doctype html><html><head><meta charset="utf-8"><title>Aether One · Engine check</title><style>
                body{margin:0;background:#101925;color:#edf5fc;font:20px Segoe UI;padding:65px}small{color:#71e7c9;letter-spacing:4px}h1{font-size:58px;max-width:780px}p{color:#a9b9cc;max-width:770px;line-height:1.7}.card{padding:25px;border:1px solid #304357;border-radius:20px;max-width:760px;margin-top:35px}</style></head><body>
                <small>LOCAL ENGINE TEST</small><h1>A little space.<br>A world to explore.</h1><p>This page is rendered by Aether One's real WebView2 engine. This deterministic test checks navigation, JavaScript, ad-request interception and site controls without relying on a remote website.</p><div class="card">Native Windows shell · Independent browser profile · Local ad filtering</div>
                <script>window.aetherReady=42;</script><script src="https://securepubads.g.doubleclick.net/aether-test.js"></script></body></html>
                """);
            var allowedFixture = false;
            p.Web!.CoreWebView2.WebResourceRequested += (_, e) =>
            {
                // Test-only fallback: deterministic allow response, never contact the ad network.
                if (e.Request.Uri == "https://securepubads.g.doubleclick.net/aether-test.js" && e.Response == null)
                {
                    allowedFixture = true;
                    e.Response = p.Web.CoreWebView2.Environment.CreateWebResourceResponse(new MemoryStream(System.Text.Encoding.UTF8.GetBytes("void 0;")), 200, "OK", "Content-Type: application/javascript\r\nCache-Control: no-store\r\n");
                }
            };
            p.Web.CoreWebView2.SetVirtualHostNameToFolderMapping("aether.test", fixtures, CoreWebView2HostResourceAccessKind.DenyCors);
            await Navigate("https://aether.test/index.html", p);
            await WaitFor(async () => !p.Loading && await p.Web.CoreWebView2.ExecuteScriptAsync("window.aetherReady") == "42");
            if (p.Blocked < 1) throw new Exception("Ad interception did not block the fixture request");
            var initialBlocked = p.Blocked;
            state.BlockAds = false; p.Loading = true; p.Web.Reload(); await WaitFor(async () => !p.Loading && await p.Web.CoreWebView2.ExecuteScriptAsync("window.aetherReady") == "42");
            // The disabled run may attempt a real request. Blocker count must stay zero.
            if (p.Blocked != 0 || !allowedFixture) throw new Exception("Global off switch failed");
            state.BlockAds = true; allowedFixture = false; state.Sites["aether.test"] = new SiteRule { BlockAds = false };
            p.Loading = true; p.Web.Reload(); await WaitFor(async () => !p.Loading && await p.Web.CoreWebView2.ExecuteScriptAsync("window.aetherReady") == "42");
            if (p.Blocked != 0 || !allowedFixture) throw new Exception("Site exception failed");
            state.BlockAds = true; state.Sites["aether.test"] = new SiteRule { JavaScript = false }; ApplyPolicy(p); p.Loading = true; p.Web.Reload();
            await WaitFor(async () => !p.Loading && await p.Web.CoreWebView2.ExecuteScriptAsync("typeof window.aetherReady") == "\"undefined\"");
            state.Sites.Remove("aether.test"); ApplyPolicy(p); p.Loading = true; p.Web.Reload(); await WaitFor(async () => !p.Loading && await p.Web.CoreWebView2.ExecuteScriptAsync("window.aetherReady") == "42");
            Bookmark(); if (!state.Bookmarks.Any(x => x.Url == p.Url)) throw new Exception("Bookmark save failed");
            Home(); await Navigate("https://aether.test/index.html", p); if (p.AtHome || !p.Web.Visible) throw new Exception("Live page restore failed");
            NewTab(); if (pages.Count != 2) throw new Exception("New tab failed"); CloseTab(Current); if (pages.Count != 1) throw new Exception("Close tab failed");
            tabs.SelectedTab = p.Container; Sync(); await Task.Delay(700); CaptureWindow(Path.Combine(output, "AetherOne-Engine.png"));
            File.WriteAllText(Path.Combine(output, "smoke-test.txt"), $"PASS: WebView2 engine startup, local HTTPS navigation, JavaScript execution, ad interception ({initialBlocked}), global blocker off, per-site ad exception, site JavaScript off, bookmark, live page restore, new tab and close tab.\nRuntime: {p.Web.CoreWebView2.Environment.BrowserVersionString}\n");
            Close();
        }
        catch (Exception e) { File.WriteAllText(Path.Combine(output, "smoke-test.txt"), "FAIL: " + e); Environment.ExitCode = 1; Close(); }
    }
    private static async Task WaitFor(Func<Task<bool>> ready)
    {
        var clock = Stopwatch.StartNew(); while (clock.Elapsed < TimeSpan.FromSeconds(25)) { if (await ready()) return; await Task.Delay(100); } throw new TimeoutException("WebView2 fixture did not reach expected state");
    }
    private void CaptureWindow(string path)
    {
        using var bmp = new Bitmap(Width, Height); using var g = Graphics.FromImage(bmp); g.CopyFromScreen(Location, Point.Empty, Size); bmp.Save(path, System.Drawing.Imaging.ImageFormat.Png);
    }
}
