using Microsoft.Web.WebView2.Core;
using System.Text.Json;
namespace AetherOnePC;
public sealed partial class BrowserForm
{
    private BrowserTab? lastSelected;
    private readonly Dictionary<BrowserTab,Task<bool>> suspensionRequests=[];
    private int suspensionAttempts;
    private string? suspensionError;
    private Task<bool> SuspendHidden(BrowserTab p)
    {
        if(suspensionRequests.TryGetValue(p,out var pending))return pending;
        var task=TrySuspendHidden(p);suspensionRequests[p]=task;return task;
    }
    private async Task<bool> TrySuspendHidden(BrowserTab p)
    {
        // Let the native controller observe the tab's visibility change first.
        await Task.Yield();
        try {
            var web=p.Web;
            if(!state.MemorySaver||closing||p==Current||p==splitLeft||p==splitRight||p.Pinned||p.Audible||p.Loading||web?.CoreWebView2==null||web.Visible)return false;
            suspensionAttempts++;
            bool suspended=await web.CoreWebView2.TrySuspendAsync();
            if(suspended&&(p==Current||p==splitLeft||p==splitRight||web.Visible)){web.CoreWebView2.Resume();return false;}
            return suspended;
        }catch(Exception ex){suspensionError=ex.Message;return false;}
        finally{suspensionRequests.Remove(p);}
    }
    private Task? bundledExtension;
    private readonly Dictionary<string,CoreWebView2BrowserExtension> loadedExtensions=[];
    private Task<CoreWebView2Environment> CreateEnvironment()=>CoreWebView2Environment.CreateAsync(null,Path.Combine(profilePath,"WebView"),new CoreWebView2EnvironmentOptions{AreBrowserExtensionsEnabled=true});
    private bool IsAllowedExtensionPage(BrowserTab tab,string value)=>Uri.TryCreate(value,UriKind.Absolute,out var u)&&u.Scheme=="chrome-extension"&&u.Host==tab.ExtensionOrigin&&loadedExtensions.TryGetValue(u.Host,out var e)&&e.IsEnabled;
    private async Task EnsureBundledExtension(CoreWebView2 core)
    {
        if(bundledExtension!=null){await bundledExtension;return;}
        bundledExtension=InstallBundled(core);await bundledExtension;
    }
    private async Task InstallBundled(CoreWebView2 core)
    {
        state.ExtensionFolders??=[];state.PinnedExtensions??=[];
        foreach(var e in await core.Profile.GetBrowserExtensionsAsync())loadedExtensions[e.Id]=e;
        var source=Path.Combine(AppContext.BaseDirectory,"ReadingTools");
        if(!Directory.Exists(source))return;
        var stored=Path.Combine(profilePath,"Extensions","AetherReadingTools-1.0");
        if(!Directory.Exists(stored)){Directory.CreateDirectory(stored);foreach(var f in Directory.GetFiles(source))File.Copy(f,Path.Combine(stored,Path.GetFileName(f)),false);}
        if(!state.ReadingToolsOffered){var ext=await core.Profile.AddBrowserExtensionAsync(stored);loadedExtensions[ext.Id]=ext;state.ExtensionFolders[ext.Id]=stored;state.ReadingToolsOffered=true;state.PinnedExtensions.Add(ext.Id);QueueSave();RefreshSurfaces();}
    }
    private static string ManifestSummary(string folder)
    {
        using var doc=JsonDocument.Parse(File.ReadAllText(Path.Combine(folder,"manifest.json")));var j=doc.RootElement;
        string name=j.TryGetProperty("name",out var n)?n.GetString()??"Unnamed":"Unnamed";
        var details=new List<string>();foreach(var key in new[]{"permissions","host_permissions","content_scripts"})if(j.TryGetProperty(key,out var p))details.Add(key+": "+p.GetRawText());
        return name+"\n\n"+(details.Count>0?string.Join("\n",details):"No permissions declared.");
    }
    private async Task ImportExtension(CoreWebView2 core,string source,bool confirm=true)
    {
        string manifest=Path.Combine(source,"manifest.json");if(new FileInfo(manifest).Exists&&new FileInfo(manifest).Length>1024*1024)throw new InvalidDataException("Manifest exceeds 1 MiB.");if(!File.Exists(manifest))throw new InvalidDataException("Select the folder containing manifest.json.");
        string summary=ManifestSummary(source);
        if(confirm&&MessageBox.Show(this,summary+"\n\nThis extension can receive the access declared above. Load only extensions you trust. Load it?","Load unpacked extension",MessageBoxButtons.OKCancel,MessageBoxIcon.Question)!=DialogResult.OK)return;
        string target=Path.Combine(profilePath,"Extensions","Imported-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(target);
        int count=0;long bytes=0;
        void Copy(string src,string dst){foreach(var entry in new DirectoryInfo(src).EnumerateFileSystemInfos()){if((entry.Attributes&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Symbolic links and junctions are not imported.");if(entry.Name=="_metadata")continue;if(++count>20000)throw new InvalidDataException("Extension contains too many files.");string path=Path.Combine(dst,entry.Name);if(entry is DirectoryInfo){Directory.CreateDirectory(path);Copy(entry.FullName,path);}else{bytes+=((FileInfo)entry).Length;if(bytes>100*1024*1024)throw new InvalidDataException("Extension is larger than the 100 MiB import limit.");File.Copy(entry.FullName,path);}}}
        Copy(source,target);var ext=await core.Profile.AddBrowserExtensionAsync(target);state.ExtensionFolders[ext.Id]=target;loadedExtensions[ext.Id]=ext;QueueSave();
    }
    private async Task ExtensionsDialog(string? capturePath=null)
    {
        var p=Current;if(p==null)return;
        try{await Ensure(p);if(p.Web?.CoreWebView2==null)return;var core=p.Web.CoreWebView2;await EnsureBundledExtension(core);
            using var d=Dialog("Extensions",820,560);var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(22),RowCount=4,ColumnCount=1};layout.RowStyles.Add(new RowStyle(SizeType.Absolute,55));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,104));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,50));
            layout.Controls.Add(new Label{Text="Extensions\nLoad unpacked folders · enable, disable or remove",Dock=DockStyle.Fill,Font=new Font("Segoe UI",12),ForeColor=Visual.Text},0,0);
            var list=new ListBox{Dock=DockStyle.Fill,BackColor=Visual.Card,ForeColor=Visual.Text,Font=Font,BorderStyle=BorderStyle.None,IntegralHeight=false};var details=new TextBox{Dock=DockStyle.Fill,Multiline=true,ReadOnly=true,BackColor=Visual.Surface,ForeColor=Visual.Muted,BorderStyle=BorderStyle.None,ScrollBars=ScrollBars.Vertical};
            List<CoreWebView2BrowserExtension> items=[];
            async Task Refresh(){items=(await core.Profile.GetBrowserExtensionsAsync()).ToList();loadedExtensions.Clear();list.Items.Clear();foreach(var e in items){loadedExtensions[e.Id]=e;list.Items.Add((e.IsEnabled?"●  ":"○  ")+e.Name+"   —   "+(e.IsEnabled?"Enabled":"Disabled"));}if(items.Count>0)list.SelectedIndex=0;RefreshExtensionPins();}
            CoreWebView2BrowserExtension? Selected()=>list.SelectedIndex>=0&&list.SelectedIndex<items.Count?items[list.SelectedIndex]:null;
            list.SelectedIndexChanged+=(_,_)=>{var e=Selected();if(e==null)return;details.Text=e.Name+"\r\nID: "+e.Id+"\r\n"+(state.ExtensionFolders.TryGetValue(e.Id,out var path)?ManifestSummary(path):"Manifest folder unavailable.");};
            var actions=new FlowLayoutPanel{Dock=DockStyle.Fill};
            void Action(string name,Func<Task> action){var button=Button(name,name,async()=>{try{await action();}catch(Exception e){MessageBox.Show(d,e.Message,"Extension action failed");}});button.Dock=DockStyle.None;button.Size=new Size(135,38);actions.Controls.Add(button);}
            Action("Load unpacked",async()=>{using var folder=new FolderBrowserDialog{Description="Choose the extension folder containing manifest.json",UseDescriptionForTitle=true};if(folder.ShowDialog(d)==DialogResult.OK){await ImportExtension(core,folder.SelectedPath);await Refresh();}});
            Action("Enable / disable",async()=>{var e=Selected();if(e!=null){await e.EnableAsync(!e.IsEnabled);await Refresh();}});
            Action("Open tools",async()=>{var e=Selected();if(e!=null){d.Close();await OpenExtensionPage(e);}});
            Action("Pin / unpin",async()=>{var e=Selected();if(e!=null){if(!state.PinnedExtensions.Remove(e.Id))state.PinnedExtensions.Add(e.Id);QueueSave();RefreshExtensionPins();}await Task.CompletedTask;});
            Action("Remove",async()=>{var e=Selected();if(e!=null&&MessageBox.Show(d,"Remove "+e.Name+"? Its extension data may be removed.","Remove extension",MessageBoxButtons.OKCancel)==DialogResult.OK){await e.RemoveAsync();state.ExtensionFolders.Remove(e.Id);state.PinnedExtensions.Remove(e.Id);QueueSave();await Refresh();}});
            layout.Controls.Add(list,0,1);layout.Controls.Add(details,0,2);layout.Controls.Add(actions,0,3);d.Controls.Add(layout);await Refresh();if(capturePath!=null){d.Show(this);await Task.Delay(400);CaptureWindow(capturePath);d.Close();}else d.ShowDialog(this);
        }catch(Exception e){if(!closing)MessageBox.Show(this,"Extension support requires a current WebView2 Runtime.\n\n"+e.Message,"Extensions");}
    }
    private async Task OpenExtensionPage(CoreWebView2BrowserExtension extension)
    {
        if(!extension.IsEnabled){status.Text="Enable this extension first";return;}if(!state.ExtensionFolders.TryGetValue(extension.Id,out var folder))return;
        using var doc=JsonDocument.Parse(File.ReadAllText(Path.Combine(folder,"manifest.json")));var j=doc.RootElement;string? entry=null;
        if(j.TryGetProperty("options_page",out var old))entry=old.GetString();else if(j.TryGetProperty("options_ui",out var options)&&options.TryGetProperty("page",out var page))entry=page.GetString();else if(j.TryGetProperty("action",out var action)&&action.TryGetProperty("default_popup",out var popup))entry=popup.GetString();
        if(string.IsNullOrWhiteSpace(entry)){MessageBox.Show(this,"This extension has no options or popup page. Its content scripts, shortcuts or context menu run on supported pages.",extension.Name);return;}
        string full=Path.GetFullPath(Path.Combine(folder,entry.Replace('/',Path.DirectorySeparatorChar).TrimStart(Path.DirectorySeparatorChar)));if(!full.StartsWith(Path.GetFullPath(folder)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase)||!File.Exists(full))throw new InvalidDataException("The extension entry page is invalid.");
        NewTab();var p=Current!;await Ensure(p);if(p.Web?.CoreWebView2==null)return;p.ExtensionOrigin=extension.Id;p.AtHome=false;p.Home.Visible=false;p.Web.Visible=true;p.Web.BringToFront();p.Web.CoreWebView2.Navigate("chrome-extension://"+extension.Id+"/"+string.Join('/',entry.TrimStart('/').Split('/').Select(Uri.EscapeDataString)));
    }
}
