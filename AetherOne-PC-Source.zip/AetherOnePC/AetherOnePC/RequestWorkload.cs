using Microsoft.Web.WebView2.Core;
using System.Text.Json;
namespace AetherOnePC;
public sealed partial class BrowserForm
{
    private async Task RunRequestWorkload(string output)
    {
        string folder=Path.Combine(profilePath,"RequestFixture");Directory.CreateDirectory(folder);
        File.WriteAllText(Path.Combine(folder,"asset.txt"),"Aether resource fixture");
        File.WriteAllText(Path.Combine(folder,"index.html"),"""
            <!doctype html><title>Request routing workload</title><h1>Request routing workload</h1><script>
            window.ready=false;window.started=performance.now();
            Promise.all(Array.from({length:64},(_,i)=>fetch('/asset.txt?item='+i+'&run='+location.search,{cache:'no-store'}).then(r=>{if(!r.ok)throw Error(r.status);return r.text()}))).then(items=>{window.completed=items.length;window.duration=performance.now()-window.started;window.ready=true});
            </script>
            """);NewTab();var p=Current!;await Ensure(p);p.Web!.CoreWebView2.SetVirtualHostNameToFolderMapping("aether-route.test",folder,CoreWebView2HostResourceAccessKind.DenyCors);
        var samples=new List<object>();for(int i=0;i<5;i++){await Navigate("https://aether-route.test/index.html?run="+i,p);await WaitFor(async()=>!p.Loading&&await p.Web.CoreWebView2.ExecuteScriptAsync("window.ready")=="true");if(await p.Web.CoreWebView2.ExecuteScriptAsync("window.completed")!="64")throw new Exception("Request fixture did not finish all resources");samples.Add(new{Iteration=i,AppInterceptedResources=p.Observed,NavigationCompletedMs=p.Finished,ResourceCompletionMs=JsonSerializer.Deserialize<double>(await p.Web.CoreWebView2.ExecuteScriptAsync("window.duration"))});}
        CloseTab(p);File.WriteAllText(Path.Combine(output,"request-workload.json"),JsonSerializer.Serialize(new{ResourcesPerIteration=64,Samples=samples,Note="Same local HTTPS-mapped resources, five sequential navigations; not internet page-load timings. Observed is app-intercepted resources, not total engine traffic. Zero app interception does not mean zero engine work."},new JsonSerializerOptions{WriteIndented=true}));
    }
}
