namespace AetherOnePC;
internal static class Program
{
    internal static readonly System.Diagnostics.Stopwatch Startup = System.Diagnostics.Stopwatch.StartNew();
    [STAThread]
    static void Main(string[] args)
    {
        Startup.Restart();
        ApplicationConfiguration.Initialize();
        Application.Run(new BrowserForm(args.Contains("--smoke-test")));
    }
}
