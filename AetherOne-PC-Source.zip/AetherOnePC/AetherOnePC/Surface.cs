using System.Drawing.Drawing2D;
using System.ComponentModel;
using Microsoft.Web.WebView2.Core;
using System.Diagnostics;
using System.Text.Json;

namespace AetherOnePC;
internal static class Visual
{
    public static readonly Color Base = Color.FromArgb(12, 17, 26), Surface = Color.FromArgb(19, 26, 38), Card = Color.FromArgb(24, 33, 47), Stroke = Color.FromArgb(39, 51, 68), Text = Color.FromArgb(237, 242, 248), Muted = Color.FromArgb(138, 155, 178), Mint = Color.FromArgb(132, 229, 204), Lilac = Color.FromArgb(186, 173, 245);
    public static GraphicsPath Shape(RectangleF r, float radius)
    {
        var p = new GraphicsPath(); float d = radius * 2;
        p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right-d, r.Y, d, d, 270, 90); p.AddArc(r.Right-d, r.Bottom-d, d, d, 0, 90); p.AddArc(r.X, r.Bottom-d, d, d, 90, 90); p.CloseFigure(); return p;
    }
    public static void Round(Graphics g, RectangleF r, Color fill, float radius=12, bool stroke=false)
    {
        using var p = Shape(r, radius); using var b = new SolidBrush(fill); g.FillPath(b,p); if(stroke){using var pen=new Pen(Stroke);g.DrawPath(pen,p);}
    }
    public static void TextAt(Graphics g, string value, Rectangle r, float size, Color color, bool bold=false)
    {
        using var f = new Font("Segoe UI", size, bold?FontStyle.Bold:FontStyle.Regular);
        TextRenderer.DrawText(g,value,f,r,color,TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix|TextFormatFlags.WordBreak);
    }
    public static void Icon(Graphics g, string name, Rectangle r, Color color)
    {
        var save=g.Save();g.TranslateTransform(r.X,r.Y);g.ScaleTransform(r.Width/24f,r.Height/24f);
        using var p = new Pen(color,1.65f){StartCap=LineCap.Round,EndCap=LineCap.Round,LineJoin=LineJoin.Round};
        void Line(float x,float y,float a,float b)=>g.DrawLine(p,x,y,a,b);
        void Path(params PointF[] points)=>g.DrawLines(p,points);
        switch(name){
            case "back":Path(new(15,5),new(8,12),new(15,19));break;
            case "forward":Path(new(9,5),new(16,12),new(9,19));break;
            case "down":Path(new(6,9),new(12,15),new(18,9));break;
            case "reload":g.DrawArc(p,5,5,14,14,30,290);Path(new(16,3),new(20,6),new(16,9));break;
            case "home":Path(new(3,11),new(12,4),new(21,11));Path(new(6,10),new(6,20),new(18,20),new(18,10));break;
            case "search":g.DrawEllipse(p,4,4,12,12);Line(15,15,21,21);break;
            case "plus":Line(12,5,12,19);Line(5,12,19,12);break;
            case "close":Line(6,6,18,18);Line(6,18,18,6);break;
            case "shield":Path(new(12,3),new(20,6),new(19,14),new(16,19),new(12,22),new(8,19),new(5,14),new(4,6),new(12,3));Path(new(8,12),new(11,15),new(16,9));break;
            case "sidebar":g.DrawRectangle(p,3,4,18,16);Line(9,4,9,20);break;
            case "split":g.DrawRectangle(p,3,4,18,16);Line(12,4,12,20);break;
            case "notes":Path(new(5,3),new(16,3),new(20,7),new(20,21),new(5,21),new(5,3));Line(9,10,16,10);Line(9,14,16,14);break;
            case "bookmark":Path(new(6,3),new(18,3),new(18,21),new(12,17),new(6,21),new(6,3));break;
            case "sleep":Path(new(9,6),new(17,6),new(9,16),new(17,16));break;
            case "clock":g.DrawEllipse(p,3,3,18,18);Path(new(12,7),new(12,12),new(16,14));break;
            case "menu":Line(5,6,19,6);Line(5,12,19,12);Line(5,18,19,18);break;
            case "brand":Path(new(4,20),new(12,3),new(20,20));Line(8,14,16,14);g.DrawArc(p,2,8,20,15,10,150);break;
            case "inspect":Line(5,19,5,12);Line(12,19,12,5);Line(19,19,19,9);break;
            default:g.DrawEllipse(p,5,5,14,14);Line(12,8,12,16);Line(8,12,16,12);break;
        }g.Restore(save);
    }
}
internal sealed class ChromeButton : Button
{
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public string Glyph { get; set; } = "";
    private bool hover;
    public ChromeButton(){SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint,true);}
    protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
    protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
    protected override void OnPaint(PaintEventArgs e)
    {
        var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Parent?.BackColor??Visual.Base);
        Visual.Round(g,new Rectangle(1,1,Width-3,Height-3),hover?Color.FromArgb(36,47,64):BackColor,9);
        var c=Enabled?ForeColor:Visual.Muted;
        if(Glyph.Length>0)Visual.Icon(g,Glyph,new Rectangle((Width-19)/2,(Height-19)/2,19,19),c);
        else TextRenderer.DrawText(g,Text,Font,ClientRectangle,c,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
        if(Focused){using var p=new Pen(Visual.Mint);g.DrawRectangle(p,3,3,Width-7,Height-7);}
    }
}
internal sealed class TabDeck : TabControl
{
    public TabDeck(){Appearance=TabAppearance.FlatButtons;ItemSize=new Size(1,1);SizeMode=TabSizeMode.Fixed;Padding=Point.Empty;}
    public override Rectangle DisplayRectangle=>new(0,0,Width,Height);
    protected override void WndProc(ref Message m){if(m.Msg==0x1328){m.Result=(IntPtr)1;return;}base.WndProc(ref m);}
}
public sealed partial class BrowserForm
{
    [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd,int attribute,ref int value,int size);
    protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);if(OperatingSystem.IsWindowsVersionAtLeast(10,0,17763)){int dark=1;DwmSetWindowAttribute(Handle,20,ref dark,sizeof(int));}}
    private WorkspaceRail rail=null!;
    private TableLayoutPanel shell=null!;
    private Panel pageHost=null!;
    private Panel? notesPanel;
    private TextBox? noteInput;
    private bool refreshing, focusMode;
    private readonly Stack<TabSnapshot> closedTabs=[];
    private SplitContainer? split;
    private BrowserTab? splitLeft,splitRight;
    private void BuildWorkspaceUi()
    {
        BackColor=Visual.Base;
        shell=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,BackColor=Visual.Base,Padding=new Padding(8)};
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,208));shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));shell.RowStyles.Add(new RowStyle(SizeType.Percent,100));Controls.Add(shell);
        rail=new WorkspaceRail(this){Dock=DockStyle.Fill};shell.Controls.Add(rail,0,0);
        var body=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,BackColor=Visual.Base};
        body.RowStyles.Add(new RowStyle(SizeType.Absolute,54));body.RowStyles.Add(new RowStyle(SizeType.Percent,100));body.RowStyles.Add(new RowStyle(SizeType.Absolute,23));shell.Controls.Add(body,1,0);
        var bar=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=10,RowCount=1,Padding=new Padding(5,3,0,8)};bar.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        for(int i=0;i<10;i++)bar.ColumnStyles.Add(new ColumnStyle(i==4?SizeType.Percent:SizeType.Absolute,i==4?100:34));
        Button Tool(string glyph,string label,Action action){var b=(ChromeButton)Button("",label,action);b.Glyph=glyph;b.BackColor=Visual.Base;return b;}
        bar.Controls.Add(Tool("sidebar","Focus view · hide sidebar",ToggleFocus),0,0);
        back=Tool("back","Back · Alt+Left",()=>{if(Current?.Web?.CanGoBack==true)Current.Web.GoBack();});bar.Controls.Add(back,1,0);
        forward=Tool("forward","Forward · Alt+Right",()=>{if(Current?.Web?.CanGoForward==true)Current.Web.GoForward();});bar.Controls.Add(forward,2,0);
        reload=Tool("reload","Reload / stop",Reload);bar.Controls.Add(reload,3,0);
        var box=new Panel{Dock=DockStyle.Fill,BackColor=Visual.Card,Padding=new Padding(13,11,9,7),Margin=new Padding(5,0,7,0)};
        address.BackColor=Visual.Card;address.ForeColor=Visual.Text;address.Font=new Font("Segoe UI",10);address.PlaceholderText="Search or enter address  ·  Ctrl+L";
        address.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;_=Navigate(address.Text);}};box.Controls.Add(address);bar.Controls.Add(box,4,0);
        shield=Tool("shield","Ad & tracker controls",BlockerDialog);bar.Controls.Add(shield,5,0);
        bar.Controls.Add(Tool("split","Split view",()=>_=SplitView()),6,0);
        bar.Controls.Add(Tool("notes","Workspace notes · Ctrl+Shift+N",ToggleNotes),7,0);
        bar.Controls.Add(Tool("inspect","Loading Inspector",()=>_=Inspector()),8,0);
        bar.Controls.Add(Tool("menu","Browser tools",ShowMenu),9,0);body.Controls.Add(bar,0,0);
        pageHost=new Panel{Dock=DockStyle.Fill,BackColor=Visual.Base,Padding=new Padding(1)};pageHost.Controls.Add(tabs);body.Controls.Add(pageHost,0,1);
        var foot=new Panel{Dock=DockStyle.Fill,Padding=new Padding(8,3,4,0)};status.ForeColor=Visual.Muted;status.Font=new Font("Segoe UI",8);foot.Controls.Add(status);foot.Controls.Add(progress);body.Controls.Add(foot,0,2);
    }
    private Panel CreateDashboard(BrowserTab owner)
    {
        var panel=new Panel{Dock=DockStyle.Fill,BackColor=Visual.Base};panel.Controls.Add(new Dashboard(this,owner){Dock=DockStyle.Fill});return panel;
    }
    private void RefreshSurfaces()
    {
        if(rail==null||refreshing||closing)return;refreshing=true;
        rail.Invalidate();
        foreach(var p in pages.Where(p=>p.AtHome&&p.Container==tabs.SelectedTab))foreach(Control c in p.Home.Controls)c.Invalidate();
        if(reload is ChromeButton b)b.Glyph=Current?.Loading==true?"close":"reload";
        refreshing=false;
    }
    private void SelectPage(BrowserTab p){EndSplit();state.ActiveWorkspace=p.Workspace;if(noteInput!=null)noteInput.Text=state.WorkspaceNotes.GetValueOrDefault(p.Workspace,"");tabs.SelectedTab=p.Container;Sync();QueueSave();}
    private void SwitchWorkspace(string workspace)
    {
        EndSplit();state.ActiveWorkspace=workspace;var p=pages.FirstOrDefault(x=>x.Workspace==workspace);if(p!=null)SelectPage(p);else NewTab();
        if(noteInput!=null)noteInput.Text=state.WorkspaceNotes.GetValueOrDefault(workspace,"");RefreshSurfaces();QueueSave();
    }
    private void WorkspaceMenu()
    {
        var menu=new ContextMenuStrip{BackColor=Visual.Surface,ForeColor=Visual.Text};foreach(var w in state.Workspaces){var name=w;menu.Items.Add(name+(name==state.ActiveWorkspace?"  ✓":""),null,(_,_)=>SwitchWorkspace(name));}
        menu.Items.Add("New workspace…",null,(_,_)=>{
            using var d=Dialog("Create workspace",420,160);var input=new TextBox{Dock=DockStyle.Top,PlaceholderText="Workspace name",MaxLength=32};var b=Button("Create","Create workspace",()=>d.DialogResult=DialogResult.OK);b.Dock=DockStyle.Bottom;b.Height=40;d.Controls.Add(input);d.Controls.Add(b);d.AcceptButton=b;
            if(d.ShowDialog(this)==DialogResult.OK&&!string.IsNullOrWhiteSpace(input.Text)){var n=input.Text.Trim();if(!state.Workspaces.Contains(n))state.Workspaces.Add(n);SwitchWorkspace(n);}
        });menu.Show(rail,new Point(14,93));
    }
    private void TabMenu(BrowserTab p)
    {
        var m=new ContextMenuStrip{BackColor=Visual.Surface,ForeColor=Visual.Text};
        m.Items.Add(p.Pinned?"Unpin":"Pin tab",null,(_,_)=>{p.Pinned=!p.Pinned;RefreshSurfaces();QueueSave();});
        foreach(var w in state.Workspaces){var workspace=w;m.Items.Add("Move to "+w,null,(_,_)=>{p.Workspace=workspace;SelectPage(p);});}
        m.Items.Add("Close tab",null,(_,_)=>CloseTab(p));m.Show(Cursor.Position);
    }
    private void ToggleFocus(){focusMode=!focusMode;shell.ColumnStyles[0].Width=focusMode?0:208;rail.Visible=!focusMode;}
    private void SaveReadLater()
    {
        var p=Current;if(p==null||p.AtHome||!IsWeb(p.Url))return;
        state.ReadLater.RemoveAll(x=>x.Url==p.Url);state.ReadLater.Insert(0,new SavedLink{Title=p.Title,Url=p.Url});QueueSave();RefreshSurfaces();status.Text="Saved to Read later";
    }
    private void ShowReadLater()
    {
        using var d=Dialog("Read later",720,480);var list=new ListBox{Dock=DockStyle.Fill,BackColor=Visual.Surface,ForeColor=Visual.Text,DisplayMember=nameof(SavedLink.Title),BorderStyle=BorderStyle.None};foreach(var x in state.ReadLater)list.Items.Add(x);
        list.DoubleClick+=(_,_)=>{if(list.SelectedItem is SavedLink x){NewTab(x.Url);d.Close();}};
        var b=Button("Remove selected","Remove reading-list item",()=>{if(list.SelectedItem is SavedLink x){state.ReadLater.Remove(x);list.Items.Remove(x);QueueSave();RefreshSurfaces();}});b.Dock=DockStyle.Bottom;b.Height=40;d.Controls.Add(list);d.Controls.Add(b);d.ShowDialog(this);
    }
    private void ReopenClosed(){if(closedTabs.TryPop(out var x)){NewTab(x.Url,true,x.Workspace);Current!.Pinned=x.Pinned;RefreshSurfaces();}}
    private void ToggleNotes()
    {
        if(notesPanel!=null){notesPanel.Visible=!notesPanel.Visible;LayoutNotes();return;}
        notesPanel=new Panel{Dock=DockStyle.None,Width=260,BackColor=Visual.Surface,Padding=new Padding(16)};
        var title=new Label{Text="WORKSPACE NOTES",Dock=DockStyle.Top,Height=36,ForeColor=Visual.Mint,Font=new Font("Segoe UI",10,FontStyle.Bold)};
        noteInput=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Vertical,BorderStyle=BorderStyle.None,BackColor=Visual.Surface,ForeColor=Visual.Text,Font=Font,AcceptsReturn=true,Text=state.WorkspaceNotes.GetValueOrDefault(state.ActiveWorkspace,"")};
        noteInput.TextChanged+=(_,_)=>{state.WorkspaceNotes[state.ActiveWorkspace]=noteInput.Text;QueueSave();};
        notesPanel.Controls.Add(noteInput);notesPanel.Controls.Add(title);pageHost.Controls.Add(notesPanel);pageHost.Resize+=(_,_)=>LayoutNotes();LayoutNotes();
    }
    private void LayoutNotes(){if(notesPanel==null)return;pageHost.Padding=new Padding(1,1,notesPanel.Visible?261:1,1);notesPanel.Bounds=new Rectangle(Math.Max(0,pageHost.ClientSize.Width-260),0,260,pageHost.ClientSize.Height);if(notesPanel.Visible)notesPanel.BringToFront();}
    private void SleepInactive(bool confirm=true)
    {
        var candidates=pages.Where(p=>p!=Current&&!p.Pinned&&!p.Loading&&p.Web!=null&&p!=splitRight).ToArray();
        if(candidates.Length==0){status.Text="No inactive page views to release";return;}
        if(confirm&&MessageBox.Show(this,$"Release {candidates.Length} inactive page views?\n\nURLs stay in the sidebar. Pages reload when opened; unsaved forms and scroll positions can be lost.","Sleep inactive tabs",MessageBoxButtons.OKCancel)!=DialogResult.OK)return;
        foreach(var p in candidates){p.Web!.Dispose();p.Web=null;p.Initialization=null;p.Sleeping=true;}
        RefreshSurfaces();status.Text=$"Released {candidates.Length} inactive page views";
    }
    private async Task SplitView()
    {
        if(split!=null){EndSplit();return;}var left=Current;if(left?.Web?.CoreWebView2==null||left.AtHome){status.Text="Open a website first, then choose another open page";return;}
        var candidates=pages.Where(p=>p!=left&&!p.AtHome&&IsWeb(p.Url)).ToArray();if(candidates.Length==0){status.Text="Open a second website in another tab first";return;}
        using var pick=Dialog("Compare with another tab",500,320);var list=new ListBox{Dock=DockStyle.Fill,BackColor=Visual.Surface,ForeColor=Visual.Text};foreach(var p in candidates)list.Items.Add(p.Title+" · "+Policy.Host(p.Url));list.SelectedIndex=0;var go=Button("Open split view","Compare two tabs",()=>pick.DialogResult=DialogResult.OK);go.Dock=DockStyle.Bottom;go.Height=40;pick.Controls.Add(list);pick.Controls.Add(go);pick.AcceptButton=go;
        if(pick.ShowDialog(this)!=DialogResult.OK)return;var right=candidates[list.SelectedIndex];
        await StartSplit(left,right);
    }
    private async Task StartSplit(BrowserTab left,BrowserTab right)
    {
        try{if(right.Web==null)await Navigate(right.Url,right);if(right.Web==null||!pages.Contains(left)||!pages.Contains(right))return;
            splitLeft=left;splitRight=right;split=new SplitContainer{Dock=DockStyle.Fill,BackColor=Visual.Stroke,SplitterWidth=5};pageHost.Controls.Add(split);split.BringToFront();split.SplitterDistance=Math.Max(100,pageHost.ClientSize.Width/2);
            left.Web.Parent=split.Panel1;right.Web.Parent=split.Panel2;left.Web.Visible=right.Web.Visible=true;left.Web.Dock=right.Web.Dock=DockStyle.Fill;
            status.Text="Split view · toolbar controls left page · click Split again to exit";
        }catch{EndSplit();status.Text="Split view could not open this page";}
    }
    private void EndSplit()
    {
        if(split==null)return;foreach(var p in new[]{splitLeft,splitRight})if(p?.Web!=null&&!p.Web.IsDisposed){p.Web.Parent=p.Container;p.Web.Dock=DockStyle.Fill;p.Web.Visible=!p.AtHome;}
        split.Dispose();split=null;splitLeft=splitRight=null;
    }
    private void CommandPalette()
    {
        using var d=Dialog("Aether commands",640,460);var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(18),RowCount=2,ColumnCount=1};layout.RowStyles.Add(new RowStyle(SizeType.Absolute,46));layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        var input=new TextBox{Dock=DockStyle.Fill,PlaceholderText="Search tabs, bookmarks or commands…",Font=new Font("Segoe UI",14),BackColor=Visual.Card,ForeColor=Visual.Text,BorderStyle=BorderStyle.FixedSingle};
        var list=new ListBox{Dock=DockStyle.Fill,BackColor=Visual.Surface,ForeColor=Visual.Text,BorderStyle=BorderStyle.None,Font=Font,IntegralHeight=false,ItemHeight=30};
        var entries=new List<(string Label,Action Run)>{("New tab",()=>NewTab()),("Dashboard",Home),("Read later",ShowReadLater),("Save page to Read later",SaveReadLater),("Workspace notes",ToggleNotes),("Bookmarks",()=>ShowLinks(false)),("History",()=>ShowLinks(true)),("Sleep inactive tabs",()=>SleepInactive()),("Focus view",ToggleFocus),("Site controls",SiteDialog),("Ad blocker",BlockerDialog),("Loading Inspector",()=>_=Inspector()),("Reopen closed tab",ReopenClosed),("Split view",()=>_=SplitView())};
        entries.AddRange(pages.Select(p=>("Tab · "+p.Title+" · "+p.Workspace,(Action)(()=>SelectPage(p)))));
        entries.AddRange(state.Bookmarks.Take(100).Select(x=>("Saved · "+x.Title,(Action)(()=>NewTab(x.Url)))));
        var visible=new List<(string Label,Action Run)>();void Filter(){visible=entries.Where(x=>x.Label.Contains(input.Text,StringComparison.OrdinalIgnoreCase)).Take(40).ToList();list.Items.Clear();foreach(var x in visible)list.Items.Add(x.Label);if(list.Items.Count>0)list.SelectedIndex=0;}
        void Run(){if(list.SelectedIndex>=0){var action=visible[list.SelectedIndex].Run;d.Close();BeginInvoke(action);}}
        input.TextChanged+=(_,_)=>Filter();input.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Down){e.SuppressKeyPress=true;list.Focus();}else if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;Run();}};list.DoubleClick+=(_,_)=>Run();list.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Enter)Run();};Filter();layout.Controls.Add(input,0,0);layout.Controls.Add(list,0,1);d.Controls.Add(layout);d.Shown+=(_,_)=>input.Focus();d.ShowDialog(this);
    }
    private sealed class WorkspaceRail : Control
    {
        private readonly BrowserForm owner;
        private readonly List<(Rectangle Rect,Action Run)> hits=[];
        private readonly List<(Rectangle Rect,BrowserTab Page)> rows=[];
        private int scroll;
        public WorkspaceRail(BrowserForm f){owner=f;DoubleBuffered=true;BackColor=Visual.Base;Cursor=Cursors.Hand;AccessibleName="Workspace and vertical tabs";TabStop=true;}
        protected override void OnPaint(PaintEventArgs e)
        {
            var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;hits.Clear();rows.Clear();g.Clear(Visual.Base);
            Visual.Icon(g,"brand",new Rectangle(13,13,27,27),Visual.Mint);Visual.TextAt(g,"aether",new Rectangle(49,10,130,27),17,Visual.Text,true);Visual.TextAt(g,"O N E   /   0 . 2",new Rectangle(51,38,135,17),7,Visual.Muted);
            Visual.Round(g,new Rectangle(9,75,Width-22,47),Visual.Card,11,true);
            using(var b=new SolidBrush(Visual.Lilac))g.FillEllipse(b,21,91,9,9);
            Visual.TextAt(g,owner.state.ActiveWorkspace,new Rectangle(40,88,Width-78,23),10,Visual.Text,true);Visual.Icon(g,"down",new Rectangle(Width-38,91,14,14),Visual.Muted);
            hits.Add((new Rectangle(9,75,Width-22,47),owner.WorkspaceMenu));
            void Nav(int y,string icon,string title,Action action,bool selected=false){if(selected)Visual.Round(g,new Rectangle(9,y,Width-22,38),Visual.Surface,8);Visual.Icon(g,icon,new Rectangle(20,y+10,18,18),selected?Visual.Mint:Visual.Muted);Visual.TextAt(g,title,new Rectangle(50,y+9,Width-70,26),10,selected?Visual.Text:Visual.Muted);hits.Add((new Rectangle(9,y,Width-22,38),action));}
            Nav(139,"home","Overview",owner.Home,owner.Current?.AtHome==true);
            Nav(179,"search","Commands   Ctrl K",owner.CommandPalette);
            Nav(219,"bookmark","Read later",owner.ShowReadLater);
            Nav(259,"notes","Workspace notes",owner.ToggleNotes);
            using(var pen=new Pen(Visual.Stroke))g.DrawLine(pen,18,313,Width-22,313);
            var items=owner.pages.Where(x=>x.Workspace==owner.state.ActiveWorkspace).OrderByDescending(x=>x.Pinned).ToArray();
            Visual.TextAt(g,"OPEN TABS  /  "+items.Length,new Rectangle(20,329,Width-65,19),8,Visual.Muted,true);
            Visual.Icon(g,"plus",new Rectangle(Width-41,327,18,18),Visual.Mint);hits.Add((new Rectangle(Width-48,320,32,32),()=>owner.NewTab()));
            var area=new Rectangle(8,357,Width-17,Math.Max(0,Height-422));var saved=g.Save();g.SetClip(area);
            int y=357-scroll;
            foreach(var p in items){var r=new Rectangle(9,y,Width-22,44);if(p==owner.Current)Visual.Round(g,r,Visual.Card,9);
                Visual.Icon(g,p.Sleeping?"sleep":p.AtHome?"home":p.Pinned?"bookmark":"clock",new Rectangle(20,y+12,17,17),p==owner.Current?Visual.Mint:Visual.Muted);
                Visual.TextAt(g,p.AtHome?"New tab":string.IsNullOrEmpty(p.Title)?Policy.Host(p.Url):p.Title,new Rectangle(47,y+7,Width-90,23),9,p==owner.Current?Visual.Text:Visual.Muted);
                Visual.TextAt(g,p.Sleeping?"Sleeping · reload on open":p.AtHome?"Your start page":Policy.Host(p.Url),new Rectangle(48,y+27,Width-76,15),7,Visual.Muted);
                Visual.Icon(g,"close",new Rectangle(Width-40,y+14,13,13),Visual.Muted);if(r.IntersectsWith(area))rows.Add((Rectangle.Intersect(r,area),p));y+=49;
            }g.Restore(saved);
            Visual.Round(g,new Rectangle(11,Height-55,Width-24,40),Visual.Surface,9);Visual.Icon(g,"sleep",new Rectangle(21,Height-44,18,18),Visual.Mint);Visual.TextAt(g,"Sleep inactive tabs",new Rectangle(49,Height-44,Width-62,24),9,Visual.Muted);hits.Add((new Rectangle(11,Height-55,Width-24,40),()=>owner.SleepInactive()));
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);foreach(var (r,p) in rows)if(r.Contains(e.Location)){if(e.Button==MouseButtons.Right)owner.TabMenu(p);else if(e.Button==MouseButtons.Middle||e.X>Width-47)owner.CloseTab(p);else owner.SelectPage(p);return;}
            if(e.Button==MouseButtons.Left)foreach(var (r,run) in hits)if(r.Contains(e.Location)){run();return;}
        }
        protected override void OnMouseWheel(MouseEventArgs e){scroll=Math.Clamp(scroll-e.Delta/3,0,Math.Max(0,owner.pages.Count(x=>x.Workspace==owner.state.ActiveWorkspace)*49-(Height-422)));Invalidate();base.OnMouseWheel(e);}
    }
    private sealed class Dashboard : Control
    {
        private readonly BrowserForm owner;private readonly BrowserTab tab;private readonly TextBox search;
        private readonly List<(Rectangle Rect,Action Run)> hits=[];
        public Dashboard(BrowserForm f,BrowserTab p)
        {
            owner=f;tab=p;DoubleBuffered=true;BackColor=Visual.Surface;AccessibleName="Aether overview dashboard";
            search=new TextBox{BorderStyle=BorderStyle.None,BackColor=Visual.Card,ForeColor=Visual.Text,Font=new Font("Segoe UI",13),PlaceholderText=""};Controls.Add(search);
            var cue=new Label{Text="Search the web, or type > for commands",ForeColor=Visual.Muted,BackColor=Visual.Card,Font=new Font("Segoe UI",11),AutoSize=false,Cursor=Cursors.IBeam};Controls.Add(cue);cue.BringToFront();
            cue.Click+=(_,_)=>search.Focus();
            void Cue(){cue.Bounds=new Rectangle(75,224,Math.Max(100,Width-143),25);cue.Visible=search.Text.Length==0&&!search.Focused;}
            search.TextChanged+=(_,_)=>Cue();search.GotFocus+=(_,_)=>Cue();search.LostFocus+=(_,_)=>Cue();Resize+=(_,_)=>Cue();Cue();
            search.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;if(search.Text.TrimStart().StartsWith('>'))owner.CommandPalette();else _=owner.Navigate(search.Text,tab);}};
            search.TextChanged+=(_,_)=>Invalidate();search.GotFocus+=(_,_)=>Invalidate();search.LostFocus+=(_,_)=>Invalidate();
            Resize+=(_,_)=>{search.Bounds=new Rectangle(75,223,Math.Max(100,Width-143),28);Invalidate();};
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;g.Clear(Visual.Surface);hits.Clear();int pad=30,w=Width-60;
            Visual.TextAt(g,"OVERVIEW  /  "+owner.state.ActiveWorkspace.ToUpperInvariant(),new Rectangle(pad,26,w-110,19),8,Visual.Muted,true);
            Visual.Round(g,new Rectangle(Width-129,23,99,26),Color.FromArgb(28,49,48),13);Visual.TextAt(g,owner.state.BlockAds?"SHIELD  ON":"SHIELD  OFF",new Rectangle(Width-120,30,88,15),7,Visual.Mint,true);
            Visual.TextAt(g,"Less noise.\nMore possibility.",new Rectangle(pad,67,w,123),34,Visual.Text,true);
            Visual.TextAt(g,"A clear space for everything you want to do next.",new Rectangle(pad,181,w,23),10,Visual.Muted);
            Visual.Round(g,new Rectangle(pad,208,w,57),Visual.Card,14,true);Visual.Icon(g,"search",new Rectangle(pad+15,226,19,19),Visual.Mint);
            int quickY=283,gap=10,tile=(w-gap*3)/4;var links=new[]{("Google","Search","https://www.google.com/"),("YouTube","Watch","https://www.youtube.com/"),("Wikipedia","Explore","https://www.wikipedia.org/"),("GitHub","Build","https://github.com/")};
            for(int i=0;i<4;i++){var x=pad+i*(tile+gap);var r=new Rectangle(x,quickY,tile,62);Visual.Round(g,r,Visual.Card,11);Visual.TextAt(g,links[i].Item1,new Rectangle(x+13,quickY+11,tile-23,23),10,Visual.Text,true);Visual.TextAt(g,links[i].Item2,new Rectangle(x+13,quickY+35,tile-23,19),8,Visual.Muted);var url=links[i].Item3;hits.Add((r,()=>_=owner.Navigate(url,tab)));}
            int cy=372,cw=(w-14)/2;
            Card(new Rectangle(pad,cy,cw,113),"READ LATER",owner.state.ReadLater.Count+" saved for a quieter moment",owner.state.ReadLater.FirstOrDefault()?.Title??"Keep a page. Come back with fresh eyes.",Visual.Lilac,owner.ShowReadLater);
            var note=owner.state.WorkspaceNotes.GetValueOrDefault(owner.state.ActiveWorkspace,"");
            Card(new Rectangle(pad+cw+14,cy,cw,113),"SCRATCHPAD",note.Length>0?"Pick up your thought":"Catch the thought before it goes",note.Length>0?note.Replace('\n',' ').Replace('\r',' '):"Notes live with this workspace. Always local.",Visual.Mint,owner.ToggleNotes);
            if(Height>585){int yy=506;Visual.TextAt(g,"CONTINUE YOUR THREAD",new Rectangle(pad,yy,w,20),8,Visual.Muted,true);
                var recent=owner.state.History.FirstOrDefault();Visual.Round(g,new Rectangle(pad,yy+29,w,67),Visual.Card,11,true);Visual.Icon(g,"clock",new Rectangle(pad+15,yy+51,19,19),Visual.Muted);
                Visual.TextAt(g,recent?.Title??"Start something worth coming back to.",new Rectangle(pad+47,yy+40,w-64,23),10,Visual.Text,true);Visual.TextAt(g,recent==null?"Your recent pages will appear here.":Policy.Host(recent.Url),new Rectangle(pad+48,yy+65,w-64,21),8,Visual.Muted);if(recent!=null)hits.Add((new Rectangle(pad,yy+29,w,67),()=>_=owner.Navigate(recent.Url,tab)));
            }
            void Card(Rectangle r,string name,string title,string detail,Color accent,Action action){Visual.Round(g,r,Visual.Card,13,true);Visual.TextAt(g,name,new Rectangle(r.X+15,r.Y+13,r.Width-28,17),7,accent,true);Visual.TextAt(g,title,new Rectangle(r.X+15,r.Y+39,r.Width-28,37),10,Visual.Text,true);Visual.TextAt(g,detail,new Rectangle(r.X+15,r.Y+82,r.Width-28,22),8,Visual.Muted);hits.Add((r,action));}
        }
        protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);foreach(var (r,run)in hits)if(r.Contains(e.Location)){run();return;}}
        protected override void Dispose(bool disposing){if(disposing)search.Dispose();base.Dispose(disposing);}
    }
    private async Task RunBenchmark(string output,BrowserTab page)
    {
        // Native dashboard and one warmed, blank engine. No remote page or background feed.
        var engineReadyMs = Program.Startup.Elapsed.TotalMilliseconds;
        await Task.Delay(3000);GC.Collect();GC.WaitForPendingFinalizers();
        var proc=Process.GetCurrentProcess();proc.Refresh();var cpu=proc.TotalProcessorTime;var start=Stopwatch.StartNew();await Task.Delay(3000);proc.Refresh();
        File.WriteAllText(Path.Combine(output,"performance.json"),JsonSerializer.Serialize(new{Version="0.2.0",NativeWindowShownMs=shownMs,EngineReadyMs=engineReadyMs,Scenario="Native dashboard with one warmed WebView2, no remote page",RootWorkingSetBytes=proc.WorkingSet64,RootPrivateBytes=proc.PrivateMemorySize64,ManagedBytes=GC.GetTotalMemory(false),IdleRootCpuMs=(proc.TotalProcessorTime-cpu).TotalMilliseconds,SampleMs=start.ElapsedMilliseconds,PageViews=pages.Count(x=>x.Web!=null),NativeControls=CountControls(this),Note="Root process only; WebView2 child processes excluded. Main-entry timers exclude EXE extraction. Root process only. Single CI sample, not an end-user benchmark."},new JsonSerializerOptions{WriteIndented=true}));
    }
    private static int CountControls(Control c)=>1+c.Controls.Cast<Control>().Sum(CountControls);
}
