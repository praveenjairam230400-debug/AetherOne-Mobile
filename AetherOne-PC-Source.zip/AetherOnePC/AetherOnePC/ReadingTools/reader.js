(() => {
  'use strict';
  // One key listener. No timer, observer, background worker, page upload or network request.
  document.addEventListener('keydown', event => {
    if (!event.altKey || !event.shiftKey || event.code !== 'KeyR' || event.repeat) return;
    event.preventDefault();
    const existing = document.getElementById('__aether_reader_style');
    if (existing) { existing.remove(); return; }
    const style = document.createElement('style');
    style.id = '__aether_reader_style';
    style.textContent = 'body{max-width:980px!important;margin:0 auto!important;padding:28px!important;line-height:1.8!important;font-size:18px!important}article,main,[role=main]{line-height:1.8!important}p{max-width:78ch!important}';
    (document.head || document.documentElement).appendChild(style);
  }, true);
})();
