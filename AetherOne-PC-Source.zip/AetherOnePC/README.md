# Aether One PC 0.3 — browser edition

Close the old Aether instance, extract the ZIP and run AetherOne.exe. Keep the ReadingTools folder alongside the program. Windows x64 with current WebView2 Evergreen Runtime is required; .NET is bundled. Tested on Windows 2025 CI; the user's Windows 10/11 device has not been remotely tested. EXE is unsigned. Data stays in %LOCALAPPDATA%\AetherOnePC\Profile.

## Browser interface
Horizontal tabs by default, page favicons and titles, audio indicator, new/close/middle-close tab, full-title tooltips, tab list, native window minimize/maximize/resize, compact address toolbar, favorites bar, native new-tab page and structured browser menu. Saved session records now include titles. The vertical workspace rail is optional under Workspace tools. Workspaces, notes, Read later, split view, command palette and site controls remain available.

Address suggestions match local tabs/bookmarks/reading list/history, with keyboard selection and click-to-open/switch. They never query a remote autocomplete API. A search is sent to Google only on submission. Website favicons are taken from the page engine, not separately fetched by the UI.

## Extensions
WebView2 extension support is enabled. Aether Reading Tools is included and loaded on first use: Alt+Shift+R toggles reading width/spacing on an HTTPS page. It has one key listener, no background worker, timer, observer, network request, storage or analytics. Its static content script can read/modify HTTPS pages; that access is declared in its manifest. You can disable or remove it in Extensions.

Extensions panel supports Load unpacked, enable/disable, remove, Pin/unpin and Open tools. Import copies an unpacked manifest.json folder into the app profile, with a permissions summary before loading; imported code is not downloaded by the app. Never load untrusted extensions. Source file changes can invalidate WebView2 installations, so imported files are kept in stable per-profile folders. Metadata files from store packages are skipped, junctions/symlinks rejected, with 100 MiB/20,000 file limits.

This is NOT a Chrome Web Store or Edge Add-ons installer. CRX packages need a valid unpacked folder. WebView2 does not expose every full-browser extension API; compatibility is extension dependent. An extension's declared options/popup entry can be opened as a tab from its shortcut, not a complete browser.action popover. Existing Edge extensions are not automatically copied. No equivalence to Edge extension compatibility is claimed.

## Resource control
One shared page environment, no dashboard webpage, background feed or continuous UI animation. Suggestions debounce once while typing. URL origin/site policy are cached per navigation. Memory saver requests suspension of hidden non-pinned, non-loading, non-audible page views and resumes on return; it preserves the DOM but background updates may be delayed. Can be disabled in Settings. Manual Sleep releases a page completely and asks before potentially losing unsaved state. Extensions add their own overhead; no zero-overhead claim.

## Build / evidence
CI policy tests and actual WebView2 integration checks cover navigation, filtering, local suggestions, favicon decoding, MV3 content-script execution, extension disable/removal, state-preserving suspension, split/rejoin, sleep/reload, workspaces and keyboard shortcuts. Deterministic virtual-host pages are used, not arbitrary live websites. Screenshots are from the running Windows application.

The baseline is the preceding 0.2 source. Both versions measure managed Main-entry-to-ready and one warmed blank WebView2. Measurements include main-process and known WebView2 process private bytes/working sets/CPU snapshots. Runtime crashpad is excluded by GetProcessInfos; summed working sets double-count shared pages; exited-process CPU is not traced. Measurements are not end-user performance, instant-loading guarantees or an internet-wide browser ranking. Safe Browsing, normal HTTP caching and certificate validation remain enabled.
