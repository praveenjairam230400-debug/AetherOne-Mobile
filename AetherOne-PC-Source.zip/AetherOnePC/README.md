# Aether One PC 0.1.0

Native Windows browser shell with the Microsoft Edge WebView2 Chromium engine. This is the Windows edition of Aether One, not an Android emulator or an HTML mockup.

## Run
Extract AetherOne-PC-Windows-x64.zip to a writable folder, then double-click AetherOne.exe. Requires Windows 11 x64 and Microsoft Edge WebView2 Evergreen Runtime. .NET is included in the EXE. No administrator rights are needed. If the engine is missing, install it from https://developer.microsoft.com/microsoft-edge/webview2/ using Microsoft's official Evergreen installer. The app does not silently install components.

The EXE is not Authenticode signed. Windows may show a reputation warning for a new, unsigned application. No Windows performance benchmark or SmartScreen reputation claim is made. Keep the included package files together.

## Features
- Native desktop address/navigation toolbar, home page, up to 24 tabs; background restored tabs initialize only when selected.
- Shared WebView2 engine/profile, default HTTP cache and live-page reuse. No engine security flags, custom proxy, SSL bypass or forced stale caching.
- Persistent bookmarks, up to 300 history entries and URL session restoration.
- Local host-based ad/tracker blocking, global toggle and exact-host site exceptions. No remote filtering server or telemetry. Not a complete EasyList engine; first-party ads and some redirects/workers may escape filters.
- Per-site JavaScript, images and zoom controls. Scripts/images remain enabled by default for complete content.
- Loading Inspector: current page navigation/resource timings, available FCP, blocked-request counts, and slowest resource hosts. Website timings can be incomplete or modified. No made-up time/bytes saved.
- User initiated new windows open in tabs; automatic popups blocked. Native download dialog, print, find, permission prompts.
- HTTPS-first address handling; file/data/javascript and unsupported top-level schemes rejected. Certificate failures cancelled. Sites can still collect data.

## Data and updates
Data is in %LOCALAPPDATA%\AetherOnePC\Profile, separate from Edge. Portable means no installer, not portable browsing data. JSON bookmarks/history/settings are local and readable by your Windows account; not an encrypted vault. No sync, incognito isolation, extension system, dedicated password manager or default-browser registration yet. Replacing the app EXE preserves its separate profile, provided the profile path stays unchanged. Android APK signing keys are unrelated and are never included in this project.

## Build and validation
.NET 10 SDK on Windows: dotnet run --project PolicyTests, then dotnet publish AetherOnePC/AetherOnePC.csproj -c Release -r win-x64 --self-contained true -o publish. CI runs the app with --smoke-test in an isolated profile and records the result plus screenshots. Deterministic fixtures cover actual engine startup/rendering, HTTPS virtual-host navigation, scripts, blocked/allowed requests, site exception, scripts off, bookmark and tab lifecycle. These checks do not substitute for testing arbitrary live websites, downloads, DRM media or performance on a user's PC.

## Shortcuts
Ctrl+L address, Ctrl+T new tab, Ctrl+W close tab, Ctrl+Tab next tab, Ctrl+Shift+Tab previous tab, Ctrl+D bookmark, Ctrl+B bookmarks, Ctrl+H history, Ctrl+J downloads, Ctrl+F find, Ctrl+R/F5 reload, Ctrl+P print, Alt+Left/Right history. Middle-click a tab to close it; right-click opens Close tab.
