# Aether One PC 0.5

Close the old app, extract the ZIP and run AetherOne.exe. Windows x64 and current WebView2 Evergreen Runtime required; .NET bundled. The executable is unsigned. This is the existing Aether native/WebView2 foundation with a Brave-inspired interface; it is not a Brave fork or a separate rendering engine.

## Interface
One horizontal tab strip and a plain page host: no second native tab header. Single-line ellipsized titles, full tab-body selection, middle-close, close controls, tooltips, tab overflow, window controls. Compact rounded address bar and toolbar, bookmarks bar, quiet gradient new-tab page. Full internal settings, profiles, extensions, bookmarks/history and downloads tabs share one navigation structure. Dark/light appearance, home/bookmarks toggles, search engines (Google, Brave, Bing, DuckDuckGo), startup restore, privacy, site JavaScript/images/ad control, memory target control and downloads location settings are implemented.

Spaces/workspaces, notes, Read later, split comparison and the bundled Reading Tools are removed from the UI. Reading Tools is removed from the engine profile during migration. Existing web tabs, bookmarks/history/cookies are retained under the default profile; prior workspace tabs are combined into the ordinary tab strip. Other extensions are retained. No new Reading Tools code is shipped.

## Predictions
Live Google predictions are enabled because they were explicitly requested. Typed search text goes to Google after 220 ms of inactivity; requests cancel on text change, submit or focus loss, with a three-second deadline. URL/email-like input is excluded. Settings > Search engine can turn predictions off. Search engine selection controls submitted searches independently of the prediction provider. Predictions are not fetched continuously or pre-rendered. Provider availability is outside Aether's control. Local bookmark/history/open-tab results remain available offline.

## Extensions
On a Chrome Web Store extension listing, use Aether's Install extension button above the page, or paste its URL in Extensions > Install from a store link. The store's native Add to Chrome mechanism is not Aether's installer and may still report interrupted downloads in WebView2.

Aether downloads CRX3 from Google's HTTPS update endpoint, checks the listing ID and developer signature, safely extracts a bounded archive, retains the signed public key for stable extension identity and shows declared permissions before loading with WebView2. Local signed CRX3 and unpacked folders are supported. Built-in component extensions are not offered for removal. Pin, enable/disable, options and remove are available for imported extensions. A declared options or popup page opens in a tab; a full browser.action popup window and every full-browser extension API are not provided. Extensions are not automatically updated; reinstallation is explicit. Signature checks establish package identity/integrity, not that an extension is safe. No unofficial CRX mirror is used.

## Profiles and downloads
Local profiles have separate program settings, history/bookmarks and separate engine user-data folders for cookies/extensions/site storage. Each opens in its own window. The default continues to use %LOCALAPPDATA%\AetherOnePC\Profile. Additional profiles use Profiles\<ID>; profiles.json stores names/IDs. There is no browser account, sync, password vault, Tor, VPN or Rewards service. Close each profile window before replacing program files.

Downloads show running/completed operations from the current window, support cancellation, folder selection and asking where to save. Completed files persist on disk. Download history is not persisted between windows.

## Resource and security behavior
Native new-tab/settings pages, shared engine environment per profile, lazy restored web tabs, bounded favicon cache, no feed/background UI animation. Memory saver requests Low for inactive unpinned/non-audio/non-loading views and restores Normal when selected. Scripts remain active; actual memory reclamation is engine managed and can slow a later return. Manual Sleep releases inactive webviews after confirming possible unsaved-state loss. Basic ad filtering can be disabled globally/per host; it is not full EasyList/Shields equivalence. Certificate validation and normal engine security remain enabled.

No claim of instant completion for every website, world-lowest resources, zero feature overhead or exact Brave feature equivalence is made. Live pages/extensions and network/server work determine actual cost. CI measures main-process and known engine processes together, and tests actual execution rather than screenshots alone. See the accompanying measured report for results and limits.


## 0.5 fixes and memory policy
Bookmark saving now immediately updates the bar and filled icon and opens an editable confirmation. Actual bookmark-open controls are exercised in CI. Tab close is limited to its 24-pixel close control with a hover circle; active closure prefers the right neighbor. Close tabs to the right and Close other tabs keep pinned pages. Rapid close holds tab widths until the pointer leaves. Native menus/suggestions dismiss on outside mouse clicks, including clicks inside WebView2, using a mouse hook only while a popup is visible (no keystroke capture or stored input).

Hidden pages now request state-preserving engine suspension; if unavailable the engine Low-memory target is used. After two inactive minutes, eligible pages are released while over three live views remain. Active, pinned, playing-audio, loading and detectable draft/form pages are excluded, as are active downloads. Detection is conservative but cannot recognize every site's custom application state. Released tabs reload on selection. Existing manual Sleep asks before releasing pages. Internal pages release unused webviews. The three-view target is not a hard RAM cap; protected tabs and extensions may keep more memory.

The extension unpacked limit is 512 MiB instead of 100 MiB, retaining signed-ID verification, path checks and bounded extraction. Compressed download limit remains 100 MiB. The exact AdBlocker Ultimate package from the reported error is tested in an isolated profile. Extensions themselves can materially increase memory.

The new memory report measures eight separate controlled pages, each touching a 32 MiB JS buffer and drawing a canvas, before reclamation, after and after closing. It includes all known engine processes. This is not an authenticated ChatGPT/Gmail measurement on the user's computer and does not prove the reported 2 GB is eliminated on their device.
