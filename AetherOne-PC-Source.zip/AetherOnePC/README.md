# Aether One PC 0.2 — Workspace edition

Extract the Windows x64 ZIP and run AetherOne.exe. Requires Windows 11 x64 with Microsoft Edge WebView2 Evergreen Runtime. .NET is bundled. No installer or admin privileges. EXE is unsigned; Windows may display a reputation warning. Runtime installation, if needed, is from https://developer.microsoft.com/microsoft-edge/webview2/.

## Redesigned native interface
Custom drawn vertical tab rail, workspace switcher, compact vector toolbar and Overview dashboard. Native controls and GDI+ rendering; no embedded dashboard webpage, animation loop, feed polling or network wallpaper. Overview cards use actual local reading-list/history/notes data, with honest empty states.

Features: Personal/Work/Research and custom workspaces, pinned tabs, searchable Ctrl+K command palette, bookmarks/history, Read later, local workspace notes drawer, focus view, two-page split view, reopen closed tabs (Ctrl+Shift+T), and manual sleep for inactive unpinned tabs. Sleeping discards the page and can lose forms/scroll state; asks before releasing, then reloads on selection. Workspace grouping shares one cookie profile; not isolated accounts.

Split view reuses two existing page controls. Toolbar controls the left page; click Split again to exit. Additional panels are built on demand. Per-page filter host/settings are cached on navigation to avoid repeated origin parsing and preference lookups for each resource.

Preserves global/per-site host-based ad filtering, per-site scripts/images/zoom, Loading Inspector, HTTPS-first navigation, certificate enforcement, downloads, printing and page find. Not full EasyList, extension support, private browsing, sync or a password manager. No claim of instant loading of arbitrary pages, zero resource overhead, novelty over every browser, or being the lightest browser worldwide.

## Profiles and updates
Uses the same %LOCALAPPDATA%\AetherOnePC\Profile as 0.1. Replace program files while the app is closed; data stays separate. Old URL sessions migrate to workspace session records. Notes/history/bookmarks are local JSON, readable by your Windows account. Never includes Android signing credentials.

## Validation and performance
CI executes policy tests and actual WebView2 smoke checks against local HTTPS virtual-host fixtures; checks blocking on/off, site exceptions/scripts, bookmarks, tab lifecycle, workspaces, read later and notes. Screenshots capture the running Windows app. Baseline source is the exact 0.1 shell plus measurement hooks. Both variants are published and launched sequentially on the same Windows runner with one warmed blank WebView2 and no remote page.

Performance JSON reports main-entry-to-Shown and main-entry-to-engine-ready time (EXE extraction before Main is excluded), native control count, managed bytes, root process private bytes/working set and a three-second root CPU interval after warmup. WebView2 child-process memory/CPU are EXCLUDED. Single CI measurements have noise and are not whole-browser or real-PC benchmarks. They do not establish comparative speed against other products.

## Design references
Official product material reviewed for interaction patterns, without importing their assets or code:
- Edge: https://explore.microsoft.com/en-us/edge/features
- Firefox: https://www.firefox.com/en-US/features/vertical-tabs/
- Vivaldi: https://vivaldi.com/features/
- Arc: https://start.arc.net/command-bar-actions
- Opera: https://www.opera.com/one
- Brave: https://support.brave.app/hc/en-us/articles/35087087593997-How-do-I-use-Split-view-in-Brave
- Chrome: https://support.google.com/chrome/answer/12929150
