using AetherOnePC;
var count = 0;
void Check(bool condition, string title) { if (!condition) throw new Exception(title); count++; }
Check(Policy.Resolve("example.org/path") == "https://example.org/path", "bare host");
Check(Policy.Resolve("http://example.org/") == "https://example.org/", "HTTPS upgrade");
Check(Policy.Resolve("https://example.org:8443/") == "https://example.org:8443/", "custom port");
Check(Policy.Resolve("javascript:alert(1)") is null, "script scheme rejected");
Check(Policy.Resolve("file:///C:/secret") is null, "local files rejected");
Check(Policy.Resolve("data:text/html,test") is null, "data scheme rejected");
Check(Policy.Resolve("about:blank") is null, "about scheme rejected");
Check(Policy.Resolve("AML case notes")!.StartsWith("https://www.google.com/search?q="), "search routing");
Check(Policy.ShouldBlock("secure.doubleclick.net", "example.org"), "ad subdomain");
Check(Policy.ShouldBlock("DOUBLECLICK.NET.", "example.org"), "normalization");
Check(!Policy.ShouldBlock("notdoubleclick.net", "example.org"), "suffix boundary");
Check(!Policy.ShouldBlock("doubleclick.net.example.org", "example.com"), "suffix spoof");
Check(!Policy.ShouldBlock("doubleclick.net", "doubleclick.net"), "direct visit");
Check(!Policy.ShouldBlock("secure.doubleclick.net", "doubleclick.net"), "first party");
Check(!Policy.ShouldBlock(null, "example.org"), "null host");
Console.WriteLine($"PASS: {count} policy checks");
