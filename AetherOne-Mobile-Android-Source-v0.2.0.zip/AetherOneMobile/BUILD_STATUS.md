# Build status
0.1.0 compiled successfully in GitHub Actions run 41364832305.
0.2.0: redesigned native UI and features; pending fresh compilation and device validation.
