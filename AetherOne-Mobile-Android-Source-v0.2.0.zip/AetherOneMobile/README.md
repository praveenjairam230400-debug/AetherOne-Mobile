# Aether One Mobile 0.2.0

Native Kotlin / Android System WebView browser. Minimum Android 8; targets Android 15. Android 16 system bar spacing is handled with WindowInsets.

## Changes
- Native dark start page with search, quick links and bookmarks.
- Mint and lavender adaptive launcher icon, including themed icon support.
- Drawn vector controls, 48dp touch targets and accessible control descriptions.
- System-bar, display-cutout and keyboard insets.
- Scrollable tab cards, per-tab close buttons, lazy tab creation and restoration of up to 20 tab URLs.
- Bookmarks and 200-entry local history with removal controls.
- Find in page, document uploads, fullscreen video, long-press link actions.
- Desktop site switch, Downloads shortcut, share and copy.
- Default browser role request and external HTTPS link handling.
- Confirmed browsing-data deletion that closes pages while preserving bookmarks.

## Build
GitHub Actions unpacks the versioned source archive into `AetherOneMobile` and runs Gradle 8.9 / JDK 17 / Android SDK 35. Download `AetherOne-installable-debug-apk` from the successful run and extract the APK.

Debug signing keys can differ between GitHub runners; Android may require uninstalling a previous debug build. This deletes its app data. These are test builds, not Play Store releases.

## Limits
No private-browsing isolation, camera/microphone permissions, password manager, extension engine, ad blocker or guaranteed performance advantage. HTTPS-only network policy prevents unencrypted pages. Websites and search engines can collect data. Session restore stores URLs and titles, not full page state or navigation history. Device testing is required.
