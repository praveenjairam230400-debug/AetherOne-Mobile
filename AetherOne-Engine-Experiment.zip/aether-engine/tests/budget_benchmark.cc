#include "aether_prepaint_budget.h"
#include <chrono>
#include <iostream>

int main() {
  constexpr std::size_t MiB=1024*1024;
  constexpr int count=5000000;
  cc::AetherPrepaintBudget policy;
  std::size_t sum=0;
  auto start=std::chrono::steady_clock::now();
  for(int i=0;i<count;++i)sum+=policy.Update((240+(i%17))*MiB,512*MiB,i,(i%15000)<16,(i%9000)<60,false);
  auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();
  std::cout << "{\"kind\":\"standalone_controller_microbenchmark\",\"iterations\":" << count
            << ",\"total_ns\":" << ns << ",\"ns_per_update\":" << static_cast<double>(ns)/count
            << ",\"state_bytes\":" << sizeof(policy) << ",\"checksum\":" << sum
            << ",\"browser_speedup_measured\":false}\n";
}
