#include "aether_prepaint_budget.h"
#include <cstdlib>
#include <iostream>
#include <limits>
#include <random>
#include <string>

namespace {
int checks = 0;
void Check(bool ok, const char* message) {
  if (!ok) { std::cerr << "FAIL: " << message << '\n'; std::exit(1); }
  ++checks;
}
constexpr std::size_t MiB = 1024 * 1024;
}

int main() {
  using cc::AetherPrepaintBudget;
  static_assert(sizeof(AetherPrepaintBudget) <= 40);
  AetherPrepaintBudget p;
  Check(p.Update(256*MiB,512*MiB,0,false,false,false)==256*MiB,"cold start keeps upstream budget");
  for(int t=1;t<2000;++t)Check(p.Update(256*MiB,512*MiB,t,false,false,false)==256*MiB,"warmup does not shrink");
  auto step=p.Update(256*MiB,512*MiB,2000,false,false,false);
  Check(step<256*MiB,"stable interval shrinks optional budget");
  for(int i=0;i<1000;++i)Check(p.Update(256*MiB,512*MiB,2000,false,false,false)==step,"same-timestamp reentry does not compound shrink");
  for(int t=2500;t<=5000;t+=500)p.Update(256*MiB,512*MiB,t,false,false,false);
  Check(p.Update(256*MiB,512*MiB,5001,false,false,false)==128*MiB,"stable floor is half upstream ceiling");
  Check(p.Update(256*MiB,512*MiB,5010,true,false,false)==256*MiB,"urgent raster restores immediately");
  Check(p.Update(256*MiB,512*MiB,5500,false,false,false)==256*MiB,"recovery cooldown holds");
  Check(p.Update(256*MiB,512*MiB,8000,false,true,false)==256*MiB,"gesture/smoothness restores");
  Check(p.Update(256*MiB,512*MiB,10000,false,false,true)==256*MiB,"OOM restores");
  Check(p.Update(0,512*MiB,10001,false,false,false)==0,"zero soft stays zero");
  Check(p.Update(512*MiB,0,10002,false,false,false)==0,"zero hard stays zero");
  Check(p.Update(512*MiB,16*MiB,10003,false,false,false)==16*MiB,"hard cap always wins over floor");
  for(int t=11000;t<=15000;t+=500)p.Update(40*MiB,512*MiB,t,false,false,false);
  Check(p.Update(40*MiB,512*MiB,15001,false,false,false)==32*MiB,"small budgets retain absolute floor");
  Check(p.Update(256*MiB,512*MiB,10,false,false,false)==256*MiB,"clock rewind resets policy");
  auto max=std::numeric_limits<std::size_t>::max();
  Check(p.Update(max,max,11,true,false,false)==max,"size max does not overflow");
  p.Update(max,max,5011,false,false,false);
  Check(p.Update(max,max,5511,false,false,false)<=max,"size max stable scaling is bounded");
  AetherPrepaintBudget full_range;
  full_range.Update(max,max,std::numeric_limits<std::int64_t>::min(),false,false,false);
  Check(full_range.Update(max,max,std::numeric_limits<std::int64_t>::max(),false,false,false)<=max,"elapsed calculation avoids signed overflow");
  std::mt19937_64 random(0xA37E);
  std::int64_t now=0;
  for(int i=0;i<100000;++i){
    now+=static_cast<std::int64_t>(random()%1000);
    std::size_t soft=random(),hard=random();
    bool urgent=random()%17==0,smooth=random()%19==0,oom=random()%31==0;
    auto result=p.Update(soft,hard,now,urgent,smooth,oom);
    Check(result<=std::min(soft,hard),"fuzz: never raises upstream limits");
    Check(result>=std::min(AetherPrepaintBudget::kFloorBytes,std::min(soft,hard)),"fuzz: absolute floor bounded by upstream limits");
    if(urgent||smooth||oom)Check(result==std::min(soft,hard),"fuzz: urgent signals restore upstream allowance");
  }
  std::cout << "PASS: " << checks << " checks; controller state " << sizeof(p) << " bytes\n";
}
