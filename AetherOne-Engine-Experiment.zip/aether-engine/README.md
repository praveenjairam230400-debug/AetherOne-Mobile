# Aether engine experiment 0.1

**Status: a compiled and tested experimental compositor-budget component, plus
a patch against pinned Chromium source. This is not a complete new browser
engine, not an installable browser, and not integrated into Aether One.**

## What actually changed

The patch changes `cc/tiles/tile_manager.cc`, its header, feature declarations
and GN source lists. It adds a fixed-state C++ controller to the engine's
speculative raster-memory allowance. It does not inject website JavaScript,
unload tabs, alter DOM state, replace V8, or rename Microsoft's runtime.

The experiment uses Chromium's existing raster-priority queue. After a quiet
warmup it gradually reduces the soft tile-byte allowance toward 50% of the
upstream ceiling, with a 32 MiB floor that never overrides a smaller upstream
limit. Missing urgent work, smoothness-priority work or a prior tile OOM restores
the upstream allowance immediately. Repeated calls within a frame do not
accelerate shrinkage. A fixed 32-byte state tracks timing and the allowance.

The existing hard limit and NOW-tile decision remain unchanged. That is a source
guard and policy invariant, **not a proof of visual correctness**. Smaller soft
budgets may increase rerasterization or interfere with activation and scrolling.
No drop in actual process memory is established: resource pools and GPU
allocators can retain freed resources, and this patch does not manage DOM, JS
heaps, all decoded images, network state or extension heaps.

Chromium already includes tile prioritization, memory budgets and idle prepaint
reclamation. This experiment is an additional feedback policy; no claim of a
globally unprecedented invention is made.

## Reproduce the component tests

Linux: Python 3, Git and a C++20 `g++` compiler:

```sh
python3 tools/validate.py
```

Windows: run the same command with `python` inside an x64 MSVC developer shell.
The hosted CI workflow runs both platforms. Linux validation includes ASan and
UBSan. When a ptrace-based host prevents LeakSanitizer, explicitly use
`ASAN_OPTIONS=detect_leaks=0`; the report records that setting. This disables the
leak checker only; the address and undefined-behaviour checks remain enabled.

`results/validation.json` reports controller tests, source-patch application and
a standalone computation microbenchmark. It explicitly records that a full
engine, website compatibility and browser-level speed/memory improvements have
not been validated. Controller nanoseconds are not page-load timings.

## Pinned upstream

Revision: `3263af0602002446c148d6ae5de1aa51b4f78e5a`.
`upstream-lock.json` includes SHA-256 values for every retrieved source file.
The included upstream directory is a small verification snapshot, **not** a full
Chromium checkout. Chromium's BSD license is retained in `LICENSE`.

## Full-engine build path

On a provisioned Linux build machine, sync a full Chromium checkout and all DEPS
at the exact revision above using the official instructions:

https://chromium.googlesource.com/chromium/src/+/main/docs/linux/build_instructions.md

Install official build prerequisites and depot_tools on that machine. The build
helper requires at least 100 GiB free disk and makes no system/dependency changes:

```sh
python3 tools/build_engine.py /absolute/path/to/chromium/src
```

It checks the revision and source hashes, applies the patch, builds `chrome`
and `cc_unittests`, then runs the compositor suite with the experiment both off
and on. It does not provision paid hardware or silently use remote credentials.

Use separate fresh profiles with the same binary for the subsequent A/B run:

```sh
out/AetherExperiment/chrome --user-data-dir=/tmp/aether-control --disable-features=AetherAdaptivePrepaint
out/AetherExperiment/chrome --user-data-dir=/tmp/aether-experiment --enable-features=AetherAdaptivePrepaint
```

Keep all Chromium sandbox, certificate and site-isolation protections enabled.
The feature is disabled by default and restricted to renderer tile managers.
GPU, headless and software rendering can behave differently; measure each
target separately. Real Aether deployment also needs a Windows engine build and
an embedding integration; this patch is not a WebView2-compatible DLL.

## Acceptance gate before integration

1. Full engine and compositor tests pass with the feature off and on.
2. Repeated A/B workloads cover long text/image pages, rapid scroll reversals,
   video, input, navigation, resizing, device scale changes and low-memory cases.
3. Record total private process memory and GPU allocations separately, plus
   p50/p95 interaction/scroll delays, paint correctness and rerasterization.
4. Reject memory savings that introduce unacceptable latency or visual defects.
5. Test authenticated sites with user authorization; do not infer Gmail/ChatGPT
   results from synthetic buffers or screenshots.

Current environment: approximately 59 GiB free disk and 9.7 GiB RAM. Chromium's
documented full-build free-disk requirement exceeds this environment. No full
engine binary has been produced here; the pending build gate is explicit.
