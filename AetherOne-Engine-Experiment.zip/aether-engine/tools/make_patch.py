#!/usr/bin/env python3
"""Generate a deterministic Chromium patch from verified pinned source."""
import difflib, hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
lock=json.loads((ROOT/'upstream-lock.json').read_text())
original={}
for item in lock['files']:
 data=(ROOT/'upstream'/item['path']).read_bytes()
 if hashlib.sha256(data).hexdigest()!=item['sha256']:raise SystemExit('Upstream hash mismatch: '+item['path'])
 original[item['path']]=data.decode()
modified={k:v for k,v in original.items() if k.startswith('cc/') and not k.endswith('unittest.cc')}
def replace(path,old,new):
 text=modified[path]
 if text.count(old)!=1:raise SystemExit('Ambiguous integration anchor: '+path)
 modified[path]=text.replace(old,new,1)
replace('cc/tiles/tile_manager.h','#include <stddef.h>','#include <stddef.h>\n\n#include "cc/tiles/aether_prepaint_budget.h"')
replace('cc/tiles/tile_manager.h','  bool did_oom_on_last_assign_;','  bool did_oom_on_last_assign_;\n\n  AetherPrepaintBudget aether_prepaint_budget_;')
replace('cc/base/features.h','namespace features {','namespace features {\n\n// Aether experiment. Disabled unless explicitly enabled at launch.\nCC_BASE_EXPORT BASE_DECLARE_FEATURE(kAetherAdaptivePrepaint);')
replace('cc/base/features.cc','namespace features {','namespace features {\n\nBASE_FEATURE(kAetherAdaptivePrepaint, base::FEATURE_DISABLED_BY_DEFAULT);')
queue='''  std::unique_ptr<RasterTilePriorityQueue> raster_priority_queue(
      client_->BuildRasterQueue(global_state_.tree_priority,
                                RasterTilePriorityQueue::Type::ALL));
'''
# This exact queue construction occurs once inside AssignGpuMemoryToTiles.
text=modified['cc/tiles/tile_manager.cc'];begin=text.index('TileManager::PrioritizedWorkToSchedule TileManager::AssignGpuMemoryToTiles() {');before=text[:begin];body=text[begin:]
if queue not in body:raise SystemExit('Raster queue anchor changed')
body=body.replace(queue,'',1)
anchor='  MemoryUsage hard_memory_limit(global_state_.hard_memory_limit_in_bytes,'
insert=queue+'''
  size_t aether_soft_limit = global_state_.soft_memory_limit_in_bytes;
  if (running_on_renderer_process_ &&
      base::FeatureList::IsEnabled(features::kAetherAdaptivePrepaint)) {
    // The top raster entry reflects the existing upstream priority ordering.
    // Missing visible/activation work restores headroom before this assignment.
    const bool urgent =
        !raster_priority_queue->IsEmpty() &&
        raster_priority_queue->Top().tile()->draw_info().NeedsRaster() &&
        (raster_priority_queue->Top().priority().priority_bin == TilePriority::NOW ||
         raster_priority_queue->Top().tile()->required_for_activation() ||
         raster_priority_queue->Top().tile()->required_for_draw());
    aether_soft_limit = aether_prepaint_budget_.Update(
        global_state_.soft_memory_limit_in_bytes,
        global_state_.hard_memory_limit_in_bytes,
        NowWithOverride().since_origin().InMilliseconds(), urgent,
        global_state_.tree_priority == SMOOTHNESS_TAKES_PRIORITY,
        did_oom_on_last_assign_);
    TRACE_EVENT_INSTANT("cc", "Aether.PrepaintBudget", "soft_bytes",
                        aether_soft_limit, "urgent", urgent);
  }

'''
if body.count(anchor)!=1:raise SystemExit('Memory limit anchor changed')
body=body.replace(anchor,insert+anchor,1).replace('MemoryUsage soft_memory_limit(global_state_.soft_memory_limit_in_bytes,','MemoryUsage soft_memory_limit(aether_soft_limit,',1)
modified['cc/tiles/tile_manager.cc']=before+body
replace('cc/BUILD.gn','    "tiles/tile_manager.cc",','    "tiles/aether_prepaint_budget.h",\n    "tiles/tile_manager.cc",')
replace('cc/BUILD.gn','    "tiles/tile_manager_unittest.cc",','    "tiles/aether_prepaint_budget_unittest.cc",\n    "tiles/tile_manager_unittest.cc",')
modified['cc/tiles/aether_prepaint_budget.h']=(ROOT/'src/aether_prepaint_budget.h').read_text()
modified['cc/tiles/aether_prepaint_budget_unittest.cc']='''// Copyright 2026 Aether One contributors. BSD-3-Clause.
#include "cc/tiles/aether_prepaint_budget.h"
#include "testing/gtest/include/gtest/gtest.h"
namespace cc {
TEST(AetherPrepaintBudgetTest, KeepsUrgentBudgetAndRestoresAfterCalm) {
  constexpr size_t kMiB = 1024 * 1024;
  AetherPrepaintBudget p;
  EXPECT_EQ(256 * kMiB, p.Update(256*kMiB,512*kMiB,0,true,false,false));
  for (int t = 2000; t <= 5000; t += 500)
    p.Update(256*kMiB,512*kMiB,t,false,false,false);
  EXPECT_EQ(128*kMiB, p.Update(256*kMiB,512*kMiB,5001,false,false,false));
  EXPECT_EQ(256*kMiB, p.Update(256*kMiB,512*kMiB,5002,true,false,false));
}
TEST(AetherPrepaintBudgetTest, NeverOverridesUpstreamHardOrZeroLimits) {
  AetherPrepaintBudget p;
  EXPECT_EQ(0u, p.Update(0,100,0,false,false,false));
  EXPECT_EQ(17u, p.Update(100,17,1,true,false,false));
}
}  // namespace cc
'''
patch=''
for path,new in sorted(modified.items()):
 old=original.get(path,'')
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path if path in original else '/dev/null',tofile='b/'+path))
(ROOT/'patches/0001-adaptive-prepaint-budget.patch').write_text(patch)
print('Generated source patch against '+lock['revision'])
