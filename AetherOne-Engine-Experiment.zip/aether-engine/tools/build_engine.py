#!/usr/bin/env python3
"""Build experimental Chromium on a provisioned Linux checkout. No downloads,
dependency installation, elevation, paid runner provisioning or release upload.
The checkout must already be synced with depot_tools and build dependencies.
"""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

parser=argparse.ArgumentParser()
parser.add_argument('checkout',type=Path)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
checkout=args.checkout.resolve()
if shutil.disk_usage(checkout).free < 100*1024**3:
    raise SystemExit('Full Chromium build not started: provide at least 100 GiB free disk on build volume')
for executable in ['gn','autoninja']:
    if not shutil.which(executable):raise SystemExit('Missing depot_tools executable: '+executable)
subprocess.run([sys.executable,str(root/'tools/apply_to_chromium.py'),str(checkout)],check=True)
out='out/AetherExperiment'
gn_args='is_debug=false is_component_build=false symbol_level=0 blink_symbol_level=0 v8_symbol_level=0 is_official_build=false'
subprocess.run(['gn','gen',out,'--args='+gn_args],cwd=checkout,check=True)
subprocess.run(['autoninja','-C',out,'chrome','cc_unittests'],cwd=checkout,check=True)
test=checkout/out/'cc_unittests'
for feature in ['--disable-features=AetherAdaptivePrepaint','--enable-features=AetherAdaptivePrepaint']:
    subprocess.run([str(test),'--test-launcher-jobs=2',feature],cwd=checkout,check=True)
print('Engine and compositor tests built. Page-level A/B validation remains required before Aether integration.')
