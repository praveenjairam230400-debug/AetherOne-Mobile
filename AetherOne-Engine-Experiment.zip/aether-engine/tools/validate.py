#!/usr/bin/env python3
"""Validate component + patch. Never reports a complete browser build."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import statistics
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
BUILD = OUT / 'build'
BUILD.mkdir(exist_ok=True)
log = []

def run(args, **kwargs):
    result = subprocess.run([str(x) for x in args], text=True, capture_output=True, **kwargs)
    log.append({'command': [str(x) for x in args], 'returncode': result.returncode,
                'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode:
        (OUT/'validation-log.json').write_text(json.dumps(log, indent=2))
        raise RuntimeError(result.stderr or result.stdout or str(args))
    return result.stdout.strip()

lock = json.loads((ROOT/'upstream-lock.json').read_text())
run(['python3' if os.name != 'nt' else 'python', ROOT/'tools/make_patch.py'])
with tempfile.TemporaryDirectory(prefix='aether-patch-') as temp:
    checkout = Path(temp)
    shutil.copytree(ROOT/'upstream', checkout, dirs_exist_ok=True)
    run(['git', 'init', '-q', checkout])
    run(['git', '-C', checkout, 'apply', '--check', ROOT/'patches/0001-adaptive-prepaint-budget.patch'])
    run(['git', '-C', checkout, 'apply', ROOT/'patches/0001-adaptive-prepaint-budget.patch'])
    assert (checkout/'cc/tiles/aether_prepaint_budget.h').read_bytes() == (ROOT/'src/aether_prepaint_budget.h').read_bytes()
    patched = (checkout/'cc/tiles/tile_manager.cc').read_text()
    assert 'MemoryUsage hard_memory_limit(global_state_.hard_memory_limit_in_bytes,' in patched
    assert 'tile_is_needed_now ? hard_memory_limit : soft_memory_limit' in patched
    assert 'MemoryUsage soft_memory_limit(aether_soft_limit,' in patched
    assert 'kAetherAdaptivePrepaint' in patched

suffix = '.exe' if os.name == 'nt' else ''
compiler = shutil.which('cl') if os.name == 'nt' else shutil.which('g++')
if not compiler:
    raise RuntimeError('A C++20 compiler is required')
def compile_one(source, target, sanitize=False):
    if os.name == 'nt':
        command=[compiler,'/nologo','/std:c++20','/O2','/EHsc','/W4','/WX',
                 '/I'+str(ROOT/'src'),str(source),'/Fe:'+str(target),'/Fo:'+str(BUILD / (source.stem+'.obj'))]
    else:
        command=[compiler,'-std=c++20','-O2','-Wall','-Wextra','-Werror','-pedantic',
                 '-I',str(ROOT/'src'),str(source),'-o',str(target)]
        if sanitize: command += ['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    run(command)

unit=BUILD/('budget_tests'+suffix)
compile_one(ROOT/'tests/budget_tests.cc',unit)
checks=run([unit])
sanitizers='not_run_on_windows'
if os.name != 'nt':
    target=BUILD/'budget_tests_sanitized'
    compile_one(ROOT/'tests/budget_tests.cc',target,True)
    sanitizers=run([target], env={**os.environ,'ASAN_OPTIONS':os.environ.get('ASAN_OPTIONS','detect_leaks=1')})
bench=BUILD/('budget_benchmark'+suffix)
compile_one(ROOT/'tests/budget_benchmark.cc',bench)
samples=[json.loads(run([bench])) for _ in range(7)]
report={
    'status':'component_tests_passed_full_engine_not_built',
    'chromium_revision':lock['revision'],
    'platform':platform.platform(),
    'compiler':compiler,
    'controller_tests':checks,
    'sanitizers':sanitizers,
    'asan_options':os.environ.get('ASAN_OPTIONS','detect_leaks=1') if os.name!='nt' else 'not_run',
    'patch_application':'passed_on_hash_verified_pinned_sources',
    'upstream_hard_and_NOW_limit_source_guards':'passed',
    'controller_microbenchmark':{
        'median_ns_per_update':statistics.median(s['ns_per_update'] for s in samples),
        'samples':samples,
        'note':'Only controller computation. Not Chromium speed, page speed, browser RAM savings, GPU work or integrated overhead.'},
    'full_engine_build':False,
    'chromium_cc_unittests_run':False,
    'browser_memory_savings_measured':False,
    'website_compatibility_tested':False,
}
(OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'validation-log.json').write_text(json.dumps(log,indent=2)+'\n')
print(checks)
print('Patch: PASS; ASan/UBSan: '+('PASS' if os.name!='nt' else 'not run'))
print('Standalone median ns/update:',report['controller_microbenchmark']['median_ns_per_update'])
print('Full Chromium build / browser speedup: NOT established')
