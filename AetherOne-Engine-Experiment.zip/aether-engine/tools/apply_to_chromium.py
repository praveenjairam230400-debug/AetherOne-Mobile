#!/usr/bin/env python3
"""Apply only to the exact pinned, unmodified integration files."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
checkout=Path(sys.argv[1]).resolve()
lock=json.loads((root/'upstream-lock.json').read_text())
revision=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()
if revision!=lock['revision']:raise SystemExit('Wrong Chromium revision; do not apply this patch')
for item in lock['files']:
    path=checkout/item['path']
    if hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
        raise SystemExit('Modified integration source: '+item['path'])
patch=root/'patches/0001-adaptive-prepaint-budget.patch'
subprocess.run(['git','-C',str(checkout),'apply','--check',str(patch)],check=True)
subprocess.run(['git','-C',str(checkout),'apply',str(patch)],check=True)
print('Applied engine experiment; full engine compilation and compatibility checks still required')
