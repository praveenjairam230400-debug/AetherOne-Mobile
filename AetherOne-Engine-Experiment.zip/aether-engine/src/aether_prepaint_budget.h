// Copyright 2026 Aether One contributors.
// BSD-3-Clause; see LICENSE.
#ifndef CC_TILES_AETHER_PREPAINT_BUDGET_H_
#define CC_TILES_AETHER_PREPAINT_BUDGET_H_

#include <algorithm>
#include <cstddef>
#include <cstdint>

namespace cc {

// Experimental compositor policy, not a process-wide memory limit. O(1), no
// allocations, no DOM changes and no JS hooks. Upstream NOW-tile/hard limits
// remain authoritative. A calm interval is wall-clock based, not frame-count
// based, since AssignGpuMemoryToTiles can run repeatedly within one frame.
class AetherPrepaintBudget {
 public:
  static constexpr std::int64_t kWarmupMs = 2000;
  static constexpr std::int64_t kStepMs = 500;
  static constexpr std::size_t kFloorBytes = 32u * 1024u * 1024u;

  std::size_t Update(std::size_t soft_limit,
                     std::size_t hard_limit,
                     std::int64_t now_ms,
                     bool urgent_raster,
                     bool smoothness_priority,
                     bool previous_oom) {
    // A disabled upstream budget must stay disabled. Never raise either limit.
    const std::size_t ceiling = std::min(soft_limit, hard_limit);
    if (!initialized_ || now_ms < last_ms_) {
      initialized_ = true;
      percent_ = 100;
      last_change_ms_ = now_ms;
      last_urgent_ms_ = now_ms;
    }
    last_ms_ = now_ms;
    if (urgent_raster || smoothness_priority || previous_oom) {
      percent_ = 100;
      last_change_ms_ = now_ms;
      last_urgent_ms_ = now_ms;
    } else if (Elapsed(now_ms, last_urgent_ms_) >= kWarmupMs &&
               Elapsed(now_ms, last_change_ms_) >= kStepMs) {
      // One step per observation, even after a long pause. Avoid a sudden
      // cache collapse after visibility or system-sleep transitions.
      percent_ = std::max(50, percent_ - 10);
      last_change_ms_ = now_ms;
    }
    // Quotient/remainder avoids size_t overflow at SIZE_MAX.
    const auto percent = static_cast<std::size_t>(percent_);
    const std::size_t scaled = ceiling / 100 * percent +
                               ceiling % 100 * percent / 100;
    return std::min(ceiling, std::max(kFloorBytes, scaled));
  }

  int retained_percent_for_testing() const { return percent_; }

 private:
  static std::uint64_t Elapsed(std::int64_t now, std::int64_t then) {
    // Called only for monotonic observations after the reset above. Unsigned
    // subtraction also handles the entire int64_t tick range without UB.
    return static_cast<std::uint64_t>(now) - static_cast<std::uint64_t>(then);
  }
  std::int64_t last_ms_ = 0;
  std::int64_t last_change_ms_ = 0;
  std::int64_t last_urgent_ms_ = 0;
  int percent_ = 100;
  bool initialized_ = false;
};

}  // namespace cc
#endif  // CC_TILES_AETHER_PREPAINT_BUDGET_H_
