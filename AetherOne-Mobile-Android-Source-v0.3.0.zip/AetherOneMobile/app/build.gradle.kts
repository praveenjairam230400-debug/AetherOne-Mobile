plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.aetherone.mobile"
    compileSdk = 36
    defaultConfig { applicationId = "com.aetherone.mobile"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "0.3.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies { implementation("androidx.webkit:webkit:1.16.0") }
