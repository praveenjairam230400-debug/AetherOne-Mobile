# Aether One Mobile 0.3.0

Performance update for the native Android System WebView browser.

## Speed changes
- AndroidX WebKit 1.16 asynchronous engine startup begins before UI construction.
- First WebView is warmed when startup completes; no background-thread WebView construction.
- Feature-guarded BackForwardCache for eligible back/forward navigation.
- Feature-guarded prerender of Google home quick link on unmetered networks; configurable in Speed settings. Only one speculative page per activity; cancelled on backgrounding or unrelated navigation. Uses additional data and memory. No unsupported-provider hidden fallback page loads.
- Exact live-page reuse avoids a network reload when returning from the native home screen.
- Progress updates no longer rewrite the address field and all navigation icons.
- Session writes are debounced and flushed when backgrounded. History is retained in memory rather than reparsed on every navigation.
- Optional Lite mode suppresses network images; sites and scripts still run.
- On-device timing strip reports WebView first-visible and page-finished callbacks, not invented benchmark scores.

## Build
JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.10.1, compile SDK 36, target SDK 35, minimum SDK 26. GitHub Actions compiles the APK and runs Android lint.

## Limits
No claim of zero-latency loading for arbitrary new pages. Prerender activation, cache eligibility, site resources, server response, provider support and connectivity affect results. No SSL bypass, forced stale cache, Safe Browsing disabling or fake page snapshots. Session restore retains URLs and titles, not complete rendered pages after process death. Debug test signing may require uninstalling an older build, deleting its app data.
